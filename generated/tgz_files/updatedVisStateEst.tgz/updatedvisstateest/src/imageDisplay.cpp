//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: imageDisplay.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "imageDisplay.h"
#include "rt_nonfinite.h"
#include "MW_SDL_video_display.h"
#include <algorithm>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
namespace coder {
namespace nvidiacoder {
namespace common {
void imageDisplay::matlabCodegenDestructor()
{
  if (!matlabCodegenIsDeleted) {
    matlabCodegenIsDeleted = true;
    if (isInitialized == 1) {
      isInitialized = 2;
      if (isSetupComplete) {
        imageDisplay::releaseImpl();
      }
    }
  }
}

//
// Arguments    : void
// Return Type  : void
//
void imageDisplay::releaseImpl()
{
  MW_SDL_videoDisplayTerminate(0, 0);
}

//
// Arguments    : void
// Return Type  : void
//
void imageDisplay::setupImpl()
{
  PixelFormatEnum = 1;
  MW_SDL_videoDisplayInit(PixelFormatEnum, 1, 1, 360.0, 640.0);
}

//
// Arguments    : unsigned char pln1[230400]
//                unsigned char pln2[230400]
//                unsigned char pln3[230400]
// Return Type  : void
//
void imageDisplay::stepImpl(unsigned char pln1[230400],
                            unsigned char pln2[230400],
                            unsigned char pln3[230400])
{
  MW_SDL_videoDisplayOutput(&pln1[0], &pln2[0], &pln3[0]);
}

//
// Arguments    : imageDisplay &iobj_0
// Return Type  : imageDisplay *
//
imageDisplay *imageDisplay::b_imageDisplay(imageDisplay &iobj_0)
{
  imageDisplay *dispObj;
  iobj_0.isInitialized = 0;
  dispObj = &iobj_0;
  iobj_0.matlabCodegenIsDeleted = false;
  return dispObj;
}

//
// Arguments    : void
// Return Type  : imageDisplay
//
imageDisplay::imageDisplay()
{
  matlabCodegenIsDeleted = true;
}

//
// Arguments    : void
// Return Type  : void
//
imageDisplay::~imageDisplay()
{
  matlabCodegenDestructor();
}

//
// Arguments    : const unsigned char img[691200]
// Return Type  : void
//
void imageDisplay::image(const unsigned char img[691200])
{
  static unsigned char b_img[230400];
  static unsigned char c_img[230400];
  static unsigned char d_img[230400];
  if (isInitialized != 1) {
    isInitialized = 1;
    setupImpl();
    isSetupComplete = true;
  }
  std::copy(&img[0], &img[230400], &b_img[0]);
  std::copy(&img[230400], &img[460800], &c_img[0]);
  std::copy(&img[460800], &img[691200], &d_img[0]);
  imageDisplay::stepImpl(b_img, c_img, d_img);
}

} // namespace common
} // namespace nvidiacoder
} // namespace coder

//
// File trailer for imageDisplay.cpp
//
// [EOF]
//
