//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xzunghr.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "xzunghr.h"
#include "rt_nonfinite.h"
#include "xzungqr.h"
#include <cstring>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : int ilo
//                int ihi
//                double A[16]
//                const double tau[3]
// Return Type  : void
//
namespace coder {
namespace internal {
namespace reflapack {
void xzunghr(int ilo, int ihi, double A[16], const double tau[3])
{
  int a;
  int b_i;
  int ia;
  int nh;
  nh = ihi - ilo;
  a = ilo + 1;
  for (int j{ihi}; j >= a; j--) {
    ia = (j - 1) << 2;
    for (int i{0}; i <= j - 2; i++) {
      A[ia + i] = 0.0;
    }
    b_i = j + 1;
    for (int i{b_i}; i <= ihi; i++) {
      int i1;
      i1 = ia + i;
      A[i1 - 1] = A[i1 - 5];
    }
    b_i = ihi + 1;
    if (b_i <= 4) {
      std::memset(&A[(b_i + ia) + -1], 0,
                  static_cast<unsigned int>(((ia - b_i) - ia) + 5) *
                      sizeof(double));
    }
  }
  for (int j{0}; j < ilo; j++) {
    ia = j << 2;
    A[ia] = 0.0;
    A[ia + 1] = 0.0;
    A[ia + 2] = 0.0;
    A[ia + 3] = 0.0;
    A[ia + j] = 1.0;
  }
  b_i = ihi + 1;
  for (int j{b_i}; j < 5; j++) {
    ia = (j - 1) << 2;
    A[ia] = 0.0;
    A[ia + 1] = 0.0;
    A[ia + 2] = 0.0;
    A[ia + 3] = 0.0;
    A[(ia + j) - 1] = 1.0;
  }
  xzungqr(nh, nh, nh, A, (ilo + (ilo << 2)) + 1, tau, ilo);
}

} // namespace reflapack
} // namespace internal
} // namespace coder

//
// File trailer for xzunghr.cpp
//
// [EOF]
//
