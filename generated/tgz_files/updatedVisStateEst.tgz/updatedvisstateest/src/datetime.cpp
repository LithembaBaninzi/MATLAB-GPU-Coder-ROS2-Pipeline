//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: datetime.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "datetime.h"
#include "getLocalTime.h"
#include "plus.h"
#include "rt_nonfinite.h"
#include <cmath>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
namespace coder {
void datetime::init()
{
  double b_second;
  double c_tm_hour;
  double c_tm_min;
  double c_tm_mon;
  double check;
  double fracSecs;
  double shi;
  double slo;
  bool expl_temp;
  check = internal::b_time::getLocalTime(b_second, c_tm_min, c_tm_hour, shi,
                                         c_tm_mon, slo, expl_temp);
  fracSecs = check / 1.0E+6;
  check = (((((slo + c_tm_mon) + shi) + c_tm_hour) + c_tm_min) + b_second) +
          fracSecs;
  if ((!std::isinf(check)) && (!std::isnan(check))) {
    creal_T ahi;
    if ((c_tm_mon < 1.0) || (c_tm_mon > 12.0)) {
      check = std::floor((c_tm_mon - 1.0) / 12.0);
      slo += check;
      c_tm_mon = ((c_tm_mon - 1.0) - check * 12.0) + 1.0;
    }
    if (c_tm_mon < 3.0) {
      slo--;
      c_tm_mon += 9.0;
    } else {
      c_tm_mon -= 3.0;
    }
    c_tm_mon =
        ((((((365.0 * slo + std::floor(slo / 4.0)) - std::floor(slo / 100.0)) +
            std::floor(slo / 400.0)) +
           std::floor((153.0 * c_tm_mon + 2.0) / 5.0)) +
          shi) +
         60.0) -
        719529.0;
    if (std::abs(c_tm_mon) <= 6.69692879491417E+299) {
      check = 1.34217729E+8 * c_tm_mon;
      check -= check - c_tm_mon;
      slo = c_tm_mon - check;
    } else if ((!std::isinf(c_tm_mon)) && (!std::isnan(c_tm_mon))) {
      shi = c_tm_mon * 3.7252902984619141E-9;
      check = 1.34217729E+8 * shi;
      check -= check - shi;
      slo = shi - check;
      check *= 2.68435456E+8;
      slo *= 2.68435456E+8;
    } else {
      check = c_tm_mon;
      slo = 0.0;
    }
    shi = c_tm_mon * 8.64E+7;
    slo = slo * 8.64E+7 + (check * 8.64E+7 - shi);
    if (std::isnan(slo)) {
      slo = 0.0;
    }
    if (std::isnan(slo)) {
      slo = 0.0;
    }
    if ((fracSecs < 0.0) || (fracSecs >= 1000.0)) {
      check = std::floor(fracSecs / 1000.0);
      b_second += check;
      fracSecs -= check * 1000.0;
    }
    ahi.re = shi;
    ahi.im = slo;
    data = matlab::internal::coder::doubledouble::plus(
        matlab::internal::coder::doubledouble::plus(
            matlab::internal::coder::doubledouble::plus(
                ahi, (60.0 * c_tm_hour + c_tm_min) * 60000.0),
            b_second * 1000.0),
        fracSecs);
  } else {
    data.re = check;
    data.im = 0.0;
  }
}

} // namespace coder

//
// File trailer for datetime.cpp
//
// [EOF]
//
