//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: tFormPQRight.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "tFormPQRight.h"
#include "quat2tform.h"
#include "rt_nonfinite.h"
#include "tform2quat.h"

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : const double pq_a2b[28]
//                double pq_c2b[28]
// Return Type  : void
//
void tFormPQRight(const double pq_a2b[28], double pq_c2b[28])
{
  static const signed char iv[16]{0, -1, 0, 0, 1, 0, 0, 0,
                                  0, 0,  1, 0, 0, 0, 0, 1};
  for (int c{0}; c < 4; c++) {
    double T_a2b[16];
    double T_c2b[16];
    int T_a2b_tmp;
    int b_T_a2b_tmp;
    int c_T_a2b_tmp;
    T_a2b_tmp = 7 * c + 3;
    coder::quat2tform(&pq_a2b[T_a2b_tmp], T_a2b);
    T_a2b[12] = pq_a2b[7 * c];
    b_T_a2b_tmp = 7 * c + 1;
    T_a2b[13] = pq_a2b[b_T_a2b_tmp];
    c_T_a2b_tmp = 7 * c + 2;
    T_a2b[14] = pq_a2b[c_T_a2b_tmp];
    for (int i{0}; i < 4; i++) {
      double d;
      double d1;
      double d2;
      double d3;
      d = T_a2b[i];
      d1 = T_a2b[i + 4];
      d2 = T_a2b[i + 8];
      d3 = T_a2b[i + 12];
      for (int i1{0}; i1 < 4; i1++) {
        int i2;
        i2 = i1 << 2;
        T_c2b[i + i2] = ((d * static_cast<double>(iv[i2]) +
                          d1 * static_cast<double>(iv[i2 + 1])) +
                         d2 * static_cast<double>(iv[i2 + 2])) +
                        d3 * static_cast<double>(iv[i2 + 3]);
      }
    }
    double dv[4];
    coder::tform2quat(T_c2b, dv);
    pq_c2b[7 * c] = T_c2b[12];
    pq_c2b[b_T_a2b_tmp] = T_c2b[13];
    pq_c2b[c_T_a2b_tmp] = T_c2b[14];
    pq_c2b[T_a2b_tmp] = dv[0];
    pq_c2b[7 * c + 4] = dv[1];
    pq_c2b[7 * c + 5] = dv[2];
    pq_c2b[7 * c + 6] = dv[3];
  }
}

//
// File trailer for tFormPQRight.cpp
//
// [EOF]
//
