//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xzlartg.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "xzlartg.h"
#include "rt_nonfinite.h"
#include <cmath>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : double f
//                double g
//                double &sn
//                double &r
// Return Type  : double
//
namespace coder {
namespace internal {
namespace reflapack {
double xzlartg(double f, double g, double &sn, double &r)
{
  double cs;
  cs = std::abs(f);
  r = std::abs(g);
  if (g == 0.0) {
    cs = 1.0;
    sn = 0.0;
    r = f;
  } else if (f == 0.0) {
    cs = 0.0;
    if (g >= 0.0) {
      sn = 1.0;
    } else {
      sn = -1.0;
    }
  } else if ((cs > 1.4916681462400413E-154) && (cs < 4.7403759540545887E+153) &&
             (r > 1.4916681462400413E-154) && (r < 4.7403759540545887E+153)) {
    r = std::sqrt(f * f + g * g);
    cs /= r;
    if (!(f >= 0.0)) {
      r = -r;
    }
    sn = g / r;
  } else {
    double gs;
    double u;
    u = std::fmin(4.49423283715579E+307,
                  std::fmax(2.2250738585072014E-308, std::fmax(cs, r)));
    cs = f / u;
    gs = g / u;
    r = std::sqrt(cs * cs + gs * gs);
    cs = std::abs(cs) / r;
    if (!(f >= 0.0)) {
      r = -r;
    }
    sn = gs / r;
    r *= u;
  }
  return cs;
}

} // namespace reflapack
} // namespace internal
} // namespace coder

//
// File trailer for xzlartg.cpp
//
// [EOF]
//
