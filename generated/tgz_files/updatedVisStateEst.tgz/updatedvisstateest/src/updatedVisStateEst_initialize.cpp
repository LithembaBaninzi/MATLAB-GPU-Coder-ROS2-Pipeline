//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: updatedVisStateEst_initialize.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "updatedVisStateEst_initialize.h"
#include "CoderTimeAPI.h"
#include "pause.h"
#include "rt_nonfinite.h"
#include "updatedVisStateEst_data.h"

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void updatedVisStateEst_initialize()
{
  CoderTimeAPI::callCoderClockGettime_init();
  cpause_init();
  isInitialized_updatedVisStateEst = true;
}

//
// File trailer for updatedVisStateEst_initialize.cpp
//
// [EOF]
//
