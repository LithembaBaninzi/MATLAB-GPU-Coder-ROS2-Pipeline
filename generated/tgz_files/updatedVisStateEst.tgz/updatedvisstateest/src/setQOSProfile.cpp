//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: setQOSProfile.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "setQOSProfile.h"
#include "rt_nonfinite.h"
#include "updatedVisStateEst_data.h"
#include "updatedVisStateEst_types.h"
#include "mlros2_qos.h"
#include "rmw/qos_profiles.h"
#include "rmw/types.h"
#include <cmath>
#include <cstddef>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : rmw_qos_profile_t rmwProfile
//                double qosDepth
//                const char qosReliability[8]
//                double qosDeadline
//                double qosLifespan
//                const char qosLiveliness[9]
//                double qosLeaseDuration
//                bool qosAvoidROSNamespaceConventions
// Return Type  : rmw_qos_profile_t
//
namespace coder {
namespace ros {
namespace ros2 {
namespace internal {
rmw_qos_profile_t setQOSProfile(rmw_qos_profile_t rmwProfile, double qosDepth,
                                const char qosReliability[8],
                                double qosDeadline, double qosLifespan,
                                const char qosLiveliness[9],
                                double qosLeaseDuration,
                                bool qosAvoidROSNamespaceConventions)
{
  static const char b_cv[8]{'r', 'e', 'l', 'i', 'a', 'b', 'l', 'e'};
  rmw_qos_liveliness_policy_t liveliness;
  rmw_qos_reliability_policy_t reliability;
  struct_T deadline;
  struct_T lifespan;
  struct_T liveliness_lease_duration;
  double sec;
  int k;
  char b_s[9];
  char s[8];
  char c;
  bool exitg1;
  bool p;
  for (k = 0; k < 8; k++) {
    c = qosReliability[k];
    s[k] = c;
    if ((c >= 'A') && (c <= 'Z')) {
      s[k] = static_cast<char>(static_cast<unsigned int>(c) + 32U);
    }
  }
  p = true;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 8)) {
    if (s[k] != b_cv[k]) {
      p = false;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (p) {
    reliability = RMW_QOS_POLICY_RELIABILITY_RELIABLE;
  } else {
    reliability = RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT;
  }
  for (k = 0; k < 9; k++) {
    c = qosLiveliness[k];
    b_s[k] = c;
    if ((c >= 'A') && (c <= 'Z')) {
      b_s[k] = static_cast<char>(static_cast<unsigned int>(c) + 32U);
    }
  }
  p = true;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 9)) {
    if (b_s[k] != cv[k]) {
      p = false;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (p) {
    liveliness = RMW_QOS_POLICY_LIVELINESS_AUTOMATIC;
  } else {
    liveliness = RMW_QOS_POLICY_LIVELINESS_MANUAL_BY_TOPIC;
  }
  sec = std::floor(qosDeadline);
  deadline.nsec = (qosDeadline - sec) * 1.0E+9;
  deadline.sec = sec;
  sec = std::floor(qosLifespan);
  lifespan.nsec = (qosLifespan - sec) * 1.0E+9;
  lifespan.sec = sec;
  sec = std::floor(qosLeaseDuration);
  liveliness_lease_duration.nsec = (qosLeaseDuration - sec) * 1.0E+9;
  liveliness_lease_duration.sec = sec;
  SET_QOS_VALUES(rmwProfile, RMW_QOS_POLICY_HISTORY_KEEP_LAST, (size_t)qosDepth,
                 RMW_QOS_POLICY_DURABILITY_VOLATILE, reliability, deadline,
                 lifespan, liveliness, liveliness_lease_duration,
                 (bool)qosAvoidROSNamespaceConventions);
  return rmwProfile;
}

} // namespace internal
} // namespace ros2
} // namespace ros
} // namespace coder

//
// File trailer for setQOSProfile.cpp
//
// [EOF]
//
