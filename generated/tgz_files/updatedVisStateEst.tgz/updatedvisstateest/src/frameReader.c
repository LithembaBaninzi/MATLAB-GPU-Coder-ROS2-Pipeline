/* Copyright 2019-2023 The MathWorks, Inc. */
#include "frameReader.h"

/* Store media type available in the file */
MW_mediaType mediaType;

/* Find the availability of the Gstreamer feature */
int findGstFeature (char* featureName)
{
    int ret = 0;
    GstPluginFeature *feature;
    feature = gst_registry_lookup_feature (gst_registry_get (), featureName);
    if (!feature)
    {
        ret = 0;
    }
    else
    {
        ret = 1;
        gst_object_unref (feature);
    }
    return ret;
}

/* Terminate media streaming and deallocate all memory */
int EXT_gstreamerMediaTerminate (MW_customData *data)
{
  int refcount = 0;
  if(data->bus)
  {
    refcount = GST_OBJECT_REFCOUNT_VALUE(data->bus);
    for (int i=0;i<refcount-1;i++)
    gst_object_unref (data->bus);
  }
  
  if(data->pipeline)
  {
    gst_element_set_state (data->pipeline, GST_STATE_NULL);
    gst_object_unref (data->pipeline);
  }
  
  return 0;
}

/* Handling specified resolution and input video resolution mismatch */
void resolutionMismatch (double reqWidth, double reqHeight, double actualWidth, double actualHeight) 
{
  if ((reqWidth != actualWidth) && (reqHeight != actualHeight))
  { 
    printf("Width of the input video is %d but the specified ‘Width’ value is %d. ‘Width’ value must match the width of the input video.\n", (int)actualWidth, (int)reqWidth);
    printf("Height of the input video is %d but the specified ‘Height’ value is %d. ‘Height’ value must match the height of the input video.\n", (int)actualHeight, (int)reqHeight);
  }
  else if (reqWidth != actualWidth)
  {
    printf("Width of the input video is %d but the specified ‘Width’ value is %d. ‘Width’ value must match the width of the input video.\n", (int)actualWidth, (int)reqWidth);
  }
  else 
  {
    printf("Height of the input video is %d but the specified ‘Height’ value is %d. ‘Height’ value must match the height of the input video.\n", (int)actualHeight, (int)reqHeight);
  }
}

/* Path and Name properties */
int getPathAndName (char* fullname, char* path, char* name)
{
  char *dirc, *basec, *locPath, *locName;

  dirc = strdup(fullname);
  basec = strdup(fullname);
  /* Get path of the file */
  locPath = dirname(dirc);

  /* Get name of the file */
  locName = basename(basec);

  int pathLength = 1;
  int nameLength = 1;

  pathLength = strlen(locPath);
  nameLength = strlen(locName);

  /* Copy path and name */
  memcpy(path, locPath, pathLength);
  memcpy(name, locName, nameLength);

  path[pathLength] = '\0';
  name[nameLength] = '\0';

  return 0;
}

char setGstPipelineStatus (MW_customData* data, GstState state, GstClockTime waitTime)
{
  GstStateChangeReturn ret;
  ret = gst_element_set_state(data->pipeline, state);

  switch(ret)
  {
    case GST_STATE_CHANGE_FAILURE: 
      MW_ERROR("Gstreamer pipeline state change failed \n");
      return -1;
      break;
    case GST_STATE_CHANGE_ASYNC:
      break;
    case GST_STATE_CHANGE_NO_PREROLL:
      return -1;
      break;
    default:
      /* Pipeline state change is successful */
      break;
  }
  
  /* Verify that the state change to the desired state has completed successfully */ 
  ret = gst_element_get_state (data->pipeline, NULL, NULL, waitTime);
  if( (ret == GST_STATE_CHANGE_FAILURE) || (ret == GST_STATE_CHANGE_NO_PREROLL) )
  {
      return -1;
  }
  
  return 0;
}

static void checkBusMessages_callback (GstBus *bus, GstMessage *msg, MW_customData *data) 
{

  switch (GST_MESSAGE_TYPE (msg)) 
  {
    case GST_MESSAGE_ERROR: {
			      GError *err;
			      gchar *debug;
			      gst_message_parse_error (msg, &err, &debug);
			      g_print ("Error: %s\n", err->message);
			      g_error_free (err);
			      g_free (debug);
			      break;
			    }
    default:
			    /* Unhandled message */
			    break;
  }
}

/* Check for any messages of bus when encountered an error*/
int checkBusMessages (GstBus *bus)
{
    bool resourceBusy = false;
    bool streamError = false;
    int ret = 0;
    ret = MW_GST_ERR_OTHER;
    GstMessage *msg = NULL;
    do
    {
        msg = gst_bus_pop(bus);
        if(msg == NULL)
        {
            break;
        }
        
        switch (GST_MESSAGE_TYPE (msg))
        {
            case GST_MESSAGE_ERROR: {
                GError *err;
                gchar *debug;
                gst_message_parse_error (msg, &err, &debug);
                g_print ("Error: %s\n", err->message);
                
                /* USB (V4L2) cameras  are treated as resources */
                if ((err->domain == gst_resource_error_quark()) && (err->code==GST_RESOURCE_ERROR_BUSY))
                {
                    resourceBusy = true;
                    ret = MW_GST_ERR_RESOURCE_BUSY;
                }
                g_error_free (err);
                g_free (debug);
                break;
            }
            default:
                /* Not an error case */
                break;
        }
        gst_message_unref(msg);
    }
    while (msg != NULL);
    
    /* Find if the error is because resource busy */
    if (resourceBusy || streamError)
    {
        ret = MW_GST_ERR_RESOURCE_BUSY;
    }
    
    return ret;
}

static void onPadAddedDecode (GstElement *element, GstPad *pad, gpointer data)
{
  GstPad *sinkpad;
  GstElement *decoder = (GstElement *) data;

  /* We can now link this pad with the decoder sink pad */
  sinkpad 			=  gst_element_get_static_pad (decoder, "sink");
  GstCaps *caps		=  gst_pad_query_caps (pad, NULL);
  GstStructure *str =  gst_caps_get_structure (caps, 0);
  const gchar *type = gst_structure_get_name (str);

  if (!g_strrstr (type, "video")) 
  {
    gst_caps_unref (caps);
    gst_object_unref (sinkpad);
    return;
  }

  gst_caps_unref (caps);
  gst_pad_link (pad, sinkpad);
  gst_object_unref (sinkpad);
}

static void autoPlugSelect (
                            GstElement *decoder,
                            GstPad *pad, GstCaps *caps,
                            GstElementFactory *factory,
                            gpointer udata
                            )
{
  GstStructure *str    =  gst_caps_get_structure (caps, 0);
  const gchar *type    =  gst_structure_get_name (str);
  
  if (g_strrstr(type,"video"))
  {
      mediaType.hasVideo = true;
  }
  else if (g_strrstr(type,"image"))
  {
      mediaType.isImage = true;
  }

}

char checkFile (const char *fileName)
{
  if (!fileName)
  {
    return -1;
  }
  else
  {
    if(access(fileName, F_OK ))
    {
      MW_ERROR("Video file is not available. \n");
      return -1;
    }
    if(access(fileName, R_OK ))
    {
      MW_ERROR("Video file is not readable. \n");
      return -1;
    }
  }

  return 0;
}

/* Initialize the video pipeline */
int initializeVideoPipeline (
                              MW_customData *data,          /* Input: Gst elements structure                            */
                              const char *fileName,         /* Input: File name of the media                            */
                              const unsigned int camWidth,  /* Input: Set frame width of the Camera                     */
                              const unsigned int camHeight, /* Input: Set frame height of the Camera                    */
                              MW_nvcamProps* prop,          /* Input: Properties structure                              */
                              double sampleTime,            /* Input: Framerate (1/sampleTime)                          */ 
                              int frameFormat               /* Input: Frame format to select from the video device      */
                              )
{
    
  /* Create a pipeline */
  data->pipeline = gst_pipeline_new ("pipeline");
  if (!data->pipeline)
  {
    MW_ERROR("Error: Creating 'pipeline'  element.\n");
    return MW_GST_ERR_CREATEPIPELINE;
  }

  /* Get bus from the pipeline  */
  data->bus = gst_pipeline_get_bus (GST_PIPELINE (data->pipeline));
  gst_bus_add_signal_watch (data->bus);
  
  /* Add a callback to check for any messages in the pipeline */
  g_signal_connect (data->bus, "message", G_CALLBACK (checkBusMessages_callback), data);

  /* Create capsfilter element */
  data->filter = gst_element_factory_make(_filter, NULL);
  if (!data->filter)
  {
    MW_ERROR("Error: Creating 'capsfilter'  element.\n");
    return MW_GST_ERR_CREATECAPSFILTER;
  }

  /* Create videoconvert element */
  data->convert = gst_element_factory_make ("videoconvert", NULL);
  if (!data->convert)
  {
    MW_ERROR("Error: Creating 'videoconvert'  element.\n");
    return MW_GST_ERR_CREATECONVERT;
  }

  /* Create appsnk element */
  data->appsink = gst_element_factory_make ("appsink", NULL);
  if (!data->appsink)
  {
    MW_ERROR("Error: Creating 'appsink'  element.\n");
    return MW_GST_ERR_CREATEAPPSINK;
  }

  /* Set filter capabilities */
  GstCaps *formatcaps;
  char capsStr[1024] = {0};

  if (data->isLiveSource) /* Live sources */
  {
    /* Set buffer queue */
    gst_app_sink_set_max_buffers((GstAppSink *) data->appsink, 2);
    gst_app_sink_set_drop ((GstAppSink *) data->appsink, TRUE);
    
    /* Create a filesrc element to read from the file source, valid for the video file reader */
    if ( !prop->isV4l2Device ) /* CSI cameras */
    {
      if( (camWidth % 2 != 0) || (camHeight % 2 != 0))
      {
        MW_ERROR("Resolution size must be even values.\n");
        return MW_GST_CSI_CAMERA_ODD_RES;
      }
      
      /* JetPack > 3.3 didn't have "nvcamerasrc" Gstreamer plugin/feature */
      char gstSrcElement[32] = "nvcamerasrc";
      if (!findGstFeature(gstSrcElement))
      {
          strcpy(gstSrcElement, "nvarguscamerasrc");
      }
      
      GstCaps *formatcaps2,*formatcaps3;
      data->src  = gst_element_factory_make (gstSrcElement,NULL);
      data->filter2 = gst_element_factory_make(_filter,NULL);
      data->filter3 = gst_element_factory_make(_filter,NULL);
      if (!data->src)
      {
        MW_ERROR_ARGS("Error: Creating '%s'  element.\n",gstSrcElement);
        return MW_GST_ERR_CREATESRC;
      }

      /* Create decodebin element */
      data->decoder  = gst_element_factory_make ("nvvidconv", NULL);
      if (!data->decoder)
      {
        MW_ERROR("Error: Creating 'nvvidconv'  element.\n");
        return MW_GST_ERR_CREATEDEC;
      }
      
      unsigned char sensorid = 0;
      /* Include the getSensorID function only for camera deployments.*/
      #ifdef _CAMERA_DEP_
        sensorid = getSensorID(prop->id);
      #endif
      /* Set the sensor id */
      g_object_set(G_OBJECT(data->src), "sensor-id", sensorid, NULL);

      if(sampleTime) /* SIMULINK */
      {
        sprintf (capsStr,"video/x-raw(memory:NVMM), width=(int)%d, height=(int)%d, format=(string)NV12, framerate=(fraction)%d/1",camWidth,camHeight,(int)(1/sampleTime));
      }
      else /* MATLAB*/
      {
          sprintf (capsStr,"video/x-raw(memory:NVMM), width=(int)%d, height=(int)%d, format=(string)NV12",camWidth,camHeight);
      }
      
      /* Set the filter capabilities */
	  formatcaps = gst_caps_from_string (capsStr);
      formatcaps2 = gst_caps_new_simple("video/x-raw",
	  "format", G_TYPE_STRING, "BGRx",
	  "width", G_TYPE_INT, camWidth,
	  "height", G_TYPE_INT, camHeight,				
	   NULL);
      formatcaps3 = gst_caps_new_simple("video/x-raw",
	  "format", G_TYPE_STRING, "RGB",NULL);
      g_object_set(G_OBJECT(data->filter), "caps", formatcaps, NULL);
      g_object_set(G_OBJECT(data->filter2), "caps", formatcaps2, NULL);
      g_object_set(G_OBJECT(data->filter3), "caps", formatcaps3, NULL);
      gst_caps_unref(formatcaps);
      gst_caps_unref(formatcaps2);
      gst_caps_unref(formatcaps3);

      /* Add Gstreamer elements to the pipeline */
      gst_bin_add_many (GST_BIN (data->pipeline), data->src, data->filter, data->decoder, data->filter2, data->convert, data->filter3, data->appsink, NULL);
      if (!gst_element_link_many(data->src, data->filter, data->decoder, data->filter2, data->convert, data->filter3, data->appsink, NULL)) 
      {
        MW_ERROR ("Failed to link one or more elements!\n");
        return MW_GST_ERR_ELEMENTLINK;
      }
    }
    else /* USB cameras */
    {
        data->src  = gst_element_factory_make ("v4l2src",NULL);
        if (!data->src)
        {
            MW_ERROR("Error: Creating 'v4l2src'  element.\n");
            return MW_GST_ERR_CREATESRC;
        }
        char deviceName[32] = {0};
        sprintf(deviceName,"/dev/video%d", prop->id);
        g_object_set(G_OBJECT(data->src), "device", deviceName, NULL);
        
        /* Frame rate in fractions must provided as numerator and denominator */
        double locFrameRate;
        int numerator;
        int denominator = 1;
        if (sampleTime)
        {
            locFrameRate = 1/sampleTime;
            numerator = locFrameRate*10.0;
            denominator = 1;
            locFrameRate = numerator/10.0;
            if ((roundf(locFrameRate)-locFrameRate) == 0.5)
            {
                numerator = locFrameRate * 10;
                denominator = 10;
            }
            else
            {
                numerator = (int) locFrameRate;
                denominator = 1;
            }
        }
        switch (frameFormat)
        {
            GstCaps *formatcaps2;
	    
            case GST_MAKE_FOURCC ('M', 'J', 'P', 'G'):	
                if (sampleTime)
                {
                    formatcaps = gst_caps_new_simple("image/jpeg",
                                                     "width", G_TYPE_INT,camWidth,
                                                     "height", G_TYPE_INT,camHeight,
                                                     "framerate", GST_TYPE_FRACTION, numerator, denominator,
                                                     NULL);
                }
                else
                {
                    formatcaps = gst_caps_new_simple("image/jpeg",
                                                      "width", G_TYPE_INT,camWidth,
                                                      "height", G_TYPE_INT,camHeight,
                                                       NULL);
                }
                formatcaps2 = gst_caps_new_simple("video/x-raw",
                                                  "format", G_TYPE_STRING,"RGB",
                                                   NULL);
                data->jpegparse  = gst_element_factory_make ("jpegparse",NULL);
                if (!data->jpegparse)
                {
                    MW_ERROR("Error: Creating 'jpegparse'  element.\n");
                     return MW_GST_ERR_CREATEJPEGPARSE;
                }
                data->jpegdec  = gst_element_factory_make ("jpegdec",NULL);
                if (!data->jpegdec)
                {
                    MW_ERROR("Error: Creating 'jpegdec'  element.\n");
                    return MW_GST_ERR_CREATEJPEGDEC;
                }
                data->filter2 = gst_element_factory_make(_filter,NULL);
                g_object_set(G_OBJECT(data->filter), "caps", formatcaps, NULL);
                gst_caps_unref(formatcaps);
                g_object_set(G_OBJECT(data->filter2), "caps", formatcaps2, NULL);
                gst_caps_unref(formatcaps2);
                /* Link the elements in the pipeline */
                gst_bin_add_many (GST_BIN (data->pipeline), data->src, data->filter, data->jpegparse, data->jpegdec, data->convert , data->filter2, data->appsink, NULL);
                if (!gst_element_link_many(data->src, data->filter, data->jpegparse, data->jpegdec, data->convert, data->filter2, data->appsink, NULL))
                {
                    MW_ERROR ("Failed to link one or more elements!\n");
                    return MW_GST_ERR_ELEMENTLINK;
                }
                break;
            default:
                if (sampleTime)
                {
                    formatcaps = gst_caps_new_simple("video/x-raw",
                                                     "format", G_TYPE_STRING,"RGB",
                                                     "width", G_TYPE_INT,camWidth,
                                                     "height", G_TYPE_INT,camHeight,
                                                     "framerate", GST_TYPE_FRACTION, numerator, denominator,
                                                     NULL);
                }
                else
                {
                    formatcaps = gst_caps_new_simple("video/x-raw",
                                                     "format", G_TYPE_STRING,"RGB",
                                                     "width", G_TYPE_INT,camWidth,
                                                     "height", G_TYPE_INT,camHeight,
                                                      NULL);
                }
		char pixelFormat[8] = {0};

		memcpy(pixelFormat, &frameFormat, 4);
		data->filter2 = gst_element_factory_make(_filter,NULL);
		GstVideoFormat videofmt;
		videofmt = gst_video_format_from_fourcc (frameFormat);
		if (videofmt)
		{
		   /* FOURCC format is recognized by the GStreamer */
 	           sprintf (capsStr,"video/x-raw, format=(string)%s, width=(int)%d, height=(int)%d",pixelFormat, camWidth, camHeight);
		}
		else
		{
		   sprintf (capsStr,"video/x-raw, width=(int)%d, height=(int)%d", camWidth, camHeight);
		}
		formatcaps2 = gst_caps_from_string (capsStr);
		
                g_object_set(G_OBJECT(data->filter), "caps", formatcaps, NULL);
                g_object_set(G_OBJECT(data->filter2), "caps", formatcaps2, NULL);
                gst_caps_unref(formatcaps);
                gst_caps_unref(formatcaps2);
                
                /* Link the elements in the pipeline */
                gst_bin_add_many (GST_BIN (data->pipeline), data->src,data->filter2,  data->filter, data->convert , data->appsink, NULL);
                if (!gst_element_link_many(data->src, data->filter2, data->convert, data->filter, data->appsink, NULL))
                {
                    MW_ERROR ("Failed to link one or more elements!\n");
                    return MW_GST_ERR_ELEMENTLINK;
                }
        }
    }
  }
  else /* Recorded media */
  {
    /* Create a filesrc element to read from the file source, valid for the video file reader */
    data->src  = gst_element_factory_make ("filesrc",NULL);
    if (!data->src)
    {
      MW_ERROR("Error: Creating 'filesrc'  element.\n");
      return MW_GST_ERR_CREATESRC;
    }

    /* Set location property of the filesrc element */
    g_object_set (G_OBJECT (data->src), "location", fileName, NULL);

    /* Create decodebin element */
    data->decoder  = gst_element_factory_make ("decodebin", NULL);
    if (!data->decoder)
    {
      MW_ERROR("Error: Creating 'decodebin'  element.\n");
      return MW_GST_ERR_CREATEDEC;
    }
    
    /* Callback to find the file type */
    g_signal_connect (data->decoder, "autoplug-select", G_CALLBACK (autoPlugSelect), data);
    
    /* Set the filter capabilities */
    formatcaps = gst_caps_new_simple ("video/x-raw", "format", G_TYPE_STRING, "RGB", NULL);
    g_object_set (G_OBJECT(data->filter), "caps", formatcaps, NULL);
    gst_caps_unref(formatcaps);
    
    int isFeatureAvailable = 0;
    /* DRIVE PX2 boards had older version of Gstreamer 1.8.2 which doesn't 
     have few Gstreamer plugins. Making video pipeline without this
     plugin.*/
    isFeatureAvailable = findGstFeature("nvvidconv");
    
    if (isFeatureAvailable)
    {
      /* Create decodebin element */
      data->decoder2  = gst_element_factory_make ("nvvidconv", NULL);
      if (!data->decoder2)
      {
        MW_ERROR("Error: Creating 'nvvidconv'  element.\n");
        return MW_GST_ERR_CREATEDEC;
      }
    
      /* Connect the sink pad when decoder completes the operation */  
      g_signal_connect (data->decoder, "pad-added", G_CALLBACK (onPadAddedDecode), data->decoder2);
    
      /* Add Gstreamer elements to the pipeline */
      gst_bin_add_many (GST_BIN (data->pipeline), data->src, data->convert, data->decoder, data->decoder2, data->filter,data->appsink, NULL);
     }
    else /* Pipeline without using nvvidconv */
     {
       /* Connect the sink pad when decoder completes the operation */  
       g_signal_connect (data->decoder, "pad-added", G_CALLBACK (onPadAddedDecode), data->convert);
    
       /* Add Gstreamer elements to the pipeline */
       gst_bin_add_many (GST_BIN (data->pipeline), data->src, data->convert, data->decoder, data->filter,data->appsink, NULL);
     }
  
    /* Link elements in Gstreamer pipeline */
    if (!gst_element_link(data->src,data->decoder))
    {
      MW_ERROR("Failed to link one or more elements!\n");
      return MW_GST_ERR_ELEMENTLINK;
    }
    
    if (isFeatureAvailable)
    {
        /* Link elements in Gstreamer pipeline */
        if (!gst_element_link_many(data->decoder2, data->convert, data->filter, data->appsink, NULL))
        {
            MW_ERROR ("Failed to link one or more elements!\n");
            return MW_GST_ERR_ELEMENTLINK;
        }
    }
    else
    {
        /* Link elements in Gstreamer pipeline */
        if (!gst_element_link_many(data->convert, data->filter, data->appsink, NULL))
        {
            MW_ERROR ("Failed to link one or more elements!\n");
            return MW_GST_ERR_ELEMENTLINK;
        }
    }
  }

  /* Change the pipeline status to playing */
  if (setGstPipelineStatus(data, GST_STATE_PLAYING, MW_GST_STATE_CHANGE_TIMEOUT))
  {
    return MW_GST_ERR_STATECHANGE;
  }
  return MW_GST_FLOW_OK;
}

int getVideoProps (MW_customData *data)
{
  /* Get the properties of the video */ 
  gint frameRate1 = 0,frameRate2 = 0, w = 0, h = 0;
  gint64 durationX = 0.0;

  data->sample = gst_app_sink_pull_sample((GstAppSink*)data->appsink);
  if(data->sample == NULL)
  {
    MW_ERROR("Error: Getting samples from the pipeline.\n");
    return MW_GST_ERR_SAMPLE_SEEK;
  }

  data->caps = gst_sample_get_caps (data->sample);
  if(data->caps == NULL)
  {
    MW_ERROR("Error: Getting caps from the sample.\n");
    return MW_GST_ERR_CAPS;
  }

  data->props = gst_caps_get_structure (data->caps, 0);
  if(data->props == NULL)
  {
    MW_ERROR("Error: Getting samples from the pipeline.\n");
    return MW_GST_ERR_GET_VIDEO_PROPS;
  }  
  /* Width and Height */
  gst_structure_get_int (data->props, "width", &w);
  gst_structure_get_int (data->props, "height", &h);
  data->videoProps.width = (double) w;
  data->videoProps.height = (double) h;

  /* Frame rate */
  gst_structure_get_fraction (data->props, "framerate", &frameRate1, &frameRate2);
  data->videoProps.frameRate = (float) frameRate1/frameRate2; 

  if (!data->isLiveSource)
  {
    double duration = 0.0;
    gst_element_query_duration (data->pipeline, GST_FORMAT_TIME, &durationX);
    duration = GST_TIME_AS_MSECONDS(durationX);
    duration = duration/1000.0;
    data->videoProps.duration = duration;      
  }

  /* Delete reference for sample */
  gst_sample_unref (data->sample);
  if ( !data->isLiveSource )
  {
      /* Restart the pipeline */
      if (setGstPipelineStatus(data, GST_STATE_NULL, MW_GST_STATE_CHANGE_TIMEOUT))
      {
          return MW_GST_ERR_STATECHANGE;
      }
  }
  return MW_GST_FLOW_OK;
}

/* Seek to a specified time */
int seekToTime ( MW_customData *data, double currTime )
{
  gint64 seekTime = (gint64) ((currTime) * pow(10, 9));
  if (currTime >= data->videoProps.duration)
  {
    MW_ERROR("‘CurrentTime’ value must be less than the duration of the video.\n");
    setGstPipelineStatus (data, GST_STATE_NULL, MW_GST_STATE_CHANGE_TIMEOUT);
    return -1;
  }
  else if (!gst_element_seek (data->pipeline, 1.0, GST_FORMAT_TIME, GST_SEEK_FLAG_FLUSH, GST_SEEK_TYPE_SET, seekTime, GST_SEEK_TYPE_NONE, GST_CLOCK_TIME_NONE)) 
  {
    MW_ERROR ("Seek failed!\n");
    return -1;
  }
  return 0;
}

/* Initialize data*/
void initializeData (MW_customData *data, bool isLiveSource)
{
  mediaType.hasVideo = false;
  mediaType.isImage = true;

  /* Initialize video properties */
  data->isLiveSource =  isLiveSource;

  /* Initialize video properties */
  data->videoProps.width	    =  0.0;
  data->videoProps.height      =  0.0;
  data->videoProps.frameRate   =  0.0;
  data->videoProps.duration 	=  0.0;
}

/* Initialize gstreamer pipeline */
int EXT_gstreamerMediaInit (
                             MW_customData *data,          /* Input: Gst variables structure              */
                             const char *fileName,         /* Input: File name of the media               */
                             double *width,                /* Output: Width of the frame (R)              */
                             double *height,               /* Output: Height of the frame (R)             */
                             const unsigned int camWidth,  /* Input: Frame width to be set (RW)           */
                             const unsigned int camHeight, /* Input: Frame Height to be set (RW)          */
                             double *duration,             /* Output: Duration of the Video (R)           */
                             double  currTime,             /* Input: Current time (RW)                    */
                             double *frameRate,            /* Output: Frame rate of video stream (R)      */
                             int id,                       /* Input: Camera sensor ID                     */
                             bool isLiveSource,            /* Input: Live source or recorded media        */
                             int cameraDevice,             /* Input: Interface type CSI, V4L2 etc.        */
                             bool isGPCTGT,                /* Input: Connected I/O mode or targeting mode */
                             double sampleTime,            /* Input: framerate (1/SampleTime)		  */
                             int frameFormat               /* Input: Frame format of the video device 	  */
                            )
{

  /* Initialize default values for the variables */
  initializeData (data, isLiveSource);

  /* Validating video file name */
  if (!data->isLiveSource && checkFile(fileName))
  {
    fprintf (stderr, "Error opening video file %s.\n", fileName);
    return MW_GST_ERR_FILE;
  } 

  /* Initialize Gstreamer libraries */
  gst_init (NULL,NULL);

  /* Set camera properties */
  MW_nvcamProps prop;
  prop.id = id;
  prop.isV4l2Device = cameraDevice;

  /* Initialize Gstreamer video pipeline */
  int initVideoStatus = MW_GST_FLOW_OK;
  initVideoStatus = initializeVideoPipeline (data, fileName, camWidth, camHeight, &prop,sampleTime, frameFormat);
  int busret = 0;
  
  /* Check for any errors on the bus */
  switch (initVideoStatus)
  {
      case MW_GST_ERR_STATECHANGE:
          busret = checkBusMessages(data->bus);
          if (busret)
          {
              return busret;
          }
          break;
      case MW_GST_FLOW_OK:
          break;
      default:
          return initVideoStatus;
  }
  /* Check whether the file has valid media data or not */
  if(!mediaType.hasVideo && (! data->isLiveSource))
  {
    GstStateChangeReturn ret;
    ret = gst_element_get_state (data->decoder, NULL, NULL, GST_SECOND);
    if( (ret == GST_STATE_CHANGE_FAILURE) || (ret == GST_STATE_CHANGE_NO_PREROLL) )
    {
      fprintf (stderr, "Invalid file type. %s must be a valid media file.\n", fileName);
      return MW_GST_ERR_NO_MEDIA;
    }
  }

  if( initVideoStatus )
  {    
    return initVideoStatus;
  }

  /* Error out on an image file */
  if ( (mediaType.isImage) && (!mediaType.hasVideo) && !data->isLiveSource)
  {
    fprintf(stderr, "Invalid file type. %s is not a valid video file.\n", fileName);
    return MW_GST_ERR_NO_MEDIA;
  }

  /* Get video properties */
  initVideoStatus = getVideoProps (data);

  if(initVideoStatus)
  {    
    return initVideoStatus;
  }

  /* Copy video properties */
  *width 	 =  data->videoProps.width;
  *height 	 =  data->videoProps.height;
  *frameRate =  data->videoProps.frameRate;
  *duration  =  data->videoProps.duration;

  if (setGstPipelineStatus(data, GST_STATE_PLAYING, MW_GST_STATE_CHANGE_TIMEOUT))
  {
    return MW_GST_ERR_STATECHANGE;
  }

  /* Start video from a specific position */ 
  if ( (!data->isLiveSource) && currTime)
  {
    if(seekToTime(data, currTime) < 0)
    {
      return MW_GST_ERR_SEEK;
    }
  }

  return MW_GST_FLOW_OK;
}

/* Convert packed RGB data to planar RGB */
void convertRGBToPlanar (
                         unsigned char* img,
                         unsigned char* pln0,
                         unsigned char* pln1,
                         unsigned char* pln2,
                         int width,
                         int height
                        )
{
  for (int i = 0; i < (height * width); i++) 
  {
    *pln0++ = *img++;
    *pln1++ = *img++;
    *pln2++ = *img++;
  }
}

/* Read frame from pipeline */
int EXT_gstreamerFrameRead (
                             MW_customData *data, /* Input:Gst element structure */
                             double width,        /* Input: Width of the frame */
                             double height,       /* Input: Height of the frame */
                             double currTime,     /* Input: Seek position (in sec) */
                             double *ctime,       /* Output:Current time of the frame (in sec) */
                             unsigned char* pln0, /* Output: Image R plane */
                             unsigned char* pln1, /* Output: Image G plane */
                             unsigned char* pln2  /* Output: Image B plane */
                            )
{

  static double FrCurrTime = 0.0;
 
  if( (FrCurrTime != currTime) && (!data->isLiveSource))
  {
    if(seekToTime(data, currTime) < 0)
    {
      return MW_GST_ERR_SEEK;
    }
  }

  /* Check for end of stream (EOS) of a video sequence */
  if ( gst_app_sink_is_eos((GstAppSink*)data->appsink) )
  {
    return MW_GST_EOS;
  }

  /* Pull sample from the video pipeline */
  data->sample = gst_app_sink_pull_sample((GstAppSink*)data->appsink);
  if(data->sample == NULL)
  {
    MW_ERROR("Error: Getting samples from the pipeline.\n");
    return MW_GST_ERR_SAMPLE_SEEK;
  }

  /* Get frame time stamp */
  gint64 timeStamp;
  gst_element_query_position (data->pipeline, GST_FORMAT_TIME, &timeStamp);
  *ctime = (double) GST_TIME_AS_MSECONDS(timeStamp)/1000;
  FrCurrTime = *ctime;

  /* Get the buffers associated with the sample */
  data->buffer = gst_sample_get_buffer (data->sample);
  if(data->buffer == NULL)
  {
    MW_ERROR("Error: Getting data buffers from the sample.\n");
    return MW_GST_ERR_SAMPLE_BUFFER;
  }

  /* Map the buffer to the frame data */
  if(!gst_buffer_map(data->buffer, &data->map, GST_MAP_READ))
  {
    MW_ERROR("Error: Mapping data buffers to the frame data.\n");
    return MW_GST_ERR_SAMPLE_BUFFER_MAP;
  }
  
  convertRGBToPlanar (data->map.data, pln0, pln1, pln2, width, height);
  gst_buffer_unmap (data->buffer, &data->map);
  gst_sample_unref (data->sample);

  return MW_GST_FLOW_OK;
}

/* LocalWords:  capsfilter videoconvert appsnk appsink filesrc nvcamerasrc
 * LocalWords:  decodebin nvvidconv capabilities framerate Gstreamer autoplug
 * LocalWords:  gstreamer Gst EOS
 */
