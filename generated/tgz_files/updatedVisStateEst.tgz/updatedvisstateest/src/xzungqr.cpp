//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xzungqr.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "xzungqr.h"
#include "rt_nonfinite.h"
#include "xzlarf.h"
#include <cstring>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : int m
//                int n
//                int k
//                double A[16]
//                int ia0
//                const double tau[3]
//                int itau0
// Return Type  : void
//
namespace coder {
namespace internal {
namespace reflapack {
void xzungqr(int m, int n, int k, double A[16], int ia0, const double tau[3],
             int itau0)
{
  if (n >= 1) {
    double work[4];
    int ia;
    int itau;
    int j;
    for (j = k; j < n; j++) {
      ia = (ia0 + (j << 2)) - 1;
      if (m - 1 >= 0) {
        std::memset(&A[ia], 0, static_cast<unsigned int>(m) * sizeof(double));
      }
      A[ia + j] = 1.0;
    }
    itau = (itau0 + k) - 2;
    work[0] = 0.0;
    work[1] = 0.0;
    work[2] = 0.0;
    work[3] = 0.0;
    for (int i{k}; i >= 1; i--) {
      int iaii;
      iaii = ((ia0 + i) + ((i - 1) << 2)) - 2;
      if (i < n) {
        A[iaii] = 1.0;
        xzlarf((m - i) + 1, n - i, iaii + 1, tau[itau], A, iaii + 5, work);
      }
      if (i < m) {
        ia = iaii + 2;
        j = (iaii + m) - i;
        for (int b_k{ia}; b_k <= j + 1; b_k++) {
          A[b_k - 1] *= -tau[itau];
        }
      }
      A[iaii] = 1.0 - tau[itau];
      for (j = 0; j <= i - 2; j++) {
        A[(iaii - j) - 1] = 0.0;
      }
      itau--;
    }
  }
}

} // namespace reflapack
} // namespace internal
} // namespace coder

//
// File trailer for xzungqr.cpp
//
// [EOF]
//
