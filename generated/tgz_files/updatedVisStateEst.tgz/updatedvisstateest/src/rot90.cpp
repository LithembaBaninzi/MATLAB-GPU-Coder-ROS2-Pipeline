//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: rot90.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "rot90.h"
#include "rt_nonfinite.h"

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : const unsigned char A[691200]
//                unsigned char B[691200]
// Return Type  : void
//
namespace coder {
void rot90(const unsigned char A[691200], unsigned char B[691200])
{
  for (int p{0}; p < 3; p++) {
    for (int j{0}; j < 640; j++) {
      for (int i{0}; i < 360; i++) {
        B[(i + 360 * j) + 230400 * p] =
            A[((360 * (639 - j) - i) + 230400 * p) + 359];
      }
    }
  }
}

} // namespace coder

//
// File trailer for rot90.cpp
//
// [EOF]
//
