//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: updatedVisStateEst_data.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "updatedVisStateEst_data.h"
#include "rt_nonfinite.h"

// Custom Source Code
#include "nanoP3p.h"
// Variable Definitions
double freq;

bool freq_not_empty;

const char cv[9]{'a', 'u', 't', 'o', 'm', 'a', 't', 'i', 'c'};

bool isInitialized_updatedVisStateEst{false};

//
// File trailer for updatedVisStateEst_data.cpp
//
// [EOF]
//
