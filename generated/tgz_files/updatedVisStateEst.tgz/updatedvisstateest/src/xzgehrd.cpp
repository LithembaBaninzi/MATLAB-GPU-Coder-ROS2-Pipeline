//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xzgehrd.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "xzgehrd.h"
#include "rt_nonfinite.h"
#include "xzlarf.h"
#include "xzlarfg.h"
#include <cstring>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : double a[16]
//                int ilo
//                int ihi
//                double tau[3]
// Return Type  : void
//
namespace coder {
namespace internal {
namespace reflapack {
void xzgehrd(double a[16], int ilo, int ihi, double tau[3])
{
  double work[4];
  if ((ihi - ilo) + 1 > 1) {
    if (ilo - 2 >= 0) {
      std::memset(&tau[0], 0,
                  static_cast<unsigned int>(ilo - 1) * sizeof(double));
    }
    for (int i{ihi}; i < 4; i++) {
      tau[i - 1] = 0.0;
    }
    work[0] = 0.0;
    work[1] = 0.0;
    work[2] = 0.0;
    work[3] = 0.0;
    for (int i{ilo}; i < ihi; i++) {
      double alpha1;
      double d;
      int alpha1_tmp_tmp;
      int b_i;
      int c_i;
      int ia;
      int in;
      int lastc;
      int lastv;
      int n;
      b_i = (i - 1) << 2;
      in = i << 2;
      n = ihi - i;
      alpha1_tmp_tmp = i + b_i;
      alpha1 = a[alpha1_tmp_tmp];
      if (i + 2 <= 4) {
        c_i = i + 1;
      } else {
        c_i = 3;
      }
      d = xzlarfg(n, alpha1, a, (c_i + b_i) + 1);
      tau[i - 1] = d;
      a[alpha1_tmp_tmp] = 1.0;
      c_i = in + 1;
      if (d != 0.0) {
        bool exitg2;
        lastv = n;
        b_i = alpha1_tmp_tmp + n;
        while ((lastv > 0) && (a[b_i - 1] == 0.0)) {
          lastv--;
          b_i--;
        }
        lastc = ihi;
        exitg2 = false;
        while ((!exitg2) && (lastc > 0)) {
          int exitg1;
          b_i = in + lastc;
          ia = b_i;
          do {
            exitg1 = 0;
            if (ia <= b_i + ((lastv - 1) << 2)) {
              if (a[ia - 1] != 0.0) {
                exitg1 = 1;
              } else {
                ia += 4;
              }
            } else {
              lastc--;
              exitg1 = 2;
            }
          } while (exitg1 == 0);
          if (exitg1 == 1) {
            exitg2 = true;
          }
        }
      } else {
        lastv = 0;
        lastc = 0;
      }
      if (lastv > 0) {
        int i1;
        int i2;
        int work_tmp;
        if (lastc != 0) {
          if (lastc - 1 >= 0) {
            std::memset(&work[0], 0,
                        static_cast<unsigned int>(lastc) * sizeof(double));
          }
          b_i = alpha1_tmp_tmp;
          i1 = (in + ((lastv - 1) << 2)) + 1;
          for (int iac{c_i}; iac <= i1; iac += 4) {
            i2 = iac + lastc;
            for (ia = iac; ia < i2; ia++) {
              work_tmp = ia - iac;
              work[work_tmp] += a[ia - 1] * a[b_i];
            }
            b_i++;
          }
        }
        d = -tau[i - 1];
        if (!(d == 0.0)) {
          b_i = in;
          for (work_tmp = 0; work_tmp < lastv; work_tmp++) {
            double temp;
            temp = a[alpha1_tmp_tmp + work_tmp];
            if (temp != 0.0) {
              temp *= d;
              i1 = b_i + 1;
              i2 = lastc + b_i;
              for (int iac{i1}; iac <= i2; iac++) {
                a[iac - 1] += work[(iac - b_i) - 1] * temp;
              }
            }
            b_i += 4;
          }
        }
      }
      xzlarf(n, 4 - i, alpha1_tmp_tmp + 1, tau[i - 1], a, (i + in) + 1, work);
      a[alpha1_tmp_tmp] = alpha1;
    }
  }
}

} // namespace reflapack
} // namespace internal
} // namespace coder

//
// File trailer for xzgehrd.cpp
//
// [EOF]
//
