//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: sprintf.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "sprintf.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdio>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : const array<char, 2U> &varargin_1
//                array<char, 2U> &str
// Return Type  : void
//
namespace coder {
void b_sprintf(const array<char, 2U> &varargin_1, array<char, 2U> &str)
{
  array<char, 2U> b_varargin_1;
  array<char, 2U> c_varargin_1;
  int nbytes;
  b_varargin_1.set_size(1, varargin_1.size(1) + 1);
  nbytes = varargin_1.size(1);
  for (int i{0}; i < nbytes; i++) {
    b_varargin_1[i] = varargin_1[i];
  }
  b_varargin_1[varargin_1.size(1)] = '\x00';
  c_varargin_1.set_size(1, varargin_1.size(1) + 1);
  for (int i{0}; i < nbytes; i++) {
    c_varargin_1[i] = varargin_1[i];
  }
  c_varargin_1[varargin_1.size(1)] = '\x00';
  nbytes = std::snprintf(nullptr, 0, "Unknown command: %s", &c_varargin_1[0]);
  str.set_size(1, nbytes + 1);
  std::snprintf(&str[0], (size_t)(nbytes + 1), "Unknown command: %s",
                &b_varargin_1[0]);
  if (nbytes < 1) {
    nbytes = 0;
  }
  str.set_size(str.size(0), nbytes);
}

//
// Arguments    : double varargin_1
//                double varargin_2
//                double varargin_3
//                double varargin_4
//                double varargin_5
//                double varargin_6
//                double varargin_7
//                array<char, 2U> &str
// Return Type  : void
//
void b_sprintf(double varargin_1, double varargin_2, double varargin_3,
               double varargin_4, double varargin_5, double varargin_6,
               double varargin_7, array<char, 2U> &str)
{
  int nbytes;
  nbytes = std::snprintf(
      nullptr, 0, "Pose: [%.2f %.2f %.2f | %.2f %.2f %.2f %.2f]", varargin_1,
      varargin_2, varargin_3, varargin_4, varargin_5, varargin_6, varargin_7);
  str.set_size(1, nbytes + 1);
  std::snprintf(&str[0], (size_t)(nbytes + 1),
                "Pose: [%.2f %.2f %.2f | %.2f %.2f %.2f %.2f]", varargin_1,
                varargin_2, varargin_3, varargin_4, varargin_5, varargin_6,
                varargin_7);
  if (nbytes < 1) {
    nbytes = 0;
  }
  str.set_size(str.size(0), nbytes);
}

//
// Arguments    : int varargin_1
//                array<char, 2U> &str
// Return Type  : void
//
void b_sprintf(int varargin_1, array<char, 2U> &str)
{
  int nbytes;
  nbytes =
      std::snprintf(nullptr, 0, "Streaming - Frames processed: %d", varargin_1);
  str.set_size(1, nbytes + 1);
  std::snprintf(&str[0], (size_t)(nbytes + 1),
                "Streaming - Frames processed: %d", varargin_1);
  if (nbytes < 1) {
    nbytes = 0;
  }
  str.set_size(str.size(0), nbytes);
}

} // namespace coder

//
// File trailer for sprintf.cpp
//
// [EOF]
//
