//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: camera.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "camera.h"
#include "rt_nonfinite.h"
#include "frameReader.h"
#include "getCameraProps.h"

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
namespace coder {
namespace nvidiacoder {
namespace common {
void camera::initCamera()
{
  static const char cv1[26]{'v', 'i', '-', 'o', 'u', 't', 'p',    'u',   't',
                            ',', ' ', 'i', 'm', 'x', '2', '1',    '9',   ' ',
                            '6', '-', '0', '0', '1', '0', '\x00', '\x00'};
  double validSampleTime;
  int camIndex;
  int cameraDevice;
  int initStatus;
  unsigned int pixfmt;
  char b_cv[26];
  char nullChar;
  nullChar = '\x00';
  camIndex = 0;
  cameraDevice = 0;
  validSampleTime = 0.0;
  for (initStatus = 0; initStatus < 26; initStatus++) {
    b_cv[initStatus] = cv1[initStatus];
  }
  initStatus = validateArgsAndGetDetails(
      &b_cv[0], 640.0, 360.0, &camIndex, &cameraDevice, SearchMode,
      &VideoDevice[0], 0.0, &validSampleTime, &PixelFormat[0], &pixfmt);
  if (initStatus != 0) {
    mw_terminate();
  }
  initStatus = EXT_gstreamerMediaInit(&StructCustomData, &nullChar, &CamWidth,
                                      &CamHeight, 640U, 360U, &Duration, 0.0,
                                      &FrameRate, camIndex, true, cameraDevice,
                                      true, validSampleTime, pixfmt);
  if (initStatus == 0) {
    Initialized = true;
  } else {
    mw_terminate();
  }
}

//
// Arguments    : void
// Return Type  : void
//
void camera::matlabCodegenDestructor()
{
  if (!matlabCodegenIsDeleted) {
    matlabCodegenIsDeleted = true;
    if (isInitialized == 1) {
      isInitialized = 2;
      if (isSetupComplete) {
        releaseImpl();
      }
    }
  }
}

//
// Arguments    : void
// Return Type  : void
//
void camera::releaseImpl()
{
  if (Initialized) {
    EXT_gstreamerMediaTerminate(&StructCustomData);
  }
}

//
// Arguments    : unsigned char image[691200]
// Return Type  : void
//
void camera::stepImpl(unsigned char image[691200])
{
  static unsigned char pln0[230400];
  static unsigned char pln1[230400];
  static unsigned char pln2[230400];
  double curtime;
  curtime = 0.0;
  if (Initialized) {
    int readStatus;
    readStatus = EXT_gstreamerFrameRead(&StructCustomData, 640.0, 360.0, 0.0,
                                        &curtime, &pln0[0], &pln1[0], &pln2[0]);
    for (int i{0}; i < 360; i++) {
      for (int i1{0}; i1 < 640; i1++) {
        int b_image_tmp;
        int image_tmp;
        image_tmp = i1 + 640 * i;
        b_image_tmp = i + 360 * i1;
        image[b_image_tmp] = pln0[image_tmp];
        image[b_image_tmp + 230400] = pln1[image_tmp];
        image[b_image_tmp + 460800] = pln2[image_tmp];
      }
    }
    if (readStatus != 0) {
      Initialized = false;
    }
  }
}

//
// Arguments    : camera &iobj_0
// Return Type  : camera *
//
camera *camera::b_camera(camera &iobj_0)
{
  static const char b_cv[33]{"                                "};
  camera *cameraObj;
  iobj_0.Initialized = false;
  iobj_0.CamWidth = 1.0;
  iobj_0.CamHeight = 1.0;
  iobj_0.Duration = 0.0;
  iobj_0.SearchMode = 0U;
  iobj_0.isInitialized = 0;
  cameraObj = &iobj_0;
  for (int i{0}; i < 33; i++) {
    iobj_0.VideoDevice[i] = b_cv[i];
  }
  for (int i{0}; i < 8; i++) {
    iobj_0.PixelFormat[i] = '\x00';
  }
  iobj_0.initCamera();
  iobj_0.matlabCodegenIsDeleted = false;
  return cameraObj;
}

//
// Arguments    : void
// Return Type  : camera
//
camera::camera()
{
  matlabCodegenIsDeleted = true;
}

//
// Arguments    : void
// Return Type  : void
//
camera::~camera()
{
  matlabCodegenDestructor();
}

//
// Arguments    : unsigned char image[691200]
// Return Type  : void
//
void camera::snapshot(unsigned char image[691200])
{
  if (isInitialized != 1) {
    isInitialized = 1;
    isSetupComplete = true;
  }
  stepImpl(image);
}

} // namespace common
} // namespace nvidiacoder
} // namespace coder

//
// File trailer for camera.cpp
//
// [EOF]
//
