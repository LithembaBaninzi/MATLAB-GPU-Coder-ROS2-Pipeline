//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: tform2quat.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "tform2quat.h"
#include "eigStandard.h"
#include "rt_nonfinite.h"
#include "xdlahqr.h"
#include "xzgehrd.h"
#include "xzlarfg.h"
#include "xzlascl.h"
#include "xzsteqr.h"
#include "xzunghr.h"
#include "xzungqr.h"
#include <algorithm>
#include <cmath>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : const double H[16]
//                double q[4]
// Return Type  : void
//
namespace coder {
void tform2quat(const double H[16], double q[4])
{
  creal_T eigVec[16];
  creal_T eigVal[4];
  double A[16];
  double Q[16];
  double a__4[4];
  double e[3];
  double K12;
  double K13;
  double K14;
  double K23;
  double K24;
  double K34;
  int i;
  int j;
  int k;
  int sgn;
  bool exitg2;
  bool iscale;
  K12 = H[1] + H[4];
  K13 = H[2] + H[8];
  K14 = H[6] - H[9];
  K23 = H[6] + H[9];
  K24 = H[8] - H[2];
  K34 = H[1] - H[4];
  A[0] = ((H[0] - H[5]) - H[10]) / 3.0;
  A[4] = K12 / 3.0;
  A[8] = K13 / 3.0;
  A[12] = K14 / 3.0;
  A[1] = K12 / 3.0;
  A[5] = ((H[5] - H[0]) - H[10]) / 3.0;
  A[9] = K23 / 3.0;
  A[13] = K24 / 3.0;
  A[2] = K13 / 3.0;
  A[6] = K23 / 3.0;
  A[10] = ((H[10] - H[0]) - H[5]) / 3.0;
  A[14] = K34 / 3.0;
  A[3] = K14 / 3.0;
  A[7] = K24 / 3.0;
  A[11] = K34 / 3.0;
  A[15] = ((H[0] + H[5]) + H[10]) / 3.0;
  iscale = true;
  for (k = 0; k < 16; k++) {
    if (iscale) {
      K12 = A[k];
      if (std::isinf(K12) || std::isnan(K12)) {
        iscale = false;
      }
    } else {
      iscale = false;
    }
  }
  if (!iscale) {
    for (i = 0; i < 16; i++) {
      eigVec[i].re = rtNaN;
      eigVec[i].im = 0.0;
    }
    eigVal[0].re = rtNaN;
    eigVal[1].re = rtNaN;
    eigVal[2].re = rtNaN;
    eigVal[3].re = rtNaN;
  } else {
    int b_i;
    int exitg1;
    iscale = true;
    j = 0;
    exitg2 = false;
    while ((!exitg2) && (j < 4)) {
      b_i = 0;
      do {
        exitg1 = 0;
        if (b_i <= j) {
          if (!(A[b_i + (j << 2)] == A[j + (b_i << 2)])) {
            iscale = false;
            exitg1 = 1;
          } else {
            b_i++;
          }
        } else {
          j++;
          exitg1 = 2;
        }
      } while (exitg1 == 0);
      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
    if (iscale) {
      K24 = 0.0;
      j = 0;
      exitg2 = false;
      while ((!exitg2) && (j < 4)) {
        b_i = 0;
        do {
          exitg1 = 0;
          if (b_i <= j) {
            K12 = std::abs(A[b_i + (j << 2)]);
            if (std::isnan(K12)) {
              K24 = rtNaN;
              exitg1 = 1;
            } else {
              if (K12 > K24) {
                K24 = K12;
              }
              b_i++;
            }
          } else {
            j++;
            exitg1 = 2;
          }
        } while (exitg1 == 0);
        if (exitg1 == 1) {
          exitg2 = true;
        }
      }
      if (std::isinf(K24) || std::isnan(K24)) {
        a__4[0] = rtNaN;
        a__4[1] = rtNaN;
        a__4[2] = rtNaN;
        a__4[3] = rtNaN;
        for (i = 0; i < 16; i++) {
          A[i] = rtNaN;
        }
      } else {
        double tau[3];
        int tau_tmp;
        iscale = false;
        if ((K24 > 0.0) && (K24 < 1.0010415475915505E-146)) {
          iscale = true;
          K24 = 1.0010415475915505E-146 / K24;
          internal::reflapack::xzlascl(1.0, K24, A);
        } else if (K24 > 9.9895953610111751E+145) {
          iscale = true;
          K24 = 9.9895953610111751E+145 / K24;
          internal::reflapack::xzlascl(1.0, K24, A);
        }
        for (b_i = 0; b_i < 3; b_i++) {
          int e_tmp_tmp;
          int ia0_tmp_tmp;
          ia0_tmp_tmp = b_i << 2;
          e_tmp_tmp = b_i + ia0_tmp_tmp;
          e[b_i] = A[e_tmp_tmp + 1];
          sgn = b_i + 3;
          if (sgn > 4) {
            sgn = 4;
          }
          K23 = internal::reflapack::xzlarfg(3 - b_i, e[b_i], A,
                                             ia0_tmp_tmp + sgn);
          if (K23 != 0.0) {
            int i1;
            int n;
            A[e_tmp_tmp + 1] = 1.0;
            for (sgn = b_i + 1; sgn < 4; sgn++) {
              tau[sgn - 1] = 0.0;
            }
            n = 2 - b_i;
            i = 4 - b_i;
            for (int jj{0}; jj <= n; jj++) {
              j = b_i + jj;
              K14 = K23 * A[(j + ia0_tmp_tmp) + 1];
              K13 = 0.0;
              tau_tmp = (j + 1) << 2;
              tau[j] += K14 * A[(j + tau_tmp) + 1];
              i1 = jj + 2;
              for (int ii{i1}; ii < i; ii++) {
                sgn = b_i + ii;
                K12 = A[sgn + tau_tmp];
                tau[sgn - 1] += K14 * K12;
                K13 += K12 * A[sgn + ia0_tmp_tmp];
              }
              tau[j] += K23 * K13;
            }
            K13 = 0.0;
            for (k = 0; k <= n; k++) {
              K13 += tau[b_i + k] * A[(e_tmp_tmp + k) + 1];
            }
            K13 *= -0.5 * K23;
            if (!(K13 == 0.0)) {
              i1 = 3 - b_i;
              for (k = 0; k < i1; k++) {
                tau_tmp = b_i + k;
                tau[tau_tmp] += K13 * A[(e_tmp_tmp + k) + 1];
              }
            }
            for (int jj{0}; jj <= n; jj++) {
              j = b_i + jj;
              K14 = A[(j + ia0_tmp_tmp) + 1];
              K12 = tau[j];
              K13 = K12 * K14;
              k = (j + 1) << 2;
              tau_tmp = (j + k) + 1;
              A[tau_tmp] = (A[tau_tmp] - K13) - K13;
              i1 = jj + 2;
              for (int ii{i1}; ii < i; ii++) {
                tau_tmp = b_i + ii;
                sgn = tau_tmp + k;
                A[sgn] = (A[sgn] - tau[tau_tmp - 1] * K14) -
                         A[tau_tmp + ia0_tmp_tmp] * K12;
              }
            }
          }
          A[e_tmp_tmp + 1] = e[b_i];
          a__4[b_i] = A[e_tmp_tmp];
          tau[b_i] = K23;
        }
        a__4[3] = A[15];
        for (j = 2; j >= 0; j--) {
          tau_tmp = (j + 1) << 2;
          A[tau_tmp] = 0.0;
          i = j + 3;
          for (b_i = i; b_i < 5; b_i++) {
            A[(b_i + tau_tmp) - 1] = A[(b_i + (j << 2)) - 1];
          }
        }
        A[0] = 1.0;
        A[1] = 0.0;
        A[2] = 0.0;
        A[3] = 0.0;
        internal::reflapack::xzungqr(3, 3, 3, A, 6, tau, 1);
        sgn = internal::reflapack::xzsteqr(a__4, e, A);
        if (sgn != 0) {
          a__4[0] = rtNaN;
          a__4[1] = rtNaN;
          a__4[2] = rtNaN;
          a__4[3] = rtNaN;
          for (i = 0; i < 16; i++) {
            A[i] = rtNaN;
          }
        } else if (iscale) {
          K13 = 1.0 / K24;
          a__4[0] *= K13;
          a__4[1] *= K13;
          a__4[2] *= K13;
          a__4[3] *= K13;
        }
      }
      eigVal[0].re = a__4[0];
      eigVal[1].re = a__4[1];
      eigVal[2].re = a__4[2];
      eigVal[3].re = a__4[3];
      for (i = 0; i < 16; i++) {
        eigVec[i].re = A[i];
        eigVec[i].im = 0.0;
      }
    } else {
      iscale = true;
      j = 0;
      exitg2 = false;
      while ((!exitg2) && (j < 4)) {
        b_i = 0;
        do {
          exitg1 = 0;
          if (b_i <= j) {
            if (!(A[b_i + (j << 2)] == -A[j + (b_i << 2)])) {
              iscale = false;
              exitg1 = 1;
            } else {
              b_i++;
            }
          } else {
            j++;
            exitg1 = 2;
          }
        } while (exitg1 == 0);
        if (exitg1 == 1) {
          exitg2 = true;
        }
      }
      if (iscale) {
        double wi[4];
        double tau[3];
        internal::reflapack::xzgehrd(A, 1, 4, tau);
        std::copy(&A[0], &A[16], &Q[0]);
        internal::reflapack::xzunghr(1, 4, Q, tau);
        sgn = internal::reflapack::xdlahqr(1, 4, A, 1, 4, Q, a__4, wi);
        for (b_i = 0; b_i < sgn; b_i++) {
          eigVal[b_i].re = rtNaN;
          eigVal[b_i].im = 0.0;
        }
        i = sgn + 1;
        for (b_i = i; b_i < 5; b_i++) {
          eigVal[b_i - 1].re = 0.0;
          eigVal[b_i - 1].im = wi[b_i - 1];
        }
        if (sgn == 0) {
          for (i = 0; i < 16; i++) {
            eigVec[i].re = Q[i];
            eigVec[i].im = 0.0;
          }
          j = 1;
          do {
            exitg1 = 0;
            if (j <= 4) {
              if (j != 4) {
                i = (j - 1) << 2;
                K12 = A[j + i];
                if (K12 != 0.0) {
                  int i1;
                  if (K12 < 0.0) {
                    sgn = 1;
                  } else {
                    sgn = -1;
                  }
                  K12 = eigVec[i].re;
                  i1 = j << 2;
                  K13 = static_cast<double>(sgn) * eigVec[i1].re;
                  if (K13 == 0.0) {
                    eigVec[i].re = K12 / 1.4142135623730951;
                    eigVec[i].im = 0.0;
                  } else if (K12 == 0.0) {
                    eigVec[i].re = 0.0;
                    eigVec[i].im = K13 / 1.4142135623730951;
                  } else {
                    eigVec[i].re = K12 / 1.4142135623730951;
                    eigVec[i].im = K13 / 1.4142135623730951;
                  }
                  eigVec[i1].re = eigVec[i].re;
                  eigVec[i1].im = -eigVec[i].im;
                  K12 = eigVec[i + 1].re;
                  K13 = static_cast<double>(sgn) * eigVec[i1 + 1].re;
                  if (K13 == 0.0) {
                    eigVec[i + 1].re = K12 / 1.4142135623730951;
                    eigVec[i + 1].im = 0.0;
                  } else if (K12 == 0.0) {
                    eigVec[i + 1].re = 0.0;
                    eigVec[i + 1].im = K13 / 1.4142135623730951;
                  } else {
                    eigVec[i + 1].re = K12 / 1.4142135623730951;
                    eigVec[i + 1].im = K13 / 1.4142135623730951;
                  }
                  eigVec[i1 + 1].re = eigVec[i + 1].re;
                  eigVec[i1 + 1].im = -eigVec[i + 1].im;
                  K12 = eigVec[i + 2].re;
                  K13 = static_cast<double>(sgn) * eigVec[i1 + 2].re;
                  if (K13 == 0.0) {
                    eigVec[i + 2].re = K12 / 1.4142135623730951;
                    eigVec[i + 2].im = 0.0;
                  } else if (K12 == 0.0) {
                    eigVec[i + 2].re = 0.0;
                    eigVec[i + 2].im = K13 / 1.4142135623730951;
                  } else {
                    eigVec[i + 2].re = K12 / 1.4142135623730951;
                    eigVec[i + 2].im = K13 / 1.4142135623730951;
                  }
                  eigVec[i1 + 2].re = eigVec[i + 2].re;
                  eigVec[i1 + 2].im = -eigVec[i + 2].im;
                  K12 = eigVec[i + 3].re;
                  K13 = static_cast<double>(sgn) * eigVec[i1 + 3].re;
                  if (K13 == 0.0) {
                    eigVec[i + 3].re = K12 / 1.4142135623730951;
                    eigVec[i + 3].im = 0.0;
                  } else if (K12 == 0.0) {
                    eigVec[i + 3].re = 0.0;
                    eigVec[i + 3].im = K13 / 1.4142135623730951;
                  } else {
                    eigVec[i + 3].re = K12 / 1.4142135623730951;
                    eigVec[i + 3].im = K13 / 1.4142135623730951;
                  }
                  eigVec[i1 + 3].re = eigVec[i + 3].re;
                  eigVec[i1 + 3].im = -eigVec[i + 3].im;
                  j += 2;
                } else {
                  j++;
                }
              } else {
                j++;
              }
            } else {
              exitg1 = 1;
            }
          } while (exitg1 == 0);
        } else {
          for (i = 0; i < 16; i++) {
            eigVec[i].re = rtNaN;
            eigVec[i].im = 0.0;
          }
        }
      } else {
        eigStandard(A, eigVec, eigVal);
      }
    }
  }
  a__4[0] = eigVal[0].re;
  a__4[1] = eigVal[1].re;
  a__4[2] = eigVal[2].re;
  a__4[3] = eigVal[3].re;
  if (!std::isnan(eigVal[0].re)) {
    sgn = 1;
  } else {
    sgn = 0;
    k = 2;
    exitg2 = false;
    while ((!exitg2) && (k < 5)) {
      if (!std::isnan(a__4[k - 1])) {
        sgn = k;
        exitg2 = true;
      } else {
        k++;
      }
    }
  }
  if (sgn == 0) {
    j = 0;
  } else {
    K13 = a__4[sgn - 1];
    j = sgn - 1;
    i = sgn + 1;
    for (k = i; k < 5; k++) {
      K12 = a__4[k - 1];
      if (K13 < K12) {
        K13 = K12;
        j = k - 1;
      }
    }
  }
  sgn = j << 2;
  q[0] = eigVec[sgn + 3].re;
  q[1] = eigVec[sgn].re;
  q[2] = eigVec[sgn + 1].re;
  q[3] = eigVec[sgn + 2].re;
  if (q[0] < 0.0) {
    q[0] = -q[0];
    q[1] = -q[1];
    q[2] = -q[2];
    q[3] = -q[3];
  }
}

} // namespace coder

//
// File trailer for tform2quat.cpp
//
// [EOF]
//
