
//
// File main.cpp
//
// Code generated for MATLAB function 'updatedVisStateEst'.
//
// MATLAB Coder version         : 24.2 (R2024b) 21-Jun-2024
// C/C++ source code generated on : Mon Feb 09 16:09:55 2026
//
#include <thread>
#include <vector>
#include "rclcpp/rclcpp.hpp"
#include "updatedVisStateEst.h"
rclcpp::Node::SharedPtr gNodePtr;
rclcpp::executors::MultiThreadedExecutor::SharedPtr gMultiExec;
bool threadTerminating = false;
void threadFunction(void)
{
    try {
        updatedVisStateEst();
    } catch (std::runtime_error & e) {
        std::cout << "Caught exception: " << e.what() << std::endl;
    } catch (...) {
        std::cout << "Caught unknown exception, terminating the program." << std::endl;
    }
    gMultiExec->cancel();
    gMultiExec->remove_node(gNodePtr);
    threadTerminating = true;
    rclcpp::shutdown();
}
int main(int argc, char * const argv[])
{
    std::vector<char *> args(argv, argv + argc);
    rclcpp::init(static_cast<int>(args.size()), args.data());
    gNodePtr = std::make_shared<rclcpp::Node>("p3p_node","");
    // Declare parameters if there is any
    gMultiExec = std::make_shared<rclcpp::executors::MultiThreadedExecutor>();
    gMultiExec->add_node(gNodePtr);
    std::thread threadObj(threadFunction);
    gMultiExec->spin();
    if (threadTerminating) {
    threadObj.join();
    }
    return 0;
}
