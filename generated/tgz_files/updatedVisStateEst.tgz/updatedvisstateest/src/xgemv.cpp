//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xgemv.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "xgemv.h"
#include "rt_nonfinite.h"
#include <cstring>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : int n
//                const double x[12]
//                double beta1
//                double y[16]
//                int iy0
// Return Type  : void
//
namespace coder {
namespace internal {
namespace blas {
void b_xgemv(int n, const double x[12], double beta1, double y[16], int iy0)
{
  if (n != 0) {
    int iy;
    int iyend;
    iyend = iy0 + 3;
    if (beta1 != 1.0) {
      if (beta1 == 0.0) {
        if (iy0 <= iyend) {
          std::memset(&y[iy0 + -1], 0,
                      static_cast<unsigned int>((iyend - iy0) + 1) *
                          sizeof(double));
        }
      } else {
        for (iy = iy0; iy <= iyend; iy++) {
          y[iy - 1] *= beta1;
        }
      }
    }
    iyend = 4;
    iy = ((n - 1) << 2) + 1;
    for (int iac{1}; iac <= iy; iac += 4) {
      int i;
      i = iac + 3;
      for (int ia{iac}; ia <= i; ia++) {
        int i1;
        i1 = ((iy0 + ia) - iac) - 1;
        y[i1] += y[ia - 1] * x[iyend];
      }
      iyend++;
    }
  }
}

//
// Arguments    : int n
//                const double x[12]
//                double beta1
//                double y[16]
//                int iy0
// Return Type  : void
//
void xgemv(int n, const double x[12], double beta1, double y[16], int iy0)
{
  if (n != 0) {
    int iy;
    int iyend;
    iyend = iy0 + 3;
    if (beta1 != 1.0) {
      if (beta1 == 0.0) {
        if (iy0 <= iyend) {
          std::memset(&y[iy0 + -1], 0,
                      static_cast<unsigned int>((iyend - iy0) + 1) *
                          sizeof(double));
        }
      } else {
        for (iy = iy0; iy <= iyend; iy++) {
          y[iy - 1] *= beta1;
        }
      }
    }
    iyend = 8;
    iy = ((n - 1) << 2) + 1;
    for (int iac{1}; iac <= iy; iac += 4) {
      int i;
      i = iac + 3;
      for (int ia{iac}; ia <= i; ia++) {
        int i1;
        i1 = ((iy0 + ia) - iac) - 1;
        y[i1] += y[ia - 1] * x[iyend];
      }
      iyend++;
    }
  }
}

} // namespace blas
} // namespace internal
} // namespace coder

//
// File trailer for xgemv.cpp
//
// [EOF]
//
