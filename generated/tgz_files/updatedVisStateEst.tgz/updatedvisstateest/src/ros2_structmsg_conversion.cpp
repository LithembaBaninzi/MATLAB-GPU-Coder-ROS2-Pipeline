#include "ros2_structmsg_conversion.h"


// Conversions between builtin_interfaces_TimeStruct_T and builtin_interfaces::msg::Time

void struct2msg(builtin_interfaces::msg::Time& msgPtr, builtin_interfaces_TimeStruct_T const* structPtr)
{
  const std::string rosMessageType("builtin_interfaces/Time");

  msgPtr.nanosec =  structPtr->nanosec;
  msgPtr.sec =  structPtr->sec;
}

void msg2struct(builtin_interfaces_TimeStruct_T* structPtr, const builtin_interfaces::msg::Time& msgPtr)
{
  const std::string rosMessageType("builtin_interfaces/Time");

  structPtr->nanosec =  msgPtr.nanosec;
  structPtr->sec =  msgPtr.sec;
}


// Conversions between geometry_msgs_PointStruct_T and geometry_msgs::msg::Point

void struct2msg(geometry_msgs::msg::Point& msgPtr, geometry_msgs_PointStruct_T const* structPtr)
{
  const std::string rosMessageType("geometry_msgs/Point");

  msgPtr.x =  structPtr->x;
  msgPtr.y =  structPtr->y;
  msgPtr.z =  structPtr->z;
}

void msg2struct(geometry_msgs_PointStruct_T* structPtr, const geometry_msgs::msg::Point& msgPtr)
{
  const std::string rosMessageType("geometry_msgs/Point");

  structPtr->x =  msgPtr.x;
  structPtr->y =  msgPtr.y;
  structPtr->z =  msgPtr.z;
}


// Conversions between geometry_msgs_PoseStruct_T and geometry_msgs::msg::Pose

void struct2msg(geometry_msgs::msg::Pose& msgPtr, geometry_msgs_PoseStruct_T const* structPtr)
{
  const std::string rosMessageType("geometry_msgs/Pose");

  struct2msg(msgPtr.orientation, &structPtr->orientation);
  struct2msg(msgPtr.position, &structPtr->position);
}

void msg2struct(geometry_msgs_PoseStruct_T* structPtr, const geometry_msgs::msg::Pose& msgPtr)
{
  const std::string rosMessageType("geometry_msgs/Pose");

  msg2struct(&structPtr->orientation, msgPtr.orientation);
  msg2struct(&structPtr->position, msgPtr.position);
}


// Conversions between geometry_msgs_PoseStampedStruct_T and geometry_msgs::msg::PoseStamped

void struct2msg(geometry_msgs::msg::PoseStamped& msgPtr, geometry_msgs_PoseStampedStruct_T const* structPtr)
{
  const std::string rosMessageType("geometry_msgs/PoseStamped");

  struct2msg(msgPtr.header, &structPtr->header);
  struct2msg(msgPtr.pose, &structPtr->pose);
}

void msg2struct(geometry_msgs_PoseStampedStruct_T* structPtr, const geometry_msgs::msg::PoseStamped& msgPtr)
{
  const std::string rosMessageType("geometry_msgs/PoseStamped");

  msg2struct(&structPtr->header, msgPtr.header);
  msg2struct(&structPtr->pose, msgPtr.pose);
}


// Conversions between geometry_msgs_QuaternionStruct_T and geometry_msgs::msg::Quaternion

void struct2msg(geometry_msgs::msg::Quaternion& msgPtr, geometry_msgs_QuaternionStruct_T const* structPtr)
{
  const std::string rosMessageType("geometry_msgs/Quaternion");

  msgPtr.w =  structPtr->w;
  msgPtr.x =  structPtr->x;
  msgPtr.y =  structPtr->y;
  msgPtr.z =  structPtr->z;
}

void msg2struct(geometry_msgs_QuaternionStruct_T* structPtr, const geometry_msgs::msg::Quaternion& msgPtr)
{
  const std::string rosMessageType("geometry_msgs/Quaternion");

  structPtr->w =  msgPtr.w;
  structPtr->x =  msgPtr.x;
  structPtr->y =  msgPtr.y;
  structPtr->z =  msgPtr.z;
}


// Conversions between std_msgs_HeaderStruct_T and std_msgs::msg::Header

void struct2msg(std_msgs::msg::Header& msgPtr, std_msgs_HeaderStruct_T const* structPtr)
{
  const std::string rosMessageType("std_msgs/Header");

  convertFromStructPrimitiveArray(msgPtr.frame_id, structPtr->frame_id);
  struct2msg(msgPtr.stamp, &structPtr->stamp);
}

void msg2struct(std_msgs_HeaderStruct_T* structPtr, const std_msgs::msg::Header& msgPtr)
{
  const std::string rosMessageType("std_msgs/Header");

  convertToStructPrimitiveArray(structPtr->frame_id, msgPtr.frame_id);
  msg2struct(&structPtr->stamp, msgPtr.stamp);
}


// Conversions between std_msgs_StringStruct_T and std_msgs::msg::String

void struct2msg(std_msgs::msg::String& msgPtr, std_msgs_StringStruct_T const* structPtr)
{
  const std::string rosMessageType("std_msgs/String");

  convertFromStructPrimitiveArray(msgPtr.data, structPtr->data);
}

void msg2struct(std_msgs_StringStruct_T* structPtr, const std_msgs::msg::String& msgPtr)
{
  const std::string rosMessageType("std_msgs/String");

  convertToStructPrimitiveArray(structPtr->data, msgPtr.data);
}

