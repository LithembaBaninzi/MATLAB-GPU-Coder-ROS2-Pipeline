//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: std_msgs_StringStruct.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "std_msgs_StringStruct.h"
#include "rt_nonfinite.h"
#include "updatedVisStateEst_types.h"
#include "coder_array.h"

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Message struct definition for std_msgs/String
//
// Arguments    : std_msgs_StringStruct_T &msg
// Return Type  : void
//
void std_msgs_StringStruct(std_msgs_StringStruct_T &msg)
{
  static const char b_cv[15]{'s', 't', 'd', '_', 'm', 's', 'g', 's',
                             '/', 'S', 't', 'r', 'i', 'n', 'g'};
  for (int i{0}; i < 15; i++) {
    msg.MessageType[i] = b_cv[i];
  }
  msg.data.set_size(1, 0);
  //(&msg);
}

//
// File trailer for std_msgs_StringStruct.cpp
//
// [EOF]
//
