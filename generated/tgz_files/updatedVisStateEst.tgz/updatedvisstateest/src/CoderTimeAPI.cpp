//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: CoderTimeAPI.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "CoderTimeAPI.h"
#include "rt_nonfinite.h"
#include "updatedVisStateEst_data.h"

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void CoderTimeAPI::callCoderClockGettime_init()
{
  freq_not_empty = false;
}

//
// File trailer for CoderTimeAPI.cpp
//
// [EOF]
//
