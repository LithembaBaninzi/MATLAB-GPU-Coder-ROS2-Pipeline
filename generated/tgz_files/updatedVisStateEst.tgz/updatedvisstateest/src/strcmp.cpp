//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: strcmp.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "strcmp.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : const array<char, 2U> &b
// Return Type  : bool
//
namespace coder {
namespace internal {
bool b_strcmp(const array<char, 2U> &b)
{
  static const char b_cv[5]{'s', 't', 'a', 'r', 't'};
  bool b_bool;
  b_bool = false;
  if (b.size(1) == 5) {
    int kstr;
    kstr = 0;
    int exitg1;
    do {
      exitg1 = 0;
      if (kstr < 5) {
        if (b_cv[kstr] != b[kstr]) {
          exitg1 = 1;
        } else {
          kstr++;
        }
      } else {
        b_bool = true;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }
  return b_bool;
}

//
// Arguments    : const array<char, 2U> &b
// Return Type  : bool
//
bool c_strcmp(const array<char, 2U> &b)
{
  static const char b_cv[4]{'s', 't', 'o', 'p'};
  bool b_bool;
  b_bool = false;
  if (b.size(1) == 4) {
    int kstr;
    kstr = 0;
    int exitg1;
    do {
      exitg1 = 0;
      if (kstr < 4) {
        if (b_cv[kstr] != b[kstr]) {
          exitg1 = 1;
        } else {
          kstr++;
        }
      } else {
        b_bool = true;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }
  return b_bool;
}

//
// Arguments    : const array<char, 2U> &b
// Return Type  : bool
//
bool d_strcmp(const array<char, 2U> &b)
{
  static const char b_cv[8]{'s', 'h', 'u', 't', 'd', 'o', 'w', 'n'};
  bool b_bool;
  b_bool = false;
  if (b.size(1) == 8) {
    int kstr;
    kstr = 0;
    int exitg1;
    do {
      exitg1 = 0;
      if (kstr < 8) {
        if (b_cv[kstr] != b[kstr]) {
          exitg1 = 1;
        } else {
          kstr++;
        }
      } else {
        b_bool = true;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }
  return b_bool;
}

} // namespace internal
} // namespace coder

//
// File trailer for strcmp.cpp
//
// [EOF]
//
