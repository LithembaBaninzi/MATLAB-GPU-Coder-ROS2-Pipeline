//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: getCurrentTimestamp.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "getCurrentTimestamp.h"
#include "datetime.h"
#include "rt_nonfinite.h"
#include <cmath>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// DATETIMETOROS2TIME Summary of this function goes here
//    Detailed explanation goes here
//
// Arguments    : int &sec
//                unsigned int &nsec
// Return Type  : double
//
double getCurrentTimestamp(int &sec, unsigned int &nsec)
{
  coder::datetime currentTime;
  double dec;
  double secondsSinceEpoch;
  currentTime.init();
  // currentTime.Format = 'dd-MMM-yyyy HH:mm:ss.SSSSSSSSS';
  dec = currentTime.data.re / 1000.0;
  secondsSinceEpoch = std::floor(dec);
  if (secondsSinceEpoch < 2.147483648E+9) {
    if (secondsSinceEpoch >= -2.147483648E+9) {
      sec = static_cast<int>(secondsSinceEpoch);
    } else {
      sec = MIN_int32_T;
    }
  } else if (secondsSinceEpoch >= 2.147483648E+9) {
    sec = MAX_int32_T;
  } else {
    sec = 0;
  }
  secondsSinceEpoch = std::floor((dec - secondsSinceEpoch) * 1.0E+9);
  if (secondsSinceEpoch < 4.294967296E+9) {
    if (secondsSinceEpoch >= 0.0) {
      nsec = static_cast<unsigned int>(secondsSinceEpoch);
    } else {
      nsec = 0U;
    }
  } else if (secondsSinceEpoch >= 4.294967296E+9) {
    nsec = MAX_uint32_T;
  } else {
    nsec = 0U;
  }
  return dec;
}

//
// File trailer for getCurrentTimestamp.cpp
//
// [EOF]
//
