//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xdtrevc3.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "xdtrevc3.h"
#include "rt_nonfinite.h"
#include "xdlaln2.h"
#include "xgemv.h"
#include <cmath>
#include <cstring>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : const double T[16]
//                double vr[16]
// Return Type  : void
//
namespace coder {
namespace internal {
namespace reflapack {
void xdtrevc3(const double T[16], double vr[16])
{
  double work[12];
  double x[4];
  double remax;
  int ii;
  int ip;
  int j;
  std::memset(&work[0], 0, 12U * sizeof(double));
  x[0] = 0.0;
  x[1] = 0.0;
  x[2] = 0.0;
  x[3] = 0.0;
  work[0] = 0.0;
  for (j = 0; j < 3; j++) {
    work[j + 1] = 0.0;
    for (ii = 0; ii <= j; ii++) {
      work[j + 1] += std::abs(T[ii + ((j + 1) << 2)]);
    }
  }
  ip = 0;
  for (int ki{3}; ki >= 0; ki--) {
    if (ip == -1) {
      ip = 1;
    } else {
      double smin;
      double wi;
      double wr_tmp;
      int wr_tmp_tmp;
      if ((ki + 1 == 1) || (T[ki + ((ki - 1) << 2)] == 0.0)) {
        ip = 0;
      } else {
        ip = -1;
      }
      wr_tmp_tmp = ki << 2;
      ii = ki + wr_tmp_tmp;
      wr_tmp = T[ii];
      wi = 0.0;
      if (ip != 0) {
        wi = std::sqrt(std::abs(T[ki + ((ki - 1) << 2)])) *
             std::sqrt(std::abs(T[ii - 1]));
      }
      smin = std::fmax(2.2204460492503131E-16 * (std::abs(wr_tmp) + wi),
                       4.0083367200179456E-292);
      if (ip == 0) {
        double scale;
        int i;
        work[ki + 8] = 1.0;
        for (int k{0}; k < ki; k++) {
          work[k + 8] = -T[k + wr_tmp_tmp];
        }
        j = ki - 1;
        int exitg1;
        do {
          exitg1 = 0;
          if (j + 1 >= 1) {
            bool guard1;
            guard1 = false;
            if (j + 1 == 1) {
              guard1 = true;
            } else {
              i = (j - 1) << 2;
              ii = j + i;
              if (T[ii] == 0.0) {
                guard1 = true;
              } else {
                scale = xdlaln2(2, 1, smin, T, ii, work, j + 8, wr_tmp, 0.0, x,
                                remax);
                if ((remax > 1.0) && (std::fmax(work[j - 1], work[j]) >
                                      2.4948003869183992E+291 / remax)) {
                  x[0] /= remax;
                  x[1] /= remax;
                  scale /= remax;
                }
                if (scale != 1.0) {
                  ii = ki + 9;
                  for (int k{9}; k <= ii; k++) {
                    work[k - 1] *= scale;
                  }
                }
                work[j + 7] = x[0];
                work[j + 8] = x[1];
                if ((j - 1 >= 1) && (!(-x[0] == 0.0))) {
                  ii = j - 2;
                  for (int k{0}; k <= ii; k++) {
                    work[k + 8] += -x[0] * T[i + k];
                  }
                }
                if ((j - 1 >= 1) && (!(-x[1] == 0.0))) {
                  ii = j << 2;
                  i = j - 2;
                  for (int k{0}; k <= i; k++) {
                    work[k + 8] += -x[1] * T[ii + k];
                  }
                }
                j -= 2;
              }
            }
            if (guard1) {
              i = j << 2;
              scale = xdlaln2(1, 1, smin, T, (i + j) + 1, work, j + 9, wr_tmp,
                              0.0, x, remax);
              if ((remax > 1.0) &&
                  (work[j] > 2.4948003869183992E+291 / remax)) {
                x[0] /= remax;
                scale /= remax;
              }
              if (scale != 1.0) {
                ii = ki + 9;
                for (int k{9}; k <= ii; k++) {
                  work[k - 1] *= scale;
                }
              }
              work[j + 8] = x[0];
              if ((j >= 1) && (!(-x[0] == 0.0))) {
                for (int k{0}; k < j; k++) {
                  work[k + 8] += -x[0] * T[i + k];
                }
              }
              j--;
            }
          } else {
            exitg1 = 1;
          }
        } while (exitg1 == 0);
        if (ki + 1 > 1) {
          blas::xgemv(ki, work, work[ki + 8], vr, wr_tmp_tmp + 1);
        }
        ii = -1;
        remax = std::abs(vr[wr_tmp_tmp]);
        scale = std::abs(vr[wr_tmp_tmp + 1]);
        if (scale > remax) {
          ii = 0;
          remax = scale;
        }
        scale = std::abs(vr[wr_tmp_tmp + 2]);
        if (scale > remax) {
          ii = 1;
          remax = scale;
        }
        if (std::abs(vr[wr_tmp_tmp + 3]) > remax) {
          ii = 2;
        }
        remax = 1.0 / std::abs(vr[(ii + wr_tmp_tmp) + 1]);
        i = wr_tmp_tmp + 4;
        for (int k{wr_tmp_tmp + 1}; k <= i; k++) {
          vr[k - 1] *= remax;
        }
      } else {
        double scale;
        int i;
        int ix0;
        ix0 = (ki - 1) << 2;
        remax = T[ki + ix0];
        scale = T[ii - 1];
        if (std::abs(scale) >= std::abs(remax)) {
          work[ki + 3] = 1.0;
          work[ki + 8] = wi / scale;
        } else {
          work[ki + 3] = -wi / remax;
          work[ki + 8] = 1.0;
        }
        work[ki + 4] = 0.0;
        work[ki + 7] = 0.0;
        for (int k{0}; k <= ki - 2; k++) {
          work[k + 4] = -work[ki + 3] * T[k + ix0];
          work[k + 8] = -work[ki + 8] * T[k + wr_tmp_tmp];
        }
        j = ki - 2;
        while (j + 1 >= 1) {
          if ((j + 1 == 1) || (T[1] == 0.0)) {
            i = j << 2;
            scale = xdlaln2(1, 2, smin, T, (i + j) + 1, work, j + 5, wr_tmp, wi,
                            x, remax);
            if ((remax > 1.0) && (work[j] > 2.4948003869183992E+291 / remax)) {
              x[0] /= remax;
              x[2] /= remax;
              scale /= remax;
            }
            if (scale != 1.0) {
              ii = ki + 5;
              for (int k{5}; k <= ii; k++) {
                work[k - 1] *= scale;
              }
              ii = ki + 9;
              for (int k{9}; k <= ii; k++) {
                work[k - 1] *= scale;
              }
            }
            work[j + 4] = x[0];
            work[j + 8] = x[2];
            if ((j >= 1) && (!(-x[0] == 0.0))) {
              work[4] += -x[0] * T[i];
            }
            if ((j >= 1) && (!(-x[2] == 0.0))) {
              for (int k{0}; k < j; k++) {
                work[k + 8] += -x[2] * T[i + k];
              }
            }
            j--;
          } else {
            scale = xdlaln2(2, 2, smin, T, 1, work, 5, wr_tmp, wi, x, remax);
            if ((remax > 1.0) && (std::fmax(work[0], work[1]) >
                                  2.4948003869183992E+291 / remax)) {
              remax = 1.0 / remax;
              x[0] *= remax;
              x[2] *= remax;
              x[1] *= remax;
              x[3] *= remax;
              scale *= remax;
            }
            if (scale != 1.0) {
              i = ki + 5;
              for (int k{5}; k <= i; k++) {
                work[k - 1] *= scale;
              }
              i = ki + 9;
              for (int k{9}; k <= i; k++) {
                work[k - 1] *= scale;
              }
            }
            work[4] = x[0];
            work[5] = x[1];
            work[8] = x[2];
            work[9] = x[3];
            j = -1;
          }
        }
        if (ki + 1 > 2) {
          blas::b_xgemv(ki - 1, work, work[ki + 3], vr, ix0 + 1);
          blas::xgemv(ki - 1, work, work[ki + 8], vr, wr_tmp_tmp + 1);
        } else {
          i = ix0 + 4;
          for (int k{ix0 + 1}; k <= i; k++) {
            vr[k - 1] *= work[ki + 3];
          }
          i = wr_tmp_tmp + 4;
          for (int k{wr_tmp_tmp + 1}; k <= i; k++) {
            vr[k - 1] *= work[ki + 8];
          }
        }
        remax = 1.0 /
                std::fmax(
                    std::fmax(
                        std::fmax(std::fmax(0.0, std::abs(vr[ix0]) +
                                                     std::abs(vr[wr_tmp_tmp])),
                                  std::abs(vr[ix0 + 1]) +
                                      std::abs(vr[wr_tmp_tmp + 1])),
                        std::abs(vr[ix0 + 2]) + std::abs(vr[wr_tmp_tmp + 2])),
                    std::abs(vr[ix0 + 3]) + std::abs(vr[wr_tmp_tmp + 3]));
        i = ix0 + 4;
        for (int k{ix0 + 1}; k <= i; k++) {
          vr[k - 1] *= remax;
        }
        i = wr_tmp_tmp + 4;
        for (int k{wr_tmp_tmp + 1}; k <= i; k++) {
          vr[k - 1] *= remax;
        }
      }
    }
  }
}

} // namespace reflapack
} // namespace internal
} // namespace coder

//
// File trailer for xdtrevc3.cpp
//
// [EOF]
//
