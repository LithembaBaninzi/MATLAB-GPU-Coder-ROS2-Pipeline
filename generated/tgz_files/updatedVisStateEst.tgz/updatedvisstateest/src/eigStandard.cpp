//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: eigStandard.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "eigStandard.h"
#include "rt_nonfinite.h"
#include "xdlahqr.h"
#include "xdtrevc3.h"
#include "xnrm2.h"
#include "xzgebal.h"
#include "xzgehrd.h"
#include "xzlascl.h"
#include "xzunghr.h"
#include <algorithm>
#include <cmath>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : const double A[16]
//                creal_T V[16]
//                creal_T D[4]
// Return Type  : void
//
namespace coder {
void eigStandard(const double A[16], creal_T V[16], creal_T D[4])
{
  double b_A[16];
  double vr[16];
  double absxk;
  double anrm;
  int ihi;
  int k;
  bool exitg1;
  std::copy(&A[0], &A[16], &b_A[0]);
  anrm = 0.0;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 16)) {
    absxk = std::abs(A[k]);
    if (std::isnan(absxk)) {
      anrm = rtNaN;
      exitg1 = true;
    } else {
      if (absxk > anrm) {
        anrm = absxk;
      }
      k++;
    }
  }
  if (std::isinf(anrm) || std::isnan(anrm)) {
    D[0].re = rtNaN;
    D[0].im = 0.0;
    D[1].re = rtNaN;
    D[1].im = 0.0;
    D[2].re = rtNaN;
    D[2].im = 0.0;
    D[3].re = rtNaN;
    D[3].im = 0.0;
    for (int g1_tmp_tmp{0}; g1_tmp_tmp < 16; g1_tmp_tmp++) {
      V[g1_tmp_tmp].re = rtNaN;
      V[g1_tmp_tmp].im = 0.0;
    }
  } else {
    double scale[4];
    double wi[4];
    double wr[4];
    double tau[3];
    double cscale;
    int ilo;
    int info;
    bool scalea;
    cscale = anrm;
    scalea = false;
    if ((anrm > 0.0) && (anrm < 6.7178761075670888E-139)) {
      scalea = true;
      cscale = 6.7178761075670888E-139;
      internal::reflapack::xzlascl(anrm, cscale, b_A);
    } else if (anrm > 1.4885657073574029E+138) {
      scalea = true;
      cscale = 1.4885657073574029E+138;
      internal::reflapack::xzlascl(anrm, cscale, b_A);
    }
    ilo = internal::reflapack::xzgebal(b_A, ihi, scale);
    internal::reflapack::xzgehrd(b_A, ilo, ihi, tau);
    std::copy(&b_A[0], &b_A[16], &vr[0]);
    internal::reflapack::xzunghr(ilo, ihi, vr, tau);
    info = internal::reflapack::xdlahqr(ilo, ihi, b_A, ilo, ihi, vr, wr, wi);
    if (info == 0) {
      double f1;
      int g1_tmp_tmp;
      internal::reflapack::xdtrevc3(b_A, vr);
      if (ilo != ihi) {
        for (int i{ilo}; i <= ihi; i++) {
          g1_tmp_tmp = i + 12;
          for (k = i; k <= g1_tmp_tmp; k += 4) {
            vr[k - 1] *= scale[i - 1];
          }
        }
      }
      g1_tmp_tmp = ilo - 1;
      for (int i{g1_tmp_tmp}; i >= 1; i--) {
        f1 = scale[i - 1];
        if (static_cast<int>(f1) != i) {
          absxk = vr[i - 1];
          vr[i - 1] = vr[static_cast<int>(f1) - 1];
          vr[static_cast<int>(f1) - 1] = absxk;
          absxk = vr[i + 3];
          vr[i + 3] = vr[static_cast<int>(f1) + 3];
          vr[static_cast<int>(f1) + 3] = absxk;
          absxk = vr[i + 7];
          vr[i + 7] = vr[static_cast<int>(f1) + 7];
          vr[static_cast<int>(f1) + 7] = absxk;
          absxk = vr[i + 11];
          vr[i + 11] = vr[static_cast<int>(f1) + 11];
          vr[static_cast<int>(f1) + 11] = absxk;
        }
      }
      g1_tmp_tmp = ihi + 1;
      for (int i{g1_tmp_tmp}; i < 5; i++) {
        f1 = scale[i - 1];
        if (static_cast<int>(f1) != i) {
          absxk = vr[i - 1];
          vr[i - 1] = vr[static_cast<int>(f1) - 1];
          vr[static_cast<int>(f1) - 1] = absxk;
          absxk = vr[i + 3];
          vr[i + 3] = vr[static_cast<int>(f1) + 3];
          vr[static_cast<int>(f1) + 3] = absxk;
          absxk = vr[i + 7];
          vr[i + 7] = vr[static_cast<int>(f1) + 7];
          vr[static_cast<int>(f1) + 7] = absxk;
          absxk = vr[i + 11];
          vr[i + 11] = vr[static_cast<int>(f1) + 11];
          vr[static_cast<int>(f1) + 11] = absxk;
        }
      }
      for (int i{0}; i < 4; i++) {
        f1 = wi[i];
        if (!(f1 < 0.0)) {
          if ((i + 1 != 4) && (f1 > 0.0)) {
            double c;
            double d;
            double d1;
            double f1_tmp;
            double g1_tmp;
            double s;
            int b_tmp;
            ihi = i << 2;
            absxk = std::abs(internal::blas::xnrm2(4, vr, ihi + 1));
            b_tmp = (i + 1) << 2;
            f1 = std::abs(internal::blas::xnrm2(4, vr, b_tmp + 1));
            if (absxk < f1) {
              absxk /= f1;
              absxk = f1 * std::sqrt(absxk * absxk + 1.0);
            } else if (absxk > f1) {
              f1 /= absxk;
              absxk *= std::sqrt(f1 * f1 + 1.0);
            } else if (std::isnan(f1)) {
              absxk = rtNaN;
            } else {
              absxk *= 1.4142135623730951;
            }
            absxk = 1.0 / absxk;
            g1_tmp_tmp = ihi + 4;
            for (k = ihi + 1; k <= g1_tmp_tmp; k++) {
              vr[k - 1] *= absxk;
            }
            g1_tmp_tmp = b_tmp + 4;
            for (k = b_tmp + 1; k <= g1_tmp_tmp; k++) {
              vr[k - 1] *= absxk;
            }
            f1 = vr[ihi];
            absxk = vr[b_tmp];
            s = vr[ihi + 1];
            g1_tmp = vr[b_tmp + 1];
            f1_tmp = vr[ihi + 2];
            c = vr[b_tmp + 2];
            d = vr[ihi + 3];
            d1 = vr[b_tmp + 3];
            k = 0;
            absxk = std::abs(f1 * f1 + absxk * absxk);
            s = std::abs(s * s + g1_tmp * g1_tmp);
            if (s > absxk) {
              k = 1;
              absxk = s;
            }
            s = std::abs(f1_tmp * f1_tmp + c * c);
            if (s > absxk) {
              k = 2;
              absxk = s;
            }
            if (std::abs(d * d + d1 * d1) > absxk) {
              k = 3;
            }
            f1_tmp = vr[k + ihi];
            f1 = std::abs(f1_tmp);
            g1_tmp_tmp = k + b_tmp;
            g1_tmp = vr[g1_tmp_tmp];
            absxk = std::abs(g1_tmp);
            if (g1_tmp == 0.0) {
              c = 1.0;
              s = 0.0;
            } else if (f1_tmp == 0.0) {
              c = 0.0;
              if (g1_tmp >= 0.0) {
                s = 1.0;
              } else {
                s = -1.0;
              }
            } else if ((f1 > 1.4916681462400413E-154) &&
                       (f1 < 4.7403759540545887E+153) &&
                       (absxk > 1.4916681462400413E-154) &&
                       (absxk < 4.7403759540545887E+153)) {
              s = std::sqrt(f1_tmp * f1_tmp + g1_tmp * g1_tmp);
              c = f1 / s;
              if (!(f1_tmp >= 0.0)) {
                s = -s;
              }
              s = g1_tmp / s;
            } else {
              absxk = std::fmin(
                  4.49423283715579E+307,
                  std::fmax(2.2250738585072014E-308, std::fmax(f1, absxk)));
              f1 = f1_tmp / absxk;
              absxk = g1_tmp / absxk;
              s = std::sqrt(f1 * f1 + absxk * absxk);
              c = std::abs(f1) / s;
              if (!(f1_tmp >= 0.0)) {
                s = -s;
              }
              s = absxk / s;
            }
            absxk = c * vr[ihi] + s * vr[b_tmp];
            vr[b_tmp] = c * vr[b_tmp] - s * vr[ihi];
            vr[ihi] = absxk;
            absxk = vr[b_tmp + 1];
            f1 = vr[ihi + 1];
            vr[b_tmp + 1] = c * absxk - s * f1;
            vr[ihi + 1] = c * f1 + s * absxk;
            absxk = vr[b_tmp + 2];
            f1 = vr[ihi + 2];
            vr[b_tmp + 2] = c * absxk - s * f1;
            vr[ihi + 2] = c * f1 + s * absxk;
            absxk = vr[b_tmp + 3];
            f1 = vr[ihi + 3];
            vr[b_tmp + 3] = c * absxk - s * f1;
            vr[ihi + 3] = c * f1 + s * absxk;
            vr[g1_tmp_tmp] = 0.0;
          } else {
            ihi = i << 2;
            absxk = 1.0 / internal::blas::xnrm2(4, vr, ihi + 1);
            g1_tmp_tmp = ihi + 4;
            for (k = ihi + 1; k <= g1_tmp_tmp; k++) {
              vr[k - 1] *= absxk;
            }
          }
        }
      }
      for (g1_tmp_tmp = 0; g1_tmp_tmp < 16; g1_tmp_tmp++) {
        V[g1_tmp_tmp].re = vr[g1_tmp_tmp];
        V[g1_tmp_tmp].im = 0.0;
      }
      for (ihi = 0; ihi < 3; ihi++) {
        if ((wi[ihi] > 0.0) && (wi[ihi + 1] < 0.0)) {
          g1_tmp_tmp = ihi << 2;
          k = (ihi + 1) << 2;
          absxk = V[k].re;
          V[g1_tmp_tmp].im = absxk;
          V[k].re = V[g1_tmp_tmp].re;
          V[k].im = -absxk;
          absxk = V[k + 1].re;
          V[g1_tmp_tmp + 1].im = absxk;
          V[k + 1].re = V[g1_tmp_tmp + 1].re;
          V[k + 1].im = -absxk;
          absxk = V[k + 2].re;
          V[g1_tmp_tmp + 2].im = absxk;
          V[k + 2].re = V[g1_tmp_tmp + 2].re;
          V[k + 2].im = -absxk;
          absxk = V[k + 3].re;
          V[g1_tmp_tmp + 3].im = absxk;
          V[k + 3].re = V[g1_tmp_tmp + 3].re;
          V[k + 3].im = -absxk;
        }
      }
    } else {
      for (int g1_tmp_tmp{0}; g1_tmp_tmp < 16; g1_tmp_tmp++) {
        V[g1_tmp_tmp].re = rtNaN;
        V[g1_tmp_tmp].im = 0.0;
      }
    }
    if (scalea) {
      internal::reflapack::xzlascl(cscale, anrm, 4 - info, wr, info + 1);
      internal::reflapack::xzlascl(cscale, anrm, 4 - info, wi, info + 1);
      if (info != 0) {
        internal::reflapack::xzlascl(cscale, anrm, ilo - 1, wr, 1);
        internal::reflapack::xzlascl(cscale, anrm, ilo - 1, wi, 1);
      }
    }
    if (info != 0) {
      for (int i{ilo}; i <= info; i++) {
        wr[i - 1] = rtNaN;
        wi[i - 1] = 0.0;
      }
    }
    D[0].re = wr[0];
    D[0].im = wi[0];
    D[1].re = wr[1];
    D[1].im = wi[1];
    D[2].re = wr[2];
    D[2].im = wi[2];
    D[3].re = wr[3];
    D[3].im = wi[3];
  }
}

} // namespace coder

//
// File trailer for eigStandard.cpp
//
// [EOF]
//
