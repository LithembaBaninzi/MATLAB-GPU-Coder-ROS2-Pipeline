//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: updatedVisStateEst.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "updatedVisStateEst.h"
#include "camera.h"
#include "geometry_msgs_PoseStampedStruct.h"
#include "getCurrentTimestamp.h"
#include "imageDisplay.h"
#include "insertText.h"
#include "lower.h"
#include "mod.h"
#include "pause.h"
#include "ros2node.h"
#include "ros2publisher.h"
#include "ros2subscriber.h"
#include "rot90.h"
#include "rt_nonfinite.h"
#include "sprintf.h"
#include "std_msgs_StringStruct.h"
#include "strcmp.h"
#include "tFormPQRight.h"
#include "tic.h"
#include "toc.h"
#include "updatedVisStateEst_data.h"
#include "updatedVisStateEst_initialize.h"
#include "updatedVisStateEst_types.h"
#include "coder_array.h"
#include "mlros2_node.h"
#include "mlros2_pub.h"
#include "nanoP3p.h"
#include <cmath>
#include <cstdio>
#include <cstring>

// Custom Source Code
#include "nanoP3p.h"
// Function Declarations
static void b_sendStatus(const coder::b_ros2publisher &pub);

static void c_sendStatus(const coder::b_ros2publisher &pub);

static void d_sendStatus(const coder::b_ros2publisher &pub);

static void e_sendStatus(const coder::b_ros2publisher &pub);

static void f_sendStatus(const coder::b_ros2publisher &pub);

static void sendStatus(const coder::b_ros2publisher &pub);

static void sendStatus(const coder::b_ros2publisher &pub,
                       const coder::array<char, 2U> &txt);

// Function Definitions
//
// Arguments    : const coder::b_ros2publisher &pub
// Return Type  : void
//
static void b_sendStatus(const coder::b_ros2publisher &pub)
{
  static const char b_cv[24]{'P', 'o', 's', 'e', ' ', 'e', 's', 't',
                             'i', 'm', 'a', 't', 'i', 'o', 'n', ' ',
                             's', 't', 'a', 'r', 't', 'e', 'd', '.'};
  std_msgs_StringStruct_T msg;
  //  --- Helper: Send Status ---
  std_msgs_StringStruct(msg);
  msg.data.set_size(1, 24);
  for (int i{0}; i < 24; i++) {
    msg.data[i] = b_cv[i];
  }
  MATLABROS2Publisher_publish(pub.PublisherHelper, &msg);
  std::printf("[STATUS] %s\n", "Pose estimation started.");
  std::fflush(stdout);
}

//
// Arguments    : const coder::b_ros2publisher &pub
// Return Type  : void
//
static void c_sendStatus(const coder::b_ros2publisher &pub)
{
  static const char b_cv[24]{'P', 'o', 's', 'e', ' ', 'e', 's', 't',
                             'i', 'm', 'a', 't', 'i', 'o', 'n', ' ',
                             's', 't', 'o', 'p', 'p', 'e', 'd', '.'};
  std_msgs_StringStruct_T msg;
  //  --- Helper: Send Status ---
  std_msgs_StringStruct(msg);
  msg.data.set_size(1, 24);
  for (int i{0}; i < 24; i++) {
    msg.data[i] = b_cv[i];
  }
  MATLABROS2Publisher_publish(pub.PublisherHelper, &msg);
  std::printf("[STATUS] %s\n", "Pose estimation stopped.");
  std::fflush(stdout);
}

//
// Arguments    : const coder::b_ros2publisher &pub
// Return Type  : void
//
static void d_sendStatus(const coder::b_ros2publisher &pub)
{
  static const char b_cv[16]{'S', 'h', 'u', 't', 't', 'i', 'n', 'g',
                             ' ', 'd', 'o', 'w', 'n', '.', '.', '.'};
  std_msgs_StringStruct_T msg;
  //  --- Helper: Send Status ---
  std_msgs_StringStruct(msg);
  msg.data.set_size(1, 16);
  for (int i{0}; i < 16; i++) {
    msg.data[i] = b_cv[i];
  }
  MATLABROS2Publisher_publish(pub.PublisherHelper, &msg);
  std::printf("[STATUS] %s\n", "Shutting down...");
  std::fflush(stdout);
}

//
// Arguments    : const coder::b_ros2publisher &pub
// Return Type  : void
//
static void e_sendStatus(const coder::b_ros2publisher &pub)
{
  static const char b_cv[32]{'I', 'd', 'l', 'e', ' ', '-', ' ', 'W',
                             'a', 'i', 't', 'i', 'n', 'g', ' ', 'f',
                             'o', 'r', ' ', 'S', 'T', 'A', 'R', 'T',
                             ' ', 'c', 'o', 'm', 'm', 'a', 'n', 'd'};
  std_msgs_StringStruct_T msg;
  //  --- Helper: Send Status ---
  std_msgs_StringStruct(msg);
  msg.data.set_size(1, 32);
  for (int i{0}; i < 32; i++) {
    msg.data[i] = b_cv[i];
  }
  MATLABROS2Publisher_publish(pub.PublisherHelper, &msg);
  std::printf("[STATUS] %s\n", "Idle - Waiting for START command");
  std::fflush(stdout);
}

//
// Arguments    : const coder::b_ros2publisher &pub
// Return Type  : void
//
static void f_sendStatus(const coder::b_ros2publisher &pub)
{
  static const char b_cv[17]{'S', 'h', 'u', 't', 'd', 'o', 'w', 'n', ' ',
                             'c', 'o', 'm', 'p', 'l', 'e', 't', 'e'};
  std_msgs_StringStruct_T msg;
  //  --- Helper: Send Status ---
  std_msgs_StringStruct(msg);
  msg.data.set_size(1, 17);
  for (int i{0}; i < 17; i++) {
    msg.data[i] = b_cv[i];
  }
  MATLABROS2Publisher_publish(pub.PublisherHelper, &msg);
  std::printf("[STATUS] %s\n", "Shutdown complete");
  std::fflush(stdout);
}

//
// Arguments    : const coder::b_ros2publisher &pub
// Return Type  : void
//
static void sendStatus(const coder::b_ros2publisher &pub)
{
  static const char b_cv[33]{'R', 'e', 'a', 'd', 'y', '.', ' ', 'W', 'a',
                             'i', 't', 'i', 'n', 'g', ' ', 'f', 'o', 'r',
                             ' ', 'S', 'T', 'A', 'R', 'T', ' ', 'c', 'o',
                             'm', 'm', 'a', 'n', 'd', '.'};
  std_msgs_StringStruct_T msg;
  //  --- Helper: Send Status ---
  std_msgs_StringStruct(msg);
  msg.data.set_size(1, 33);
  for (int i{0}; i < 33; i++) {
    msg.data[i] = b_cv[i];
  }
  MATLABROS2Publisher_publish(pub.PublisherHelper, &msg);
  std::printf("[STATUS] %s\n", "Ready. Waiting for START command.");
  std::fflush(stdout);
}

//
// Arguments    : const coder::b_ros2publisher &pub
//                const coder::array<char, 2U> &txt
// Return Type  : void
//
static void sendStatus(const coder::b_ros2publisher &pub,
                       const coder::array<char, 2U> &txt)
{
  coder::array<char, 2U> varargin_1;
  std_msgs_StringStruct_T msg;
  int loop_ub;
  //  --- Helper: Send Status ---
  std_msgs_StringStruct(msg);
  loop_ub = txt.size(1);
  msg.data.set_size(1, txt.size(1));
  for (int i{0}; i < loop_ub; i++) {
    msg.data[i] = txt[i];
  }
  MATLABROS2Publisher_publish(pub.PublisherHelper, &msg);
  varargin_1.set_size(1, txt.size(1) + 1);
  for (int i{0}; i < loop_ub; i++) {
    varargin_1[i] = txt[i];
  }
  varargin_1[txt.size(1)] = '\x00';
  std::printf("[STATUS] %s\n", &varargin_1[0]);
  std::fflush(stdout);
}

//
// VISSTATEEST2 Visual state estimator with ROS2 control
//    Listens for start/stop commands via ROS2 and publishes pose estimates
//    Exits cleanly when stop command is received
//
// Arguments    : void
// Return Type  : void
//
void updatedVisStateEst()
{
  static const char b_cv[6]{'c', 'a', 'm', 'e', 'r', 'a'};
  static unsigned char frameRGB[691200];
  static unsigned char uv[691200];
  coder::b_ros2publisher pub_status;
  coder::nvidiacoder::common::camera cam;
  coder::nvidiacoder::common::imageDisplay dispObj;
  coder::ros2node p3pNode;
  coder::ros2publisher p3pPub;
  coder::ros2subscriber commandSub;
  coder::array<char, 2U> cmd_msg_data;
  coder::array<char, 2U> label;
  geometry_msgs_PoseStampedStruct_T p3pMsg;
  double frameCounter;
  double lastStatusTime_tv_nsec;
  double lastStatusTime_tv_sec;
  int b_index;
  bool isRunning;
  bool shouldExit;
  if (!isInitialized_updatedVisStateEst) {
    updatedVisStateEst_initialize();
  }
  cam.matlabCodegenIsDeleted = true;
  dispObj.matlabCodegenIsDeleted = true;
  //  Initializations
  //  Include library header
  //  Control flags (make them persistent for callbacks)
  isRunning = false;
  shouldExit = false;
  //  Jetson camera configuration
  coder::nvidiacoder::common::camera::b_camera(cam);
  //  Optional display (on Jetson monitor)
  coder::nvidiacoder::common::imageDisplay::b_imageDisplay(dispObj);
  //  Prepare frame buffers
  //     %% Init ROS2 nodes (Domain 0 for communication with MATLAB app)
  //  Domain 0 to match MATLAB app
  p3pNode.NodeHandle = MATLAB::getGlobalNodeHandle();
  UNUSED_PARAM(p3pNode.NodeHandle);
  //  Publisher for pose data
  //  p3pPub = ros2publisher(p3pNode, "/pose_p3p", "geometry_msgs/Pose");
  //  p3pMsg = ros2message("geometry_msgs/Pose");
  //  Publisher for pose data (PoseStamped - includes timestamp)
  p3pPub.init(p3pNode);
  geometry_msgs_PoseStampedStruct(p3pMsg);
  //  Publisher for status messages
  pub_status.init(p3pNode);
  //  Subscriber for control commands from MATLAB app
  //  Note: We can't use nested callbacks with codegen, so we'll poll
  commandSub.init(p3pNode);
  std::printf("ROS2 initialized. Waiting for START command...\n");
  std::fflush(stdout);
  sendStatus(pub_status);
  //     %% Main loop - wait for commands and process
  frameCounter = 0.0;
  lastStatusTime_tv_sec = coder::tic(lastStatusTime_tv_nsec);
  while (!shouldExit) {
    bool cmd_ok;
    //  Poll for new commands (instead of callback)
    cmd_ok = commandSub.receive(cmd_msg_data);
    //  Non-blocking
    if (cmd_ok) {
      int loop_ub_tmp;
      label.set_size(1, cmd_msg_data.size(1) + 1);
      loop_ub_tmp = cmd_msg_data.size(1);
      for (b_index = 0; b_index < loop_ub_tmp; b_index++) {
        label[b_index] = cmd_msg_data[b_index];
      }
      label[cmd_msg_data.size(1)] = '\x00';
      std::printf("Received command: %s\n", &label[0]);
      std::fflush(stdout);
      coder::lower(cmd_msg_data, label);
      if (coder::internal::b_strcmp(label)) {
        b_index = 0;
      } else if (coder::internal::c_strcmp(label)) {
        b_index = 1;
      } else if (coder::internal::d_strcmp(label)) {
        b_index = 2;
      } else {
        b_index = -1;
      }
      switch (b_index) {
      case 0:
        if (!isRunning) {
          isRunning = true;
          frameCounter = 0.0;
          std::printf("Starting pose estimation...\n");
          std::fflush(stdout);
          b_sendStatus(pub_status);
        }
        break;
      case 1:
        if (isRunning) {
          isRunning = false;
          std::printf("Stopping pose estimation...\n");
          std::fflush(stdout);
          c_sendStatus(pub_status);
          //  Display blank frame when stopped
          std::memset(&uv[0], 0, 691200U * sizeof(unsigned char));
          dispObj.image(uv);
        }
        break;
      case 2:
        std::printf("Shutdown command received.\n");
        std::fflush(stdout);
        d_sendStatus(pub_status);
        shouldExit = true;
        isRunning = false;
        break;
      default:
        label.set_size(1, cmd_msg_data.size(1) + 1);
        for (b_index = 0; b_index < loop_ub_tmp; b_index++) {
          label[b_index] = cmd_msg_data[b_index];
        }
        label[cmd_msg_data.size(1)] = '\x00';
        std::printf("Unknown command: %s\n", &label[0]);
        std::fflush(stdout);
        coder::b_sprintf(cmd_msg_data, label);
        sendStatus(pub_status, label);
        break;
      }
    }
    //  Check if we should be processing frames
    if (isRunning) {
      double p3pSoln[28];
      double quadPose[28];
      //  Capture frame
      cam.snapshot(uv);
      coder::rot90(uv, frameRGB);
      getCurrentTimestamp(p3pMsg.header.stamp.sec, p3pMsg.header.stamp.nanosec);
      frameCounter++;
      //  Display progress every 10 frames
      if (coder::b_mod(frameCounter) == 0.0) {
        if (frameCounter < 2.147483648E+9) {
          b_index = static_cast<int>(frameCounter);
        } else {
          b_index = MAX_int32_T;
        }
        std::printf("Processing frame %d...\n", b_index);
        std::fflush(stdout);
      }
      //  Call external CUDA P3P function
      nanoP3p(&frameRGB[0], &p3pSoln[0]);
      // convert to quad frame
      tFormPQRight(p3pSoln, quadPose);
      //  Populate ROS2 message
      p3pMsg.header.frame_id.set_size(1, 6);
      for (b_index = 0; b_index < 6; b_index++) {
        p3pMsg.header.frame_id[b_index] = b_cv[b_index];
      }
      //  Add this line
      p3pMsg.pose.position.x = quadPose[0];
      p3pMsg.pose.position.y = quadPose[1];
      p3pMsg.pose.position.z = quadPose[2];
      p3pMsg.pose.orientation.w = quadPose[3];
      p3pMsg.pose.orientation.x = quadPose[4];
      p3pMsg.pose.orientation.y = quadPose[5];
      p3pMsg.pose.orientation.z = quadPose[6];
      MATLABROS2Publisher_publish(p3pPub.PublisherHelper, &p3pMsg);
      //  Debug: Check if we got a valid pose
      if (!std::isnan(quadPose[0])) {
        if (coder::c_mod(frameCounter) == 0.0) {
          //  Print less frequently
          if (frameCounter < 2.147483648E+9) {
            b_index = static_cast<int>(frameCounter);
          } else {
            b_index = MAX_int32_T;
          }
          std::printf("Frame %d: Detected Pose: [%.3f, %.3f, %.3f, %.3f, %.3f, "
                      "%.3f, %.3f]\n",
                      b_index, quadPose[0], quadPose[1], quadPose[2],
                      quadPose[3], quadPose[4], quadPose[5], quadPose[6]);
          std::fflush(stdout);
        }
      } else if (coder::c_mod(frameCounter) == 0.0) {
        if (frameCounter < 2.147483648E+9) {
          b_index = static_cast<int>(frameCounter);
        } else {
          b_index = MAX_int32_T;
        }
        std::printf("Frame %d: No features detected (NaN)\n", b_index);
        std::fflush(stdout);
      }
      //  Display overlay
      // OVERLAYPOSEONIMAGE Superimpose pose array values on the image.
      // img_vis = fliplr(rot90(img_in, -1)); % flip for display so overlays
      // aren't mirrored poseVec = poseArr(:, s);
      if (!std::isnan(p3pSoln[0])) {
        coder::b_sprintf(p3pSoln[0], p3pSoln[1], p3pSoln[2], p3pSoln[3],
                         p3pSoln[4], p3pSoln[5], p3pSoln[6], label);
        coder::insertText(frameRGB, label);
        // ,
      }
      // mark (1,1)
      // img_out = rot90(fliplr(img_working));
      dispObj.image(frameRGB);
      //  Send heartbeat status every 5 seconds
      if (coder::toc(lastStatusTime_tv_sec, lastStatusTime_tv_nsec) > 5.0) {
        if (frameCounter < 2.147483648E+9) {
          b_index = static_cast<int>(frameCounter);
        } else {
          b_index = MAX_int32_T;
        }
        coder::b_sprintf(b_index, label);
        sendStatus(pub_status, label);
        lastStatusTime_tv_sec = coder::tic(lastStatusTime_tv_nsec);
      }
      //  Control frame rate (adjust as needed)
      coder::pause(0.033);
      //  ~30 FPS
    } else {
      //  Not running - send idle heartbeat every 5 seconds
      if (coder::toc(lastStatusTime_tv_sec, lastStatusTime_tv_nsec) > 5.0) {
        e_sendStatus(pub_status);
        lastStatusTime_tv_sec = coder::tic(lastStatusTime_tv_nsec);
      }
      //  Not running - sleep to reduce CPU usage
      coder::pause(1.0);
    }
  }
  //     %% Clean shutdown
  std::printf("\nShutting down cleanly...\n");
  std::fflush(stdout);
  f_sendStatus(pub_status);
  if (frameCounter < 2.147483648E+9) {
    b_index = static_cast<int>(frameCounter);
  } else {
    b_index = MAX_int32_T;
  }
  std::printf("Shutdown complete. Total frames processed: %d\n", b_index);
  std::fflush(stdout);
  //  Exit gracefully - let MATLAB handle cleanup
}

//
// File trailer for updatedVisStateEst.cpp
//
// [EOF]
//
