//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xzgebal.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "xzgebal.h"
#include "rt_nonfinite.h"
#include "xnrm2.h"
#include <cmath>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : double A[16]
//                int &ihi
//                double scale[4]
// Return Type  : int
//
namespace coder {
namespace internal {
namespace reflapack {
int xzgebal(double A[16], int &ihi, double scale[4])
{
  double b_scale;
  int exitg5;
  int i;
  int ilo;
  int ix;
  int ix0_tmp;
  int iy;
  int kend;
  int n;
  bool converged;
  bool notdone;
  scale[0] = 1.0;
  scale[1] = 1.0;
  scale[2] = 1.0;
  scale[3] = 1.0;
  ilo = 1;
  ihi = 4;
  notdone = true;
  do {
    exitg5 = 0;
    if (notdone) {
      int exitg4;
      notdone = false;
      ix0_tmp = ihi;
      do {
        exitg4 = 0;
        if (ix0_tmp > 0) {
          bool exitg6;
          converged = false;
          ix = 0;
          exitg6 = false;
          while ((!exitg6) && (ix <= ihi - 1)) {
            if ((ix + 1 == ix0_tmp) ||
                (!(A[(ix0_tmp + (ix << 2)) - 1] != 0.0))) {
              ix++;
            } else {
              converged = true;
              exitg6 = true;
            }
          }
          if (converged) {
            ix0_tmp--;
          } else {
            scale[ihi - 1] = ix0_tmp;
            if (ix0_tmp != ihi) {
              ix = (ix0_tmp - 1) << 2;
              iy = (ihi - 1) << 2;
              for (int k{0}; k < ihi; k++) {
                int temp_tmp;
                temp_tmp = ix + k;
                b_scale = A[temp_tmp];
                i = iy + k;
                A[temp_tmp] = A[i];
                A[i] = b_scale;
              }
              b_scale = A[ix0_tmp - 1];
              A[ix0_tmp - 1] = A[ihi - 1];
              A[ihi - 1] = b_scale;
              b_scale = A[ix0_tmp + 3];
              A[ix0_tmp + 3] = A[ihi + 3];
              A[ihi + 3] = b_scale;
              b_scale = A[ix0_tmp + 7];
              A[ix0_tmp + 7] = A[ihi + 7];
              A[ihi + 7] = b_scale;
              b_scale = A[ix0_tmp + 11];
              A[ix0_tmp + 11] = A[ihi + 11];
              A[ihi + 11] = b_scale;
            }
            exitg4 = 1;
          }
        } else {
          exitg4 = 2;
        }
      } while (exitg4 == 0);
      if (exitg4 == 1) {
        if (ihi == 1) {
          ilo = 1;
          ihi = 1;
          exitg5 = 1;
        } else {
          ihi--;
          notdone = true;
        }
      }
    } else {
      notdone = true;
      while (notdone) {
        bool exitg6;
        notdone = false;
        ix0_tmp = ilo;
        exitg6 = false;
        while ((!exitg6) && (ix0_tmp <= ihi)) {
          bool exitg7;
          converged = false;
          ix = ilo;
          exitg7 = false;
          while ((!exitg7) && (ix <= ihi)) {
            if ((ix == ix0_tmp) ||
                (!(A[(ix + ((ix0_tmp - 1) << 2)) - 1] != 0.0))) {
              ix++;
            } else {
              converged = true;
              exitg7 = true;
            }
          }
          if (converged) {
            ix0_tmp++;
          } else {
            scale[ilo - 1] = ix0_tmp;
            if (ix0_tmp != ilo) {
              int temp_tmp;
              ix = (ix0_tmp - 1) << 2;
              kend = (ilo - 1) << 2;
              for (int k{0}; k < ihi; k++) {
                temp_tmp = ix + k;
                b_scale = A[temp_tmp];
                i = kend + k;
                A[temp_tmp] = A[i];
                A[i] = b_scale;
              }
              ix = (kend + ix0_tmp) - 1;
              iy = (kend + ilo) - 1;
              n = 5 - ilo;
              for (int k{0}; k < n; k++) {
                temp_tmp = k << 2;
                kend = ix + temp_tmp;
                b_scale = A[kend];
                i = iy + temp_tmp;
                A[kend] = A[i];
                A[i] = b_scale;
              }
            }
            ilo++;
            notdone = true;
            exitg6 = true;
          }
        }
      }
      converged = false;
      exitg5 = 2;
    }
  } while (exitg5 == 0);
  if (exitg5 != 1) {
    bool exitg3;
    exitg3 = false;
    while ((!exitg3) && (!converged)) {
      int exitg2;
      converged = true;
      ix = ilo - 1;
      do {
        exitg2 = 0;
        if (ix + 1 <= ihi) {
          double absxk;
          double c;
          double ca;
          double r;
          double t;
          kend = (ihi - ilo) + 1;
          iy = ix << 2;
          c = blas::xnrm2(kend, A, iy + ilo);
          ix0_tmp = ((ilo - 1) << 2) + ix;
          r = 0.0;
          if (kend >= 1) {
            if (kend == 1) {
              r = std::abs(A[ix0_tmp]);
            } else {
              b_scale = 3.3121686421112381E-170;
              kend = (ix0_tmp + ((kend - 1) << 2)) + 1;
              for (int k{ix0_tmp + 1}; k <= kend; k += 4) {
                absxk = std::abs(A[k - 1]);
                if (absxk > b_scale) {
                  t = b_scale / absxk;
                  r = r * t * t + 1.0;
                  b_scale = absxk;
                } else {
                  t = absxk / b_scale;
                  r += t * t;
                }
              }
              r = b_scale * std::sqrt(r);
            }
          }
          if (ihi < 1) {
            kend = 0;
          } else {
            kend = 1;
            if (ihi > 1) {
              b_scale = std::abs(A[iy]);
              for (int k{2}; k <= ihi; k++) {
                t = std::abs(A[(iy + k) - 1]);
                if (t > b_scale) {
                  kend = k;
                  b_scale = t;
                }
              }
            }
          }
          ca = std::abs(A[(kend + iy) - 1]);
          n = 5 - ilo;
          if (5 - ilo < 1) {
            kend = 0;
          } else {
            kend = 1;
            if (5 - ilo > 1) {
              b_scale = std::abs(A[ix0_tmp]);
              for (int k{2}; k <= n; k++) {
                t = std::abs(A[ix0_tmp + ((k - 1) << 2)]);
                if (t > b_scale) {
                  kend = k;
                  b_scale = t;
                }
              }
            }
          }
          b_scale = std::abs(A[ix + (((kend + ilo) - 2) << 2)]);
          if ((c == 0.0) || (r == 0.0)) {
            ix++;
          } else {
            double f;
            int exitg1;
            absxk = r / 2.0;
            f = 1.0;
            t = c + r;
            do {
              exitg1 = 0;
              if ((c < absxk) &&
                  (std::fmax(f, std::fmax(c, ca)) < 4.9896007738368E+291) &&
                  (std::fmin(r, std::fmin(absxk, b_scale)) >
                   2.0041683600089728E-292)) {
                if (std::isnan(((((c + f) + ca) + r) + absxk) + b_scale)) {
                  exitg1 = 1;
                } else {
                  f *= 2.0;
                  c *= 2.0;
                  ca *= 2.0;
                  r /= 2.0;
                  absxk /= 2.0;
                  b_scale /= 2.0;
                }
              } else {
                absxk = c / 2.0;
                while ((absxk >= r) &&
                       (std::fmax(r, b_scale) < 4.9896007738368E+291) &&
                       (std::fmin(std::fmin(f, c), std::fmin(absxk, ca)) >
                        2.0041683600089728E-292)) {
                  f /= 2.0;
                  c /= 2.0;
                  absxk /= 2.0;
                  ca /= 2.0;
                  r *= 2.0;
                  b_scale *= 2.0;
                }
                if ((!(c + r >= 0.95 * t)) &&
                    ((!(f < 1.0)) || (!(scale[ix] < 1.0)) ||
                     (!(f * scale[ix] <= 1.0020841800044864E-292))) &&
                    ((!(f > 1.0)) || (!(scale[ix] > 1.0)) ||
                     (!(scale[ix] >= 9.9792015476736E+291 / f)))) {
                  b_scale = 1.0 / f;
                  scale[ix] *= f;
                  kend = ix0_tmp + 1;
                  i = (ix0_tmp + ((4 - ilo) << 2)) + 1;
                  for (int k{kend}; k <= i; k += 4) {
                    A[k - 1] *= b_scale;
                  }
                  i = iy + ihi;
                  for (int k{iy + 1}; k <= i; k++) {
                    A[k - 1] *= f;
                  }
                  converged = false;
                }
                exitg1 = 2;
              }
            } while (exitg1 == 0);
            if (exitg1 == 1) {
              exitg2 = 2;
            } else {
              ix++;
            }
          }
        } else {
          exitg2 = 1;
        }
      } while (exitg2 == 0);
      if (exitg2 != 1) {
        exitg3 = true;
      }
    }
  }
  return ilo;
}

} // namespace reflapack
} // namespace internal
} // namespace coder

//
// File trailer for xzgebal.cpp
//
// [EOF]
//
