//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: ros2subscriber.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "ros2subscriber.h"
#include "ros2node.h"
#include "rt_nonfinite.h"
#include "setQOSProfile.h"
#include "std_msgs_StringStruct.h"
#include "updatedVisStateEst_data.h"
#include "updatedVisStateEst_types.h"
#include "coder_array.h"
#include "mlros2_node.h"
#include "mlros2_sub.h"
#include "rclcpp/rclcpp.hpp"
#include "rmw/qos_profiles.h"

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
namespace coder {
void ros2subscriber::callback()
{
  MessageCount++;
}

//
// Arguments    : void
// Return Type  : void
//
void ros2subscriber::deadline_callback() const
{
  if (IsInitialized) {
    MATLABROS2Subscriber_deadlineMissedWarning(SubscriberHelper, NodeHandle);
  }
}

//
// Arguments    : void
// Return Type  : void
//
void ros2subscriber::incompatible_qos_callback() const
{
  if (IsInitialized) {
    MATLABROS2Subscriber_incompatibleQoSWarning(SubscriberHelper, NodeHandle);
  }
}

//
// Arguments    : void
// Return Type  : void
//
void ros2subscriber::liveliness_callback() const
{
  if (IsInitialized) {
    MATLABROS2Subscriber_livelinessChangedWarning(SubscriberHelper, NodeHandle);
  }
}

//
// Arguments    : void
// Return Type  : void
//
void ros2subscriber::message_lost_callback() const
{
  if (IsInitialized) {
    MATLABROS2Subscriber_messageLostWarning(SubscriberHelper, NodeHandle);
  }
}

//
// Arguments    : ros2node &node
// Return Type  : ros2subscriber *
//
ros2subscriber *ros2subscriber::init(ros2node &node)
{
  static const char resolvedTopic[22]{'/', 'j', 'e', 't', 's', 'o', 'n', '/',
                                      'c', 'a', 'm', 'e', 'r', 'a', '/', 'c',
                                      'o', 'm', 'm', 'a', 'n', 'd'};
  static const char b_cv[8]{'k', 'e', 'e', 'p', 'l', 'a', 's', 't'};
  static const char cv1[8]{'r', 'e', 'l', 'i', 'a', 'b', 'l', 'e'};
  static const char cv2[8]{'v', 'o', 'l', 'a', 't', 'i', 'l', 'e'};
  ros2subscriber *obj;
  obj = this;
  obj->IsInitialized = false;
  for (int i{0}; i < 22; i++) {
    obj->TopicName[i] = resolvedTopic[i];
  }
  obj->Depth = 1.0;
  for (int i{0}; i < 8; i++) {
    obj->History[i] = b_cv[i];
    obj->Reliability[i] = cv1[i];
    obj->Durability[i] = cv2[i];
  }
  obj->Deadline = 0.0;
  obj->Lifespan = 0.0;
  for (int i{0}; i < 9; i++) {
    obj->Liveliness[i] = cv[i];
  }
  rmw_qos_profile_t qos_profile;
  obj->LeaseDuration = 0.0;
  obj->AvoidROSNamespaceConventions = false;
  qos_profile = ros::ros2::internal::setQOSProfile(
      rmw_qos_profile_default, obj->Depth, obj->Reliability, obj->Deadline,
      obj->Lifespan, obj->Liveliness, obj->LeaseDuration,
      obj->AvoidROSNamespaceConventions);
  obj->MessageCount = 0.0;
  std_msgs_StringStruct(obj->MsgStruct);
  auto structPtr = (&obj->MsgStruct);
  obj->SubscriberHelper = std::unique_ptr<
      MATLABROS2Subscriber<std_msgs::msg::String, std_msgs_StringStruct_T>>(
      new MATLABROS2Subscriber<std_msgs::msg::String, std_msgs_StringStruct_T>(
          structPtr, [this] { this->callback(); },
          [this] { this->deadline_callback(); },
          [this] { this->liveliness_callback(); },
          [this] { this->message_lost_callback(); },
          [this] { this->incompatible_qos_callback(); })); //();
  obj->NodeHandle = node.NodeHandle;
  MATLABROS2Subscriber_createSubscriber(obj->SubscriberHelper, node.NodeHandle,
                                        &obj->TopicName[0], 22.0, qos_profile);
  obj->callback();
  obj->deadline_callback();
  obj->liveliness_callback();
  obj->message_lost_callback();
  obj->incompatible_qos_callback();
  obj->IsInitialized = true;
  return obj;
}

//
// Arguments    : array<char, 2U> &receivedMsg_data
// Return Type  : bool
//
bool ros2subscriber::receive(array<char, 2U> &receivedMsg_data) const
{
  rcl_duration_value_t tTimeoutNsec;
  ::rclcpp::Clock::SharedPtr tClock;
  ::rclcpp::Time tStop;
  double nMessages;
  int loop_ub;
  bool exitg1;
  bool status;
  nMessages = MessageCount;
  tTimeoutNsec = RCL_S_TO_NS(0.01);
  tClock = std::make_shared<rclcpp::Clock>(RCL_ROS_TIME); //();
  tStop = tClock->now() + rclcpp::Duration::from_nanoseconds(tTimeoutNsec);
  status = true;
  exitg1 = false;
  while ((!exitg1) && (MessageCount == nMessages)) {
    ::rclcpp::Time currentTime;
    currentTime = tClock->now(); //(tClock);
    if (currentTime >= tStop) {
      status = false;
      exitg1 = true;
    }
  }
  char statusText[7];
  getStatusText(status, &statusText[0]);
  MATLABROS2Subscriber_lock(SubscriberHelper);
  receivedMsg_data.set_size(1, MsgStruct.data.size(1));
  loop_ub = MsgStruct.data.size(1);
  for (int i{0}; i < loop_ub; i++) {
    receivedMsg_data[i] = MsgStruct.data[i];
  }
  MATLABROS2Subscriber_unlock(SubscriberHelper);
  return status;
}

} // namespace coder

//
// File trailer for ros2subscriber.cpp
//
// [EOF]
//
