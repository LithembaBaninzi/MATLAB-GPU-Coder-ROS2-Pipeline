//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: updatedVisStateEst_terminate.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "updatedVisStateEst_terminate.h"
#include "rt_nonfinite.h"
#include "updatedVisStateEst_data.h"

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void updatedVisStateEst_terminate()
{
  isInitialized_updatedVisStateEst = false;
}

//
// File trailer for updatedVisStateEst_terminate.cpp
//
// [EOF]
//
