//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: geometry_msgs_PoseStampedStruct.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "geometry_msgs_PoseStampedStruct.h"
#include "geometry_msgs_PoseStruct.h"
#include "rt_nonfinite.h"
#include "std_msgs_HeaderStruct.h"
#include "updatedVisStateEst_types.h"

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Message struct definition for geometry_msgs/PoseStamped
//
// Arguments    : geometry_msgs_PoseStampedStruct_T &msg
// Return Type  : void
//
void geometry_msgs_PoseStampedStruct(geometry_msgs_PoseStampedStruct_T &msg)
{
  static const char b_cv[25]{'g', 'e', 'o', 'm', 'e', 't', 'r', 'y', '_',
                             'm', 's', 'g', 's', '/', 'P', 'o', 's', 'e',
                             'S', 't', 'a', 'm', 'p', 'e', 'd'};
  for (int i{0}; i < 25; i++) {
    msg.MessageType[i] = b_cv[i];
  }
  std_msgs_HeaderStruct(msg.header);
  geometry_msgs_PoseStruct(msg.pose);
  //(&msg);
}

//
// File trailer for geometry_msgs_PoseStampedStruct.cpp
//
// [EOF]
//
