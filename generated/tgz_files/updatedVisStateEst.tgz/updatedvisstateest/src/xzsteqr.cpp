//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xzsteqr.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "xzsteqr.h"
#include "rt_nonfinite.h"
#include "xdlaev2.h"
#include "xzlartg.h"
#include "xzlascl.h"
#include <cmath>

// Custom Source Code
#include "nanoP3p.h"
// Function Declarations
namespace coder {
namespace internal {
namespace reflapack {
static void b_rotateRight(int n, double z[16], int iz0, const double cs[6],
                          int ic0, int is0);

static void rotateRight(int n, double z[16], int iz0, const double cs[6],
                        int ic0, int is0);

} // namespace reflapack
} // namespace internal
} // namespace coder

// Function Definitions
//
// Arguments    : int n
//                double z[16]
//                int iz0
//                const double cs[6]
//                int ic0
//                int is0
// Return Type  : void
//
namespace coder {
namespace internal {
namespace reflapack {
static void b_rotateRight(int n, double z[16], int iz0, const double cs[6],
                          int ic0, int is0)
{
  for (int j{0}; j <= n - 2; j++) {
    double ctemp;
    double stemp;
    int offsetj;
    int offsetjp1;
    ctemp = cs[(ic0 + j) - 1];
    stemp = cs[(is0 + j) - 1];
    offsetj = ((j << 2) + iz0) - 2;
    offsetjp1 = (((j + 1) << 2) + iz0) - 2;
    if ((ctemp != 1.0) || (stemp != 0.0)) {
      double d;
      double temp;
      temp = z[offsetjp1 + 1];
      d = z[offsetj + 1];
      z[offsetjp1 + 1] = ctemp * temp - stemp * d;
      d = stemp * temp + ctemp * d;
      z[offsetj + 1] = d;
      temp = z[offsetjp1 + 2];
      d = z[offsetj + 2];
      z[offsetjp1 + 2] = ctemp * temp - stemp * d;
      d = stemp * temp + ctemp * d;
      z[offsetj + 2] = d;
      temp = z[offsetjp1 + 3];
      d = z[offsetj + 3];
      z[offsetjp1 + 3] = ctemp * temp - stemp * d;
      d = stemp * temp + ctemp * d;
      z[offsetj + 3] = d;
      temp = z[offsetjp1 + 4];
      d = z[offsetj + 4];
      z[offsetjp1 + 4] = ctemp * temp - stemp * d;
      d = stemp * temp + ctemp * d;
      z[offsetj + 4] = d;
    }
  }
}

//
// Arguments    : int n
//                double z[16]
//                int iz0
//                const double cs[6]
//                int ic0
//                int is0
// Return Type  : void
//
static void rotateRight(int n, double z[16], int iz0, const double cs[6],
                        int ic0, int is0)
{
  int i;
  i = n - 1;
  for (int j{i}; j >= 1; j--) {
    double ctemp;
    double stemp;
    int offsetj;
    int offsetjp1;
    ctemp = cs[(ic0 + j) - 2];
    stemp = cs[(is0 + j) - 2];
    offsetj = (((j - 1) << 2) + iz0) - 2;
    offsetjp1 = ((j << 2) + iz0) - 2;
    if ((ctemp != 1.0) || (stemp != 0.0)) {
      double d;
      double temp;
      temp = z[offsetjp1 + 1];
      d = z[offsetj + 1];
      z[offsetjp1 + 1] = ctemp * temp - stemp * d;
      d = stemp * temp + ctemp * d;
      z[offsetj + 1] = d;
      temp = z[offsetjp1 + 2];
      d = z[offsetj + 2];
      z[offsetjp1 + 2] = ctemp * temp - stemp * d;
      d = stemp * temp + ctemp * d;
      z[offsetj + 2] = d;
      temp = z[offsetjp1 + 3];
      d = z[offsetj + 3];
      z[offsetjp1 + 3] = ctemp * temp - stemp * d;
      d = stemp * temp + ctemp * d;
      z[offsetj + 3] = d;
      temp = z[offsetjp1 + 4];
      d = z[offsetj + 4];
      z[offsetjp1 + 4] = ctemp * temp - stemp * d;
      d = stemp * temp + ctemp * d;
      z[offsetj + 4] = d;
    }
  }
}

//
// Arguments    : double d[4]
//                double e[3]
//                double z[16]
// Return Type  : int
//
int xzsteqr(double d[4], double e[3], double z[16])
{
  double work[6];
  double c;
  double s;
  double tst;
  int i;
  int info;
  int jtot;
  int l1;
  info = 0;
  for (i = 0; i < 6; i++) {
    work[i] = 0.0;
  }
  jtot = 0;
  l1 = 1;
  int exitg1;
  do {
    exitg1 = 0;
    if (l1 > 4) {
      for (jtot = 0; jtot < 3; jtot++) {
        double p;
        int iscale;
        int ix;
        iscale = jtot;
        p = d[jtot];
        for (ix = jtot + 2; ix < 5; ix++) {
          c = d[ix - 1];
          if (c < p) {
            iscale = ix - 1;
            p = c;
          }
        }
        if (iscale != jtot) {
          d[iscale] = d[jtot];
          d[jtot] = p;
          ix = jtot << 2;
          iscale <<= 2;
          tst = z[ix];
          z[ix] = z[iscale];
          z[iscale] = tst;
          tst = z[ix + 1];
          z[ix + 1] = z[iscale + 1];
          z[iscale + 1] = tst;
          tst = z[ix + 2];
          z[ix + 2] = z[iscale + 2];
          z[iscale + 2] = tst;
          tst = z[ix + 3];
          z[ix + 3] = z[iscale + 3];
          z[iscale + 3] = tst;
        }
      }
      exitg1 = 1;
    } else {
      int l;
      int lend;
      int lendsv;
      int lsv;
      int m;
      bool exitg2;
      if (l1 > 1) {
        e[l1 - 2] = 0.0;
      }
      m = l1;
      exitg2 = false;
      while ((!exitg2) && (m < 4)) {
        tst = std::abs(e[m - 1]);
        if (tst == 0.0) {
          exitg2 = true;
        } else if (tst <= std::sqrt(std::abs(d[m - 1])) *
                              std::sqrt(std::abs(d[m])) *
                              2.2204460492503131E-16) {
          e[m - 1] = 0.0;
          exitg2 = true;
        } else {
          m++;
        }
      }
      l = l1 - 1;
      lsv = l1;
      lend = m;
      lendsv = m;
      l1 = m + 1;
      if (m != l + 1) {
        double anorm;
        int iscale;
        int ix;
        ix = m - l;
        if (ix <= 0) {
          anorm = 0.0;
        } else {
          anorm = std::abs(d[(l + ix) - 1]);
          i = 0;
          exitg2 = false;
          while ((!exitg2) && (i <= ix - 2)) {
            iscale = l + i;
            tst = std::abs(d[iscale]);
            if (std::isnan(tst)) {
              anorm = rtNaN;
              exitg2 = true;
            } else {
              if (tst > anorm) {
                anorm = tst;
              }
              tst = std::abs(e[iscale]);
              if (std::isnan(tst)) {
                anorm = rtNaN;
                exitg2 = true;
              } else {
                if (tst > anorm) {
                  anorm = tst;
                }
                i++;
              }
            }
          }
        }
        iscale = 0;
        if (!(anorm == 0.0)) {
          if (std::isinf(anorm) || std::isnan(anorm)) {
            d[0] = rtNaN;
            d[1] = rtNaN;
            d[2] = rtNaN;
            d[3] = rtNaN;
            for (ix = 0; ix < 16; ix++) {
              z[ix] = rtNaN;
            }
            exitg1 = 1;
          } else {
            if (anorm > 2.2346346549904327E+153) {
              iscale = 1;
              xzlascl(anorm, 2.2346346549904327E+153, ix, d, l + 1);
              b_xzlascl(anorm, 2.2346346549904327E+153, ix - 1, e, l + 1);
            } else if (anorm < 3.02546243347603E-123) {
              iscale = 2;
              xzlascl(anorm, 3.02546243347603E-123, ix, d, l + 1);
              b_xzlascl(anorm, 3.02546243347603E-123, ix - 1, e, l + 1);
            }
            if (std::abs(d[m - 1]) < std::abs(d[l])) {
              lend = lsv;
              l = m - 1;
            }
            if (lend > l + 1) {
              int exitg4;
              do {
                exitg4 = 0;
                if (l + 1 != lend) {
                  m = l + 1;
                  exitg2 = false;
                  while ((!exitg2) && (m < lend)) {
                    tst = std::abs(e[m - 1]);
                    if (tst * tst <= 4.9303806576313238E-32 *
                                             std::abs(d[m - 1]) *
                                             std::abs(d[m]) +
                                         2.2250738585072014E-308) {
                      exitg2 = true;
                    } else {
                      m++;
                    }
                  }
                } else {
                  m = lend;
                }
                if (m < lend) {
                  e[m - 1] = 0.0;
                }
                if (m == l + 1) {
                  l++;
                  if (l + 1 > lend) {
                    exitg4 = 1;
                  }
                } else if (m == l + 2) {
                  d[l] = xdlaev2(d[l], e[l], d[l + 1], c, work[l], tst);
                  d[l + 1] = c;
                  work[l + 3] = tst;
                  rotateRight(2, z, (l << 2) + 1, work, l + 1, l + 4);
                  e[l] = 0.0;
                  l += 2;
                  if (l + 1 > lend) {
                    exitg4 = 1;
                  }
                } else if (jtot == 120) {
                  exitg4 = 1;
                } else {
                  double b;
                  double g;
                  double p;
                  jtot++;
                  g = (d[l + 1] - d[l]) / (2.0 * e[l]);
                  tst = std::abs(g);
                  if (tst < 1.0) {
                    tst = std::sqrt(tst * tst + 1.0);
                  } else if (tst > 1.0) {
                    b = 1.0 / tst;
                    tst *= std::sqrt(b * b + 1.0);
                  } else {
                    tst *= 1.4142135623730951;
                  }
                  if (!(g >= 0.0)) {
                    tst = -tst;
                  }
                  g = (d[m - 1] - d[l]) + e[l] / (g + tst);
                  tst = 1.0;
                  c = 1.0;
                  p = 0.0;
                  ix = m - 1;
                  for (i = ix; i >= l + 1; i--) {
                    double r;
                    r = e[i - 1];
                    b = c * r;
                    c = xzlartg(g, tst * r, s, r);
                    tst = s;
                    if (i != m - 1) {
                      e[i] = r;
                    }
                    g = d[i] - p;
                    r = (d[i - 1] - g) * s + 2.0 * c * b;
                    p = s * r;
                    d[i] = g + p;
                    g = c * r - b;
                    work[i - 1] = c;
                    work[i + 2] = -s;
                  }
                  rotateRight(m - l, z, (l << 2) + 1, work, l + 1, l + 4);
                  d[l] -= p;
                  e[l] = g;
                }
              } while (exitg4 == 0);
            } else {
              int exitg3;
              do {
                exitg3 = 0;
                if (l + 1 != lend) {
                  m = l + 1;
                  exitg2 = false;
                  while ((!exitg2) && (m > lend)) {
                    tst = std::abs(e[m - 2]);
                    if (tst * tst <= 4.9303806576313238E-32 *
                                             std::abs(d[m - 1]) *
                                             std::abs(d[m - 2]) +
                                         2.2250738585072014E-308) {
                      exitg2 = true;
                    } else {
                      m--;
                    }
                  }
                } else {
                  m = lend;
                }
                if (m > lend) {
                  e[m - 2] = 0.0;
                }
                if (m == l + 1) {
                  l--;
                  if (l + 1 < lend) {
                    exitg3 = 1;
                  }
                } else if (m == l) {
                  d[l - 1] =
                      xdlaev2(d[l - 1], e[l - 1], d[l], c, work[m - 1], tst);
                  d[l] = c;
                  work[m + 2] = tst;
                  b_rotateRight(2, z, ((l - 1) << 2) + 1, work, m, m + 3);
                  e[l - 1] = 0.0;
                  l -= 2;
                  if (l + 1 < lend) {
                    exitg3 = 1;
                  }
                } else if (jtot == 120) {
                  exitg3 = 1;
                } else {
                  double b;
                  double g;
                  double p;
                  jtot++;
                  c = e[l - 1];
                  g = (d[l - 1] - d[l]) / (2.0 * c);
                  tst = std::abs(g);
                  if (tst < 1.0) {
                    tst = std::sqrt(tst * tst + 1.0);
                  } else if (tst > 1.0) {
                    b = 1.0 / tst;
                    tst *= std::sqrt(b * b + 1.0);
                  } else {
                    tst *= 1.4142135623730951;
                  }
                  if (!(g >= 0.0)) {
                    tst = -tst;
                  }
                  g = (d[m - 1] - d[l]) + c / (g + tst);
                  tst = 1.0;
                  c = 1.0;
                  p = 0.0;
                  for (i = m; i <= l; i++) {
                    double r;
                    r = e[i - 1];
                    b = c * r;
                    c = xzlartg(g, tst * r, s, r);
                    tst = s;
                    if (i != m) {
                      e[i - 2] = r;
                    }
                    g = d[i - 1] - p;
                    r = (d[i] - g) * s + 2.0 * c * b;
                    p = s * r;
                    d[i - 1] = g + p;
                    g = c * r - b;
                    work[i - 1] = c;
                    work[i + 2] = s;
                  }
                  b_rotateRight((l - m) + 2, z, ((m - 1) << 2) + 1, work, m,
                                m + 3);
                  d[l] -= p;
                  e[l - 1] = g;
                }
              } while (exitg3 == 0);
            }
            if (iscale == 1) {
              ix = lendsv - lsv;
              xzlascl(2.2346346549904327E+153, anorm, ix + 1, d, lsv);
              b_xzlascl(2.2346346549904327E+153, anorm, ix, e, lsv);
            } else if (iscale == 2) {
              ix = lendsv - lsv;
              xzlascl(3.02546243347603E-123, anorm, ix + 1, d, lsv);
              b_xzlascl(3.02546243347603E-123, anorm, ix, e, lsv);
            }
            if (jtot >= 120) {
              if (e[0] != 0.0) {
                info = 1;
              }
              if (e[1] != 0.0) {
                info++;
              }
              if (e[2] != 0.0) {
                info++;
              }
              exitg1 = 1;
            }
          }
        }
      }
    }
  } while (exitg1 == 0);
  return info;
}

} // namespace reflapack
} // namespace internal
} // namespace coder

//
// File trailer for xzsteqr.cpp
//
// [EOF]
//
