//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xzlarfg.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "xzlarfg.h"
#include "rt_nonfinite.h"
#include "xnrm2.h"
#include <cmath>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : int n
//                double &alpha1
//                double x[3]
// Return Type  : double
//
namespace coder {
namespace internal {
namespace reflapack {
double xzlarfg(int n, double &alpha1, double x[3])
{
  double tau;
  tau = 0.0;
  if (n > 0) {
    double xnorm;
    xnorm = blas::xnrm2(n - 1, x);
    if (xnorm != 0.0) {
      double a_tmp;
      a_tmp = std::abs(alpha1);
      xnorm = std::abs(xnorm);
      if (a_tmp < xnorm) {
        a_tmp /= xnorm;
        xnorm *= std::sqrt(a_tmp * a_tmp + 1.0);
      } else if (a_tmp > xnorm) {
        xnorm /= a_tmp;
        xnorm = a_tmp * std::sqrt(xnorm * xnorm + 1.0);
      } else if (std::isnan(xnorm)) {
        xnorm = rtNaN;
      } else {
        xnorm = a_tmp * 1.4142135623730951;
      }
      if (alpha1 >= 0.0) {
        xnorm = -xnorm;
      }
      if (std::abs(xnorm) < 1.0020841800044864E-292) {
        int knt;
        knt = 0;
        do {
          knt++;
          for (int k{2}; k <= n; k++) {
            x[k - 1] *= 9.9792015476736E+291;
          }
          xnorm *= 9.9792015476736E+291;
          alpha1 *= 9.9792015476736E+291;
        } while ((std::abs(xnorm) < 1.0020841800044864E-292) && (knt < 20));
        a_tmp = std::abs(alpha1);
        xnorm = std::abs(blas::xnrm2(n - 1, x));
        if (a_tmp < xnorm) {
          a_tmp /= xnorm;
          xnorm *= std::sqrt(a_tmp * a_tmp + 1.0);
        } else if (a_tmp > xnorm) {
          xnorm /= a_tmp;
          xnorm = a_tmp * std::sqrt(xnorm * xnorm + 1.0);
        } else if (std::isnan(xnorm)) {
          xnorm = rtNaN;
        } else {
          xnorm = a_tmp * 1.4142135623730951;
        }
        if (alpha1 >= 0.0) {
          xnorm = -xnorm;
        }
        tau = (xnorm - alpha1) / xnorm;
        a_tmp = 1.0 / (alpha1 - xnorm);
        for (int k{2}; k <= n; k++) {
          x[k - 1] *= a_tmp;
        }
        for (int k{0}; k < knt; k++) {
          xnorm *= 1.0020841800044864E-292;
        }
        alpha1 = xnorm;
      } else {
        tau = (xnorm - alpha1) / xnorm;
        a_tmp = 1.0 / (alpha1 - xnorm);
        for (int k{2}; k <= n; k++) {
          x[k - 1] *= a_tmp;
        }
        alpha1 = xnorm;
      }
    }
  }
  return tau;
}

//
// Arguments    : int n
//                double &alpha1
//                double x[16]
//                int ix0
// Return Type  : double
//
double xzlarfg(int n, double &alpha1, double x[16], int ix0)
{
  double tau;
  tau = 0.0;
  if (n > 0) {
    double xnorm;
    xnorm = blas::xnrm2(n - 1, x, ix0);
    if (xnorm != 0.0) {
      double a_tmp;
      a_tmp = std::abs(alpha1);
      xnorm = std::abs(xnorm);
      if (a_tmp < xnorm) {
        a_tmp /= xnorm;
        xnorm *= std::sqrt(a_tmp * a_tmp + 1.0);
      } else if (a_tmp > xnorm) {
        xnorm /= a_tmp;
        xnorm = a_tmp * std::sqrt(xnorm * xnorm + 1.0);
      } else if (std::isnan(xnorm)) {
        xnorm = rtNaN;
      } else {
        xnorm = a_tmp * 1.4142135623730951;
      }
      if (alpha1 >= 0.0) {
        xnorm = -xnorm;
      }
      if (std::abs(xnorm) < 1.0020841800044864E-292) {
        int i;
        int knt;
        knt = 0;
        i = (ix0 + n) - 2;
        do {
          knt++;
          for (int k{ix0}; k <= i; k++) {
            x[k - 1] *= 9.9792015476736E+291;
          }
          xnorm *= 9.9792015476736E+291;
          alpha1 *= 9.9792015476736E+291;
        } while ((std::abs(xnorm) < 1.0020841800044864E-292) && (knt < 20));
        a_tmp = std::abs(alpha1);
        xnorm = std::abs(blas::xnrm2(n - 1, x, ix0));
        if (a_tmp < xnorm) {
          a_tmp /= xnorm;
          xnorm *= std::sqrt(a_tmp * a_tmp + 1.0);
        } else if (a_tmp > xnorm) {
          xnorm /= a_tmp;
          xnorm = a_tmp * std::sqrt(xnorm * xnorm + 1.0);
        } else if (std::isnan(xnorm)) {
          xnorm = rtNaN;
        } else {
          xnorm = a_tmp * 1.4142135623730951;
        }
        if (alpha1 >= 0.0) {
          xnorm = -xnorm;
        }
        tau = (xnorm - alpha1) / xnorm;
        a_tmp = 1.0 / (alpha1 - xnorm);
        for (int k{ix0}; k <= i; k++) {
          x[k - 1] *= a_tmp;
        }
        for (int k{0}; k < knt; k++) {
          xnorm *= 1.0020841800044864E-292;
        }
        alpha1 = xnorm;
      } else {
        int i;
        tau = (xnorm - alpha1) / xnorm;
        a_tmp = 1.0 / (alpha1 - xnorm);
        i = (ix0 + n) - 2;
        for (int k{ix0}; k <= i; k++) {
          x[k - 1] *= a_tmp;
        }
        alpha1 = xnorm;
      }
    }
  }
  return tau;
}

} // namespace reflapack
} // namespace internal
} // namespace coder

//
// File trailer for xzlarfg.cpp
//
// [EOF]
//
