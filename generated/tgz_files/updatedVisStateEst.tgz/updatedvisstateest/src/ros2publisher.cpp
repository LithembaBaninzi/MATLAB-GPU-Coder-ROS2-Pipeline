//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: ros2publisher.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "ros2publisher.h"
#include "geometry_msgs_PoseStampedStruct.h"
#include "ros2node.h"
#include "rt_nonfinite.h"
#include "setQOSProfile.h"
#include "std_msgs_StringStruct.h"
#include "updatedVisStateEst_data.h"
#include "updatedVisStateEst_types.h"
#include "mlros2_node.h"
#include "mlros2_pub.h"
#include "rmw/qos_profiles.h"

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
namespace coder {
void ros2publisher::deadline_callback() const
{
  if (IsInitialized) {
    MATLABROS2Publisher_deadlineMissedWarning(PublisherHelper, NodeHandle);
  }
}

//
// Arguments    : void
// Return Type  : void
//
void b_ros2publisher::deadline_callback() const
{
  if (IsInitialized) {
    MATLABROS2Publisher_deadlineMissedWarning(PublisherHelper, NodeHandle);
  }
}

//
// Arguments    : void
// Return Type  : void
//
void ros2publisher::incompatible_qos_callback() const
{
  if (IsInitialized) {
    MATLABROS2Publisher_incompatibleQoSWarning(PublisherHelper, NodeHandle);
  }
}

//
// Arguments    : void
// Return Type  : void
//
void b_ros2publisher::incompatible_qos_callback() const
{
  if (IsInitialized) {
    MATLABROS2Publisher_incompatibleQoSWarning(PublisherHelper, NodeHandle);
  }
}

//
// Arguments    : void
// Return Type  : void
//
void ros2publisher::liveliness_callback() const
{
  if (IsInitialized) {
    MATLABROS2Publisher_livelinessLostWarning(PublisherHelper, NodeHandle);
  }
}

//
// Arguments    : void
// Return Type  : void
//
void b_ros2publisher::liveliness_callback() const
{
  if (IsInitialized) {
    MATLABROS2Publisher_livelinessLostWarning(PublisherHelper, NodeHandle);
  }
}

//
// Arguments    : ros2node &node
// Return Type  : ros2publisher *
//
ros2publisher *ros2publisher::init(ros2node &node)
{
  static const char resolvedTopic[9]{'/', 'p', 'o', 's', 'e',
                                     '_', 'p', '3', 'p'};
  static const char b_cv[8]{'k', 'e', 'e', 'p', 'l', 'a', 's', 't'};
  static const char cv1[8]{'r', 'e', 'l', 'i', 'a', 'b', 'l', 'e'};
  static const char cv2[8]{'v', 'o', 'l', 'a', 't', 'i', 'l', 'e'};
  ros2publisher *obj;
  geometry_msgs_PoseStampedStruct_T r;
  obj = this;
  obj->IsInitialized = false;
  for (int i{0}; i < 9; i++) {
    obj->TopicName[i] = resolvedTopic[i];
  }
  obj->Depth = 1.0;
  for (int i{0}; i < 8; i++) {
    obj->History[i] = b_cv[i];
    obj->Reliability[i] = cv1[i];
    obj->Durability[i] = cv2[i];
  }
  obj->Deadline = 0.0;
  obj->Lifespan = 0.0;
  for (int i{0}; i < 9; i++) {
    obj->Liveliness[i] = cv[i];
  }
  rmw_qos_profile_t qos_profile;
  obj->LeaseDuration = 0.0;
  obj->AvoidROSNamespaceConventions = false;
  qos_profile = ros::ros2::internal::setQOSProfile(
      rmw_qos_profile_default, obj->Depth, obj->Reliability, obj->Deadline,
      obj->Lifespan, obj->Liveliness, obj->LeaseDuration,
      obj->AvoidROSNamespaceConventions);
  geometry_msgs_PoseStampedStruct(r);
  obj->PublisherHelper =
      std::unique_ptr<MATLABROS2Publisher<geometry_msgs::msg::PoseStamped,
                                          geometry_msgs_PoseStampedStruct_T>>(
          new MATLABROS2Publisher<geometry_msgs::msg::PoseStamped,
                                  geometry_msgs_PoseStampedStruct_T>(
              [this] { this->deadline_callback(); },
              [this] { this->liveliness_callback(); },
              [this] { this->incompatible_qos_callback(); })); //();
  MATLABROS2Publisher_createPublisher(obj->PublisherHelper, node.NodeHandle,
                                      &obj->TopicName[0], 9.0, qos_profile);
  obj->NodeHandle = node.NodeHandle;
  obj->deadline_callback();
  obj->liveliness_callback();
  obj->incompatible_qos_callback();
  obj->IsInitialized = true;
  return obj;
}

//
// Arguments    : ros2node &node
// Return Type  : b_ros2publisher *
//
b_ros2publisher *b_ros2publisher::init(ros2node &node)
{
  static const char resolvedTopic[21]{'/', 'j', 'e', 't', 's', 'o', 'n',
                                      '/', 'c', 'a', 'm', 'e', 'r', 'a',
                                      '/', 's', 't', 'a', 't', 'u', 's'};
  static const char b_cv[8]{'k', 'e', 'e', 'p', 'l', 'a', 's', 't'};
  static const char cv1[8]{'r', 'e', 'l', 'i', 'a', 'b', 'l', 'e'};
  static const char cv2[8]{'v', 'o', 'l', 'a', 't', 'i', 'l', 'e'};
  b_ros2publisher *obj;
  std_msgs_StringStruct_T r;
  obj = this;
  obj->IsInitialized = false;
  for (int i{0}; i < 21; i++) {
    obj->TopicName[i] = resolvedTopic[i];
  }
  obj->Depth = 1.0;
  for (int i{0}; i < 8; i++) {
    obj->History[i] = b_cv[i];
    obj->Reliability[i] = cv1[i];
    obj->Durability[i] = cv2[i];
  }
  obj->Deadline = 0.0;
  obj->Lifespan = 0.0;
  for (int i{0}; i < 9; i++) {
    obj->Liveliness[i] = cv[i];
  }
  rmw_qos_profile_t qos_profile;
  obj->LeaseDuration = 0.0;
  obj->AvoidROSNamespaceConventions = false;
  qos_profile = ros::ros2::internal::setQOSProfile(
      rmw_qos_profile_default, obj->Depth, obj->Reliability, obj->Deadline,
      obj->Lifespan, obj->Liveliness, obj->LeaseDuration,
      obj->AvoidROSNamespaceConventions);
  std_msgs_StringStruct(r);
  obj->PublisherHelper = std::unique_ptr<
      MATLABROS2Publisher<std_msgs::msg::String, std_msgs_StringStruct_T>>(
      new MATLABROS2Publisher<std_msgs::msg::String, std_msgs_StringStruct_T>(
          [this] { this->deadline_callback(); },
          [this] { this->liveliness_callback(); },
          [this] { this->incompatible_qos_callback(); })); //();
  MATLABROS2Publisher_createPublisher(obj->PublisherHelper, node.NodeHandle,
                                      &obj->TopicName[0], 21.0, qos_profile);
  obj->NodeHandle = node.NodeHandle;
  obj->deadline_callback();
  obj->liveliness_callback();
  obj->incompatible_qos_callback();
  obj->IsInitialized = true;
  return obj;
}

} // namespace coder

//
// File trailer for ros2publisher.cpp
//
// [EOF]
//
