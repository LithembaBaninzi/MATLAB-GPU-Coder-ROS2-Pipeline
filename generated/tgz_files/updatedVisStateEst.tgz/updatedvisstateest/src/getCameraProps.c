/* Copyright 2019-2023 The MathWorks, Inc. */
#include "getCameraProps.h"
void mw_terminate() {
    MW_TERMINATE;
}

/* Wrapper to ioctl API */
static int xioctl(int fd, int request, void* arg) {
    int r;
    do {
        r = ioctl(fd, request, arg);
    } while (-1 == r && EINTR == errno);
    return r;
}

/* Get the number of cameras connected */
int getNumCams(unsigned char* device, int* maxCamIndex) {
    int count = 0, fd = 0, numCams = 0;
    char devFileBuffer[100];
    while (count < 10) {
        device[count] = 0;
        sprintf(devFileBuffer, "/dev/video%d", count);
        fd = open(devFileBuffer, O_RDWR);
        if (fd != -1) {
            device[count] = 1;
            *maxCamIndex = count;
            numCams++;
            close(fd);
        }
        count++;
    }
    return numCams;
}

/* Get the camera capabilities, For e.g driver, model, etc .. */
int getCameraCaps(int fd, MW_camProps* camPropsArray) {
    struct v4l2_capability caps = {0};
    struct v4l2_fmtdesc fmtdesc;
    memset(&fmtdesc, 0, sizeof(fmtdesc));
    fmtdesc.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    int isValidDevice = -1;

    /* Query the camera capabilities of the camera */
    if (xioctl(fd, VIDIOC_QUERYCAP, &caps) == -1) {
        perror("Querying Capabilites\n");
        return -1;
    }

    /* Copy camera info into the structure */
    memcpy(camPropsArray->driver, caps.driver, sizeof(caps.driver));

    /* Remove extended ASCII characters */
    int srcidx = 0, destidx = 0;
    unsigned char chr = 0;
    while (!(caps.card[srcidx] == '\0')) {
        chr = caps.card[srcidx];
        if (chr < 127) {
            camPropsArray->name[destidx] = chr;
            destidx++;
        }
        srcidx++;
    }
    camPropsArray->name[destidx] = '\0';

    memcpy(camPropsArray->busInfo, caps.bus_info, sizeof(caps.bus_info));
    /* Query the supported formats of the camera */
    while (xioctl(fd, VIDIOC_ENUM_FMT, &fmtdesc) >= 0) {
        camPropsArray->frameFormats[fmtdesc.index] = fmtdesc.pixelformat;
        memcpy(camPropsArray->pixelFormatDesc[fmtdesc.index], fmtdesc.description,
               sizeof(fmtdesc.description));
	isValidDevice = 1;
        fmtdesc.index++;
    }

    /* Number of frame formats available for a given camera */
    camPropsArray->numFrameFormats = fmtdesc.index;

    return isValidDevice;
}

/* Validate frame to frame interval (1/sampleTime) and assign a value in the range */
void getFrameInterval(char* devFileBuffer,
                      int frameFormat,
                      int width,
                      int height,
                      double* sampleTime) {
    int fd = 0;
    struct v4l2_frmivalenum frmival;
    double ival = 0;
    frmival.index = 0;
    frmival.pixel_format = frameFormat;
    frmival.width = width;
    frmival.height = height;
    fd = open(devFileBuffer, O_RDWR);
    int ivalIndex = 0;
    double* fps;
    char foundInterval = 0;

    /* Step wise interval variables */
    int min_num_stepwise = 1;
    int min_den_stepwise = 1;
    int max_num_stepwise = 1;
    int max_den_stepwise = 1;
    int step_num_stepwise = 1;
    int step_den_stepwise = 1;

    while (xioctl(fd, VIDIOC_ENUM_FRAMEINTERVALS, &frmival) >= 0) {
        ivalIndex++;
        frmival.index += 1;
    }
    frmival.index = 0;
    fps = (double*)malloc(ivalIndex * sizeof(double));

    while (xioctl(fd, VIDIOC_ENUM_FRAMEINTERVALS, &frmival) >= 0) {
        if (frmival.type == V4L2_FRMIVAL_TYPE_DISCRETE) {
            ival = (int)(frmival.discrete.numerator * 10000.0) /
                   (frmival.discrete.denominator * 10000.0);

            /* Case 1: Found the interval */
            if (ival == *sampleTime) {
                foundInterval = 1;
                *sampleTime = 1.0 * frmival.discrete.numerator / frmival.discrete.denominator;
                break;
            }
            /* Store the intervals */
            fps[frmival.index] = 1.0 * frmival.discrete.denominator / frmival.discrete.numerator;
        } else {
            min_num_stepwise = frmival.stepwise.min.numerator;
            min_den_stepwise = frmival.stepwise.min.denominator;
            max_num_stepwise = frmival.stepwise.max.numerator;
            max_den_stepwise = frmival.stepwise.max.denominator;
            step_num_stepwise = frmival.stepwise.step.denominator;
            step_den_stepwise = frmival.stepwise.step.denominator;

            if ((min_num_stepwise == max_num_stepwise) && (max_den_stepwise == min_den_stepwise)) {
                foundInterval = 1;
                *sampleTime =
                    1.0 * frmival.stepwise.max.numerator / frmival.stepwise.max.denominator;
            }
        }
        frmival.index += 1;
    }
    close(fd);

    /*Case 2 & 3: outliers and in between the range */
    if (!foundInterval) {
        int fpsGiven = (int)1 / (*sampleTime);
        double fpsMax = fps[0];
        double fpsMin = fps[0];
        double nearbyFps = 0;
        int diff = abs((int)fps[0] - fpsGiven);
        int tempMin = (int)fps[0];
        int tempMax = (int)fps[0];
        if (frmival.type == V4L2_FRMIVAL_TYPE_DISCRETE) {
            for (int i = 0; i < ivalIndex; i++) {
                /* Find minimum */
                if (tempMin > (int)fps[i]) {
                    tempMin = (int)fps[i];
                    fpsMin = fps[i];
                }
                /* Find maximum */
                if (tempMax < (int)fps[i]) {
                    tempMin = (int)fps[i];
                    fpsMax = fps[i];
                }
                /* Find nearest FPS */
                if (diff > abs((int)fps[i] - fpsGiven)) {
                    diff = abs((int)fps[i] - fpsGiven);
                    nearbyFps = fps[i];
                }
            }
            if (fpsGiven < fpsMin) { /* Find the lower outlier */
                *sampleTime = 1 / fpsMin;
            } else if (fpsGiven > fpsMax) { /* Find the higher outlier */
                *sampleTime = 1 / fpsMax;
            } else { /* Find in between the lowest and highest FPS */
                *sampleTime = 1 / nearbyFps;
            }
        } else {                                                    /* Step wise interval case */
            if (fpsGiven < (min_den_stepwise / min_num_stepwise)) { /* Find the lower outlier */
                *sampleTime = (1.0 * min_den_stepwise / min_num_stepwise);
            } else if (fpsGiven >
                       (int)(max_den_stepwise / max_num_stepwise)) { /* Find the lower outlier */
                *sampleTime = (1.0 * max_num_stepwise / max_den_stepwise);
            } else { /* Find in between the lowest and highest FPS */
                fpsMax = 1.0 * max_den_stepwise / max_num_stepwise;
                min_den_stepwise = 50;
                min_num_stepwise = 1;
                step_den_stepwise = 1;
                step_num_stepwise = 10;
                tempMin = (int)1.0 * min_den_stepwise / min_num_stepwise;
                diff = (int)fpsMax;
                tempMax = (int)fpsMax;
                while (diff > tempMin) {
                    fpsMin = diff - (1.0 * step_den_stepwise / step_num_stepwise);
                    diff = (int)fpsMin;
                    if (abs(fpsGiven - diff) < tempMax) {
                        tempMax = abs(fpsGiven - diff);
                        nearbyFps = fpsMin;
                    }
                }
                *sampleTime = 1 / nearbyFps;
            }
        }
    }
    free(fps);
}

void getFPS(int fd,
            int width,
            int height,
            int pixelFormat,
            MW_camRes* resolution,
            int frmsize_index) {
    struct v4l2_frmivalenum frmival;
    frmival.index = 0;
    frmival.pixel_format = pixelFormat;
    frmival.width = width;
    frmival.height = height;
    resolution->num_framerates[frmsize_index] = 0;

    while (xioctl(fd, VIDIOC_ENUM_FRAMEINTERVALS, &frmival) >= 0) {
        if (frmival.type == V4L2_FRMIVAL_TYPE_DISCRETE) {
            resolution->framerate[frmsize_index][frmival.index] =
                (frmival.discrete.denominator * 10000.0) / (frmival.discrete.numerator * 10000.0);
        } else {
            resolution->min_framerate =
                1.0 * frmival.stepwise.max.denominator / frmival.stepwise.max.numerator;
            resolution->max_framerate =
                1.0 * frmival.stepwise.min.denominator / frmival.stepwise.min.numerator;
            resolution->step_framerate =
                1.0 * frmival.stepwise.step.denominator / frmival.stepwise.step.numerator;
        }
        frmival.index += 1;
    }
    resolution->num_framerates[frmsize_index] = frmival.index;
}

/* Query camera for supported resolutions */
void getFrameSize(const struct v4l2_frmsizeenum frmsize, MW_camRes* resolution, int resId) {
    resolution->isFrameSizeTypeStep = 0;
    if (frmsize.type == V4L2_FRMSIZE_TYPE_DISCRETE) {
        resolution->width[resId] = frmsize.discrete.width;
        resolution->height[resId] = frmsize.discrete.height;
    } else if (frmsize.type == V4L2_FRMSIZE_TYPE_STEPWISE) {
        resolution->isFrameSizeTypeStep = 1;
        resolution->min_width = frmsize.stepwise.min_width;
        resolution->max_width = frmsize.stepwise.max_width;
        resolution->step_width = frmsize.stepwise.step_width;
        resolution->min_height = frmsize.stepwise.min_height;
        resolution->max_height = frmsize.stepwise.max_height;
        resolution->step_height = frmsize.stepwise.step_height;
    }
}

/* Get Supported camera resolutions and supported FPS for each resolution */
int getCamResolutions(int fd, int* frameFormats, int numFrameFormats, MW_camRes* resolution) {
    struct v4l2_frmsizeenum frmsize;
    memset(&frmsize, 0, sizeof(frmsize));
    char mychar[5];
    for (int idx = 0; idx < numFrameFormats; idx++) {
        resolution[idx].frameFormat = frameFormats[idx];
        frmsize.pixel_format = frameFormats[idx];
        memcpy(mychar, &frameFormats[idx], 4);
        frmsize.index = 0;

        while (xioctl(fd, VIDIOC_ENUM_FRAMESIZES, &frmsize) >= 0) {
            getFrameSize(frmsize, &resolution[idx], frmsize.index);
            getFPS(fd, resolution[idx].width[frmsize.index], resolution[idx].height[frmsize.index],
                   frmsize.pixel_format, &resolution[idx], frmsize.index);
            frmsize.index++;
        }
        resolution[idx].numRes = frmsize.index;
    }
    return 0;
}

int getCamCaps(MW_camProps** camPropsArray) {
    int fd = 0;
    char devFileBuffer[32];
    unsigned char device[10];
    int numCams = 0, maxCamIndex = 0, camId = 0;
    char fourcc[4];
    int invalidDevs = 0;

    /* Get the number of available cameras */
    numCams = getNumCams(device, &maxCamIndex);

    if (!numCams) {
        return numCams;
    }

    /* Allocate memory for the properties of the camera */
    *camPropsArray = (MW_camProps*)malloc(numCams * sizeof(MW_camProps));

    /* Iterate over the available cameras on the board */
    for (int index = 0; index <= maxCamIndex; index++) {
        if (camId == numCams) {
            break;
        }

        if (device[index]) {
            sprintf(devFileBuffer, "/dev/video%d", index);
            fd = open(devFileBuffer, O_RDWR);
            memcpy((*camPropsArray)[camId].videoDevice, devFileBuffer, 32);
            (*camPropsArray)[camId].id = index;

	    /* Get camera caps */
	    if (getCameraCaps(fd, &(*camPropsArray)[camId]) < 0){
		    invalidDevs++;	
	    }
	    else{


		    /* Get supported resolutions with each frame format */
		    (*camPropsArray)[camId].resolution =
			    (MW_camRes*)malloc(sizeof(MW_camRes) * ((*camPropsArray)[camId].numFrameFormats));

		    getCamResolutions(fd, (*camPropsArray)[camId].frameFormats,
				    (*camPropsArray)[camId].numFrameFormats,
				    (*camPropsArray)[camId].resolution);
		    memcpy(fourcc, (*camPropsArray)[camId].frameFormats, 4);

		    close(fd);
		    camId++;
	    }
        }
    }

    return numCams - invalidDevs;
}

bool removeDuplicateResolution(int checkWidth,
                               int checkHeight,
                               MW_camProps* camPropsArray,
                               int frameFmtIndx) {
    int width, height;
    width = 0;
    height = 0;
    for (int j = 0; j < frameFmtIndx; j++) {
        for (int k = 0; k < camPropsArray->resolution[j].numRes; k++) {
            width = camPropsArray->resolution[j].width[k];
            height = camPropsArray->resolution[j].height[k];

            if (width == checkWidth) {
                if (height == checkHeight) {
                    return false;
                }
            }
        }
    }
    return true;
}

/* Find the minimum and maximum in the size array */
void findMinMax(MW_camProps camPropsArray,
                int* min,
                int* max,
                int* minFrameType,
                int* maxFrameType) {
    max[0] = camPropsArray.resolution[0].width[0];
    max[1] = camPropsArray.resolution[0].height[0];
    *maxFrameType = camPropsArray.resolution[0].frameFormat;
    *minFrameType = *maxFrameType;
    min[0] = max[0];
    min[1] = max[1];

    for (int j = 0; j < camPropsArray.numFrameFormats; j++) {
        for (int k = 0; k < camPropsArray.resolution[j].numRes; k++) {

            if ((max[0] < camPropsArray.resolution[j].width[k]) ||
                (max[1] < camPropsArray.resolution[j].height[k])) { /* Max resolution */
                max[0] = camPropsArray.resolution[j].width[k];
                max[1] = camPropsArray.resolution[j].height[k];
                *maxFrameType = camPropsArray.resolution[j].frameFormat;
            }

            if ((min[0] > camPropsArray.resolution[j].width[k]) ||
                (min[1] > camPropsArray.resolution[j].height[k])) { /* Min resolution */

                min[0] = camPropsArray.resolution[j].width[k];
                min[1] = camPropsArray.resolution[j].height[k];
                *minFrameType = camPropsArray.resolution[j].frameFormat;
            }
        }
    }
}


/* Get the CSI cameras nearest resolution */
void getNearByImageRes(MW_camProps camPropsArray, int* width, int* height, int* frameType) {
    int locWidth, locHeight;
    int actWidth = *width;
    int actHeight = *height;
    locWidth = *width;
    locHeight = *height;
    bool break_ = false;
    bool found = false;
    int minRes[2] = {1, 1};
    int maxRes[2] = {1, 1};
    int minFrameType = 0, maxFrameType = 0;

    /* Find min & max in the array */
    findMinMax(camPropsArray, minRes, maxRes, &minFrameType, &maxFrameType);

    if ((minRes[1] > actHeight || minRes[1] == actHeight) &&
        (minRes[0] > actWidth || minRes[0] == actWidth)) {
        *width = minRes[0];
        *height = minRes[1];
        *frameType = minFrameType;
    } else if ((maxRes[1] < actHeight || maxRes[1] == actHeight) &&
               (maxRes[0] < actWidth || maxRes[0] == actWidth)) {
        *width = maxRes[0];
        *height = maxRes[1];
        *frameType = maxFrameType;
    } else if (maxRes[0] < actWidth) {
        *width = maxRes[0];
        *height = maxRes[1];
        *frameType = maxFrameType;
    } else if (maxRes[1] < actHeight) {
        *width = maxRes[0];
        *height = maxRes[1];
        *frameType = maxFrameType;
    } else {
        for (int j = 0; j < camPropsArray.numFrameFormats; j++) {
            for (int k = 0; k < camPropsArray.resolution[j].numRes; k++) {
                locWidth = camPropsArray.resolution[j].width[k];
                locHeight = camPropsArray.resolution[j].height[k];
                if ((actWidth == locWidth) && (actHeight == locHeight)) {
                    *width = locWidth;
                    *height = locHeight;
                    *frameType = camPropsArray.resolution[j].frameFormat;
                    break_ = true;
                    break;
                } else if ((actHeight < locHeight) && (actWidth < locWidth) && (!found)) {

                    if (break_) {
                        if ((*width > locWidth) || (*height > locHeight)) {
                            *width = locWidth;
                            *height = locHeight;
                            *frameType = camPropsArray.resolution[j].frameFormat;
                        }
                    } else {
                        *width = locWidth;
                        *height = locHeight;
                        *frameType = camPropsArray.resolution[j].frameFormat;
                        break_ = true;
                    }
                } else if (actWidth == locWidth) {
                    found = true;
                    if (break_) {
                        if (*height > locHeight) {
                            *width = locWidth;
                            *height = locHeight;
                            *frameType = camPropsArray.resolution[j].frameFormat;
                        }
                    } else {
                        *width = locWidth;
                        *height = locHeight;
                        *frameType = camPropsArray.resolution[j].frameFormat;
                        break_ = true;
                    }

                } else if (actHeight == locHeight) {
                    if (break_) {
                        if (*width > locWidth) {
                            *width = locWidth;
                            *height = locHeight;
                            *frameType = camPropsArray.resolution[j].frameFormat;
                        }
                    } else {
                        *width = locWidth;
                        *height = locHeight;
                        *frameType = camPropsArray.resolution[j].frameFormat;
                        break_ = true;
                    }
                }
            }
            if (break_) {
                break;
            }
        }
    }
}

/*Returns the CSI sensor ID.*/
unsigned char getSensorID(unsigned char VideoDeviceID)
{
    char videodev[32];
    unsigned char sensorid = -1;
    sprintf(videodev, "/dev/video%d", VideoDeviceID);
    int numCams;
    MW_camProps* camPropsArray = NULL;
    numCams = getCamCaps(&camPropsArray);
    for (int i = 0; i < numCams; i++) {
        if (strcmp(camPropsArray[i].driver, "tegra-video") == 0){
            sensorid++;
            if (strcmp(camPropsArray[i].videoDevice, videodev) == 0) {
                break;
            }
        }
    }
    return sensorid;
}

int validateWebcamResolution(unsigned char *camIndex,
                             char* videoDevice,
                             int width,
                             int height)
{
    int numCams = 0;
    MW_camProps* camPropsArray = NULL;
    numCams = getCamCaps(&camPropsArray);
    if (numCams == 0) {
        return -1;
    }

    if ((videoDevice == NULL) && (*camIndex >= numCams)) {
        return -2;
    }

    /* Find the webcam index in the list of cameras. In the case of 
       video device node is provided */
    int globalCamIndex = -1;
    unsigned char webcamIndex = 0;
    if (videoDevice != NULL) {
        for (int i = 0; i < numCams; i++) {
            if ((strcmp(camPropsArray[i].driver, "tegra-video") != 0) && 
                strcmp(videoDevice, camPropsArray[i].videoDevice) == 0) {
                globalCamIndex = i;
            }
        }
        if (globalCamIndex == -1){
        	return -3;
        }
    }
    else { /*Find webcam index. Jetson can contain CSI cameras too.*/
        for (int i = 0; i < numCams; i++) {
            if (strcmp(camPropsArray[i].driver, "tegra-video") != 0){
                if (webcamIndex == *camIndex){
                    globalCamIndex = i;
                    break;
                }
                webcamIndex ++;
            }
        }
    }
    *camIndex = globalCamIndex;
    /* Webcam support is provided only for 'YUYV' pixel format */
    char fourcc[] = {'Y', 'U', 'Y', 'V'};
    unsigned char nFormat = 0;
    for (int j = 0; j < camPropsArray[globalCamIndex].numFrameFormats; j++)
    {
        if (strcmp(fourcc,camPropsArray[globalCamIndex].pixelFormatDesc[j])){
            nFormat = j;
            break;
        }
    }

    /* Validate resolution */
    unsigned char resFlag = -3;
    int w =0, h=0;
    for (int k = 0; k < camPropsArray[globalCamIndex].resolution[nFormat].numRes; k++) {
        w = camPropsArray[globalCamIndex].resolution[nFormat].width[k];
        h = camPropsArray[globalCamIndex].resolution[nFormat].height[k];
        if ((width == w) && (height == h)){
            resFlag = 0;
            break;
        }
    }
    return resFlag;
}

int validateArgsAndGetDetails(
    char* cameraName,            /* Input: Name of the camera                           */
    int setWidth,                /* Input: Width of the frame to set                    */
    int setHeight,               /* Input: Height of the frame to set                   */
    int* camIndex,               /* Output: Video device index, 0, 1, 2, etc            */
    int* cameraInterface,        /* Output: Camera interface, USB, CSI, etc             */
    unsigned int searchMode,     /* Input: Validate if the user specifies video device  */
    char* videoDevice,           /* Input&Output: Video device value, /dev/video0, etc  */
    double sampleTime,           /* Input: Validate sample time                         */
    double* retSampleTime,       /* Output: Return a valid sample time                  */
    char* pixelFormat,           /* Input: Pixel format                                 */
    unsigned int* retPixelFormat /* Output: Return frame format                         */
) {
    int numCams = 0;
    int width = 0, height = 0;
    MW_camProps* camPropsArray = NULL;
    numCams = getCamCaps(&camPropsArray);
    if (!numCams) {
        printf("No camera connected to the target.\n");
        return -1;
    }

    unsigned char resolutionAvailable = 0;
    int ret = 0;
    int cameraPropIdx = -1;
    int frameType = 0;
    *cameraInterface = 1;
    *camIndex = 0;

    if (searchMode) {
        for (int i = 0; i < numCams; i++) {
            if (strcmp(camPropsArray[i].videoDevice, videoDevice) == 0) {
                cameraPropIdx = i;
                *camIndex = camPropsArray[i].id;
#ifndef _SIMULINK_TGT_
                if (strcmp(cameraName, camPropsArray[i].name)) {
                    ret = -1;
                    printf("No video device '%s' with name '%s'.\n", cameraName, videoDevice);
                    return -1;
                }
#endif
            }
        }
        if (cameraPropIdx < 0) {
            ret = -1;
            printf("Video device '%s' did not match any of the available devices.\n", videoDevice);
        }
    } else {
        for (int i = 0; i < numCams; i++) {
            if (!strcmp(cameraName, camPropsArray[i].name)) {
                *camIndex = camPropsArray[i].id;
                cameraPropIdx = i;
                strcpy(videoDevice, camPropsArray[i].videoDevice);
            }
        }
    }

    if ((cameraPropIdx < 0) && (!searchMode)) {
        printf("Camera not available.\n");
        ret = -1;
    }

    /* CSI cameras are a special case. They allow all the even resolutions.
    So, we are handling them before the other cameras. The variable
    resolutionAvailable acts as a switch to other cameras loop.
    */
    if (!strcmp(camPropsArray[cameraPropIdx].driver, "tegra-video")) {
        *cameraInterface = 0;
        if (sampleTime) {
            int tempWidth = setWidth;
            int tempHeight = setHeight;
            getNearByImageRes(camPropsArray[cameraPropIdx], &tempWidth, &tempHeight, &frameType);
            getFrameInterval(videoDevice, frameType, tempWidth, tempHeight, retSampleTime);
        }
        resolutionAvailable = 1;
    }

    if ((setWidth == 0) || (setHeight == 0)) {
        printf("Resolution size must be nonzero values.\n");
        resolutionAvailable = 0;
        ret = -1;
    }

    printf("Camera = %d in %d\n", *cameraInterface, __LINE__);
#ifndef _SIMULINK_TGT_
    unsigned char isPixelFormatAvailable = 0;
    char pfrmt[6] = {0};
    /* Validate the details if pixel format is provided. */
    if (*pixelFormat != 0) {
        for (int j = 0; j < camPropsArray[cameraPropIdx].numFrameFormats; j++) {
            for (int k = 0; k < camPropsArray[cameraPropIdx].resolution[j].numRes; k++) {
                width = camPropsArray[cameraPropIdx].resolution[j].width[k];
                height = camPropsArray[cameraPropIdx].resolution[j].height[k];
                frameType = camPropsArray[cameraPropIdx].resolution[j].frameFormat;
                memcpy(pfrmt, &frameType, 4);

                /* Pixel format available */
                if (!strcmp(pixelFormat, pfrmt)) {
                    *retPixelFormat = frameType;
                    isPixelFormatAvailable = 1;

                    /* Do not check for resolution if CSI camera is selected. */
                    if (strcmp(camPropsArray[cameraPropIdx].driver, "tegra-video") &&
                        (width == setWidth) && (height == setHeight)) {
                        resolutionAvailable = 1;
                        break;
                    }
                }
            }
        }
        if (isPixelFormatAvailable == 0) {
            printf(" %s does not support the pixel format specified %s.\n",
                   camPropsArray[cameraPropIdx].name, pixelFormat);
            ret = -1;
        }
    }

#endif

    /* Validate the resolution and get the pixel format. This loop handles
    validating for the USB cameras.
    */
    double nearestSampleTime = 0.0;
    double diffWithSampleTime = 99999.0;
    if ((cameraPropIdx > 0) && (!resolutionAvailable) && (*pixelFormat == 0)) {
        for (int j = 0; j < camPropsArray[cameraPropIdx].numFrameFormats; j++) {
            for (int k = 0; k < camPropsArray[cameraPropIdx].resolution[j].numRes; k++) {
                width = camPropsArray[cameraPropIdx].resolution[j].width[k];
                height = camPropsArray[cameraPropIdx].resolution[j].height[k];
                frameType = camPropsArray[cameraPropIdx].resolution[j].frameFormat;
                if (width == setWidth && height == setHeight) {
                    *retPixelFormat = frameType;

                    /* Check the supported FPS */
                    if (sampleTime) {
                        getFrameInterval(videoDevice, frameType, setWidth, setHeight,
                                         retSampleTime);
                        if (diffWithSampleTime > fabs(sampleTime - *retSampleTime)) {
                            diffWithSampleTime = fabs(sampleTime - *retSampleTime);
                            nearestSampleTime = *retSampleTime;
                        }
                        *retSampleTime = nearestSampleTime;
                    } else {
                        *retSampleTime = 0.0;
                    }
                    resolutionAvailable = 1;
                }
            }
        }

        if (!resolutionAvailable) {
            printf(" %s does not support the resolution specified [%d %d].\n", cameraName, setWidth,
                   setHeight);
            ret = -1;
        }
    }

    /* Free allocated memory for storing resolutions */
    for (int i = 0; i < numCams; i++) {
        if (camPropsArray[i].resolution) {
            free(camPropsArray[i].resolution);
            camPropsArray[i].resolution = NULL;
        }
    }

    /* Free allocated memory for storing camera properties*/
    if (camPropsArray) {
        free(camPropsArray);
        camPropsArray = NULL;
    }
    return ret;
}


int getCameraProps(char* camList) {
    int numCams = 0;
    int width = 0, height = 0;
    memset(camList, 0, strlen(camList)); /* Set the buffer values to null */
    MW_camProps* camPropsArray = NULL;
    numCams = getCamCaps(&camPropsArray);
    if (!numCams) {
        printf("No camera connected to the target.\n");
        return numCams;
    }
    sprintf(camList, "%d\n", numCams);
    char pixFormat[5] = "";
    for (int i = 0; i < numCams; i++) {
        sprintf(camList + strlen(camList), "MW Camera Properties\n");
        sprintf(camList + strlen(camList), "%s\n", camPropsArray[i].name);
        sprintf(camList + strlen(camList), "%s\n", camPropsArray[i].driver);
        sprintf(camList + strlen(camList), "%s\n", camPropsArray[i].videoDevice);

        for (int j = 0; j < camPropsArray[i].numFrameFormats; j++) {
            memcpy(pixFormat, (char*)&camPropsArray[i].resolution[j].frameFormat, 4);
            sprintf(camList + strlen(camList), "Pixel format:%s\n", pixFormat);
            for (int k = 0; k < camPropsArray[i].resolution[j].numRes; k++) {
                width = camPropsArray[i].resolution[j].width[k];
                height = camPropsArray[i].resolution[j].height[k];

                sprintf(camList + strlen(camList), "[%d %d]@ ", width, height);

                for (int l = 0; l < camPropsArray[i].resolution[j].num_framerates[k]; l++) {
                    sprintf(camList + strlen(camList), "%.2f",
                            camPropsArray[i].resolution[j].framerate[k][l]);
                    if (l != camPropsArray[i].resolution[j].num_framerates[k] - 1) {
                        sprintf(camList + strlen(camList), ",");
                    }
                }
                if (k != camPropsArray[i].resolution[j].numRes) {
                    sprintf(camList + strlen(camList), "\n");
                }
            }

            if (i != camPropsArray[i].numFrameFormats - 1) {
                sprintf(camList + strlen(camList), "\n");
            }
        }

        if (i != numCams - 1) {
            sprintf(camList + strlen(camList), "\n");
        }
    }

    /* Free allocated memory for storing resolutions */
    for (int i = 0; i < numCams; i++) {
        if (camPropsArray[i].resolution) {
            free(camPropsArray[i].resolution);
            camPropsArray[i].resolution = NULL;
        }
    }

    /* Free allocated memory for storing camera properties*/
    if (camPropsArray) {
        free(camPropsArray);
        camPropsArray = NULL;
    }
    return numCams;
}

/* LocalWords:  dev Capabilites
 */
