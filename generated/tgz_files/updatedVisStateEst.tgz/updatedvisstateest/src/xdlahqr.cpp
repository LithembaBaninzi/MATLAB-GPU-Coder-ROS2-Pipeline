//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xdlahqr.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

// Include Files
#include "xdlahqr.h"
#include "rt_nonfinite.h"
#include "xdlanv2.h"
#include "xzlarfg.h"
#include <cmath>

// Custom Source Code
#include "nanoP3p.h"
// Function Definitions
//
// Arguments    : int ilo
//                int ihi
//                double h[16]
//                int iloz
//                int ihiz
//                double z[16]
//                double wr[4]
//                double wi[4]
// Return Type  : int
//
namespace coder {
namespace internal {
namespace reflapack {
int xdlahqr(int ilo, int ihi, double h[16], int iloz, int ihiz, double z[16],
            double wr[4], double wi[4])
{
  double d;
  double d1;
  double h12;
  double h22;
  double rt1r;
  double rt2r;
  double s;
  int b_i;
  int i;
  int info;
  info = 0;
  for (i = 0; i <= ilo - 2; i++) {
    wr[i] = h[i + (i << 2)];
    wi[i] = 0.0;
  }
  b_i = ihi + 1;
  for (i = b_i; i < 5; i++) {
    wr[i - 1] = h[(i + ((i - 1) << 2)) - 1];
    wi[i - 1] = 0.0;
  }
  if (ilo == ihi) {
    wr[ilo - 1] = h[(ilo + ((ilo - 1) << 2)) - 1];
    wi[ilo - 1] = 0.0;
  } else {
    double smlnum;
    int itmax;
    int kdefl;
    int nh;
    int nr;
    int nz;
    bool exitg1;
    b_i = ihi - 3;
    for (nr = ilo; nr <= b_i; nr++) {
      nh = nr + ((nr - 1) << 2);
      h[nh + 1] = 0.0;
      h[nh + 2] = 0.0;
    }
    if (ilo <= ihi - 2) {
      h[(ihi + ((ihi - 3) << 2)) - 1] = 0.0;
    }
    nh = (ihi - ilo) + 1;
    nz = ihiz - iloz;
    smlnum = 2.2250738585072014E-308 *
             (static_cast<double>(nh) / 2.2204460492503131E-16);
    if (nh < 10) {
      nh = 10;
    }
    itmax = 30 * nh;
    kdefl = 0;
    i = ihi - 1;
    exitg1 = false;
    while ((!exitg1) && (i + 1 >= ilo)) {
      double aa;
      double tst;
      int b_k;
      int i1;
      int its;
      int k;
      int l;
      int temp_tmp_tmp;
      bool converged;
      bool exitg2;
      l = ilo;
      converged = false;
      its = 0;
      exitg2 = false;
      while ((!exitg2) && (its <= itmax)) {
        double tr;
        bool exitg3;
        k = i;
        exitg3 = false;
        while ((!exitg3) && (k + 1 > l)) {
          b_i = k + ((k - 1) << 2);
          d = std::abs(h[b_i]);
          if (d <= smlnum) {
            exitg3 = true;
          } else {
            nh = k + (k << 2);
            h12 = std::abs(h[nh]);
            aa = h[b_i - 1];
            tst = std::abs(aa) + h12;
            if (tst == 0.0) {
              if (k - 1 >= ilo) {
                tst = std::abs(h[(k + ((k - 2) << 2)) - 1]);
              }
              if (k + 2 <= ihi) {
                tst += std::abs(h[nh + 1]);
              }
            }
            if (d <= 2.2204460492503131E-16 * tst) {
              tr = std::abs(h[nh - 1]);
              tst = std::abs(aa - h[nh]);
              aa = std::fmax(h12, tst);
              tst = std::fmin(h12, tst);
              s = aa + tst;
              if (std::fmin(d, tr) * (std::fmax(d, tr) / s) <=
                  std::fmax(smlnum,
                            2.2204460492503131E-16 * (tst * (aa / s)))) {
                exitg3 = true;
              } else {
                k--;
              }
            } else {
              k--;
            }
          }
        }
        l = k + 1;
        if (k + 1 > ilo) {
          h[k + ((k - 1) << 2)] = 0.0;
        }
        if (k + 1 >= i) {
          converged = true;
          exitg2 = true;
        } else {
          double v[3];
          int m;
          kdefl++;
          if (kdefl - kdefl / 20 * 20 == 0) {
            s = std::abs(h[i + ((i - 1) << 2)]) +
                std::abs(h[(i + ((i - 2) << 2)) - 1]);
            tst = 0.75 * s + h[i + (i << 2)];
            h12 = -0.4375 * s;
            aa = s;
            h22 = tst;
          } else if (kdefl - kdefl / 10 * 10 == 0) {
            nh = k + (k << 2);
            s = std::abs(h[nh + 1]) + std::abs(h[(k + ((k + 1) << 2)) + 2]);
            tst = 0.75 * s + h[nh];
            h12 = -0.4375 * s;
            aa = s;
            h22 = tst;
          } else {
            nh = i + ((i - 1) << 2);
            tst = h[nh - 1];
            aa = h[nh];
            nh = i + (i << 2);
            h12 = h[nh - 1];
            h22 = h[nh];
          }
          s = ((std::abs(tst) + std::abs(h12)) + std::abs(aa)) + std::abs(h22);
          if (s == 0.0) {
            rt1r = 0.0;
            tst = 0.0;
            rt2r = 0.0;
            h12 = 0.0;
          } else {
            tst /= s;
            aa /= s;
            h12 /= s;
            h22 /= s;
            tr = (tst + h22) / 2.0;
            tst = (tst - tr) * (h22 - tr) - h12 * aa;
            h12 = std::sqrt(std::abs(tst));
            if (tst >= 0.0) {
              rt1r = tr * s;
              rt2r = rt1r;
              tst = h12 * s;
              h12 = -tst;
            } else {
              rt1r = tr + h12;
              rt2r = tr - h12;
              if (std::abs(rt1r - h22) <= std::abs(rt2r - h22)) {
                rt1r *= s;
                rt2r = rt1r;
              } else {
                rt2r *= s;
                rt1r = rt2r;
              }
              tst = 0.0;
              h12 = 0.0;
            }
          }
          m = i - 1;
          exitg3 = false;
          while ((!exitg3) && (m >= k + 1)) {
            nh = m + ((m - 1) << 2);
            aa = h[nh - 1];
            tr = aa - rt2r;
            s = (std::abs(tr) + std::abs(h12)) + std::abs(h[nh]);
            h22 = h[nh] / s;
            nr = m + (m << 2);
            v[0] = (h22 * h[nr - 1] + tr * (tr / s)) - tst * (h12 / s);
            v[1] = h22 * (((aa + h[nr]) - rt1r) - rt2r);
            v[2] = h22 * h[nr + 1];
            s = (std::abs(v[0]) + std::abs(v[1])) + std::abs(v[2]);
            v[0] /= s;
            v[1] /= s;
            v[2] /= s;
            if (m == k + 1) {
              exitg3 = true;
            } else {
              b_i = m + ((m - 2) << 2);
              if (std::abs(h[b_i - 1]) * (std::abs(v[1]) + std::abs(v[2])) <=
                  2.2204460492503131E-16 * std::abs(v[0]) *
                      ((std::abs(h[b_i - 2]) + std::abs(h[nh - 1])) +
                       std::abs(h[nr]))) {
                exitg3 = true;
              } else {
                m--;
              }
            }
          }
          for (int c_k{m}; c_k <= i; c_k++) {
            nh = (i - c_k) + 2;
            if (nh >= 3) {
              nr = 3;
            } else {
              nr = nh;
            }
            if (c_k > m) {
              nh = (((c_k - 2) << 2) + c_k) - 1;
              for (b_k = 0; b_k < nr; b_k++) {
                v[b_k] = h[nh + b_k];
              }
            }
            tst = v[0];
            tr = xzlarfg(nr, tst, v);
            if (c_k > m) {
              b_i = c_k + ((c_k - 2) << 2);
              h[b_i - 1] = tst;
              h[b_i] = 0.0;
              if (c_k < i) {
                h[b_i + 1] = 0.0;
              }
            } else if (m > k + 1) {
              b_i = (c_k + ((c_k - 2) << 2)) - 1;
              h[b_i] *= 1.0 - tr;
            }
            d = v[1];
            tst = tr * v[1];
            if (nr == 3) {
              rt2r = v[2];
              aa = tr * v[2];
              for (nr = c_k; nr < 5; nr++) {
                b_i = c_k + ((nr - 1) << 2);
                rt1r = h[b_i - 1];
                s = h[b_i];
                d1 = h[b_i + 1];
                h12 = (rt1r + d * s) + rt2r * d1;
                rt1r -= h12 * tr;
                h[b_i - 1] = rt1r;
                s -= h12 * tst;
                h[b_i] = s;
                d1 -= h12 * aa;
                h[b_i + 1] = d1;
              }
              if (c_k + 3 <= i + 1) {
                b_i = c_k + 2;
              } else {
                b_i = i;
              }
              for (nr = 0; nr <= b_i; nr++) {
                nh = nr + ((c_k - 1) << 2);
                rt1r = h[nh];
                i1 = nr + (c_k << 2);
                s = h[i1];
                temp_tmp_tmp = nr + ((c_k + 1) << 2);
                d1 = h[temp_tmp_tmp];
                h12 = (rt1r + d * s) + rt2r * d1;
                rt1r -= h12 * tr;
                h[nh] = rt1r;
                s -= h12 * tst;
                h[i1] = s;
                d1 -= h12 * aa;
                h[temp_tmp_tmp] = d1;
              }
              for (nr = iloz; nr <= ihiz; nr++) {
                b_i = (nr + ((c_k - 1) << 2)) - 1;
                rt1r = z[b_i];
                nh = (nr + (c_k << 2)) - 1;
                s = z[nh];
                i1 = (nr + ((c_k + 1) << 2)) - 1;
                d1 = z[i1];
                h12 = (rt1r + d * s) + rt2r * d1;
                rt1r -= h12 * tr;
                z[b_i] = rt1r;
                s -= h12 * tst;
                z[nh] = s;
                d1 -= h12 * aa;
                z[i1] = d1;
              }
            } else if (nr == 2) {
              for (nr = c_k; nr < 5; nr++) {
                b_i = c_k + ((nr - 1) << 2);
                rt2r = h[b_i - 1];
                rt1r = h[b_i];
                h12 = rt2r + d * rt1r;
                rt2r -= h12 * tr;
                h[b_i - 1] = rt2r;
                rt1r -= h12 * tst;
                h[b_i] = rt1r;
              }
              for (nr = 0; nr <= i; nr++) {
                b_i = nr + ((c_k - 1) << 2);
                rt2r = h[b_i];
                nh = nr + (c_k << 2);
                rt1r = h[nh];
                h12 = rt2r + d * rt1r;
                rt2r -= h12 * tr;
                h[b_i] = rt2r;
                rt1r -= h12 * tst;
                h[nh] = rt1r;
              }
              for (nr = iloz; nr <= ihiz; nr++) {
                b_i = (nr + ((c_k - 1) << 2)) - 1;
                rt2r = z[b_i];
                nh = (nr + (c_k << 2)) - 1;
                rt1r = z[nh];
                h12 = rt2r + d * rt1r;
                rt2r -= h12 * tr;
                z[b_i] = rt2r;
                rt1r -= h12 * tst;
                z[nh] = rt1r;
              }
            }
          }
          its++;
        }
      }
      if (!converged) {
        info = i + 1;
        exitg1 = true;
      } else {
        if (l == i + 1) {
          wr[i] = h[i + (i << 2)];
          wi[i] = 0.0;
        } else if (l == i) {
          b_i = i << 2;
          nh = i + b_i;
          d = h[nh - 1];
          i1 = (i - 1) << 2;
          temp_tmp_tmp = i + i1;
          rt2r = h[temp_tmp_tmp];
          rt1r = h[nh];
          wr[i - 1] = xdlanv2(h[temp_tmp_tmp - 1], d, rt2r, rt1r, wi[i - 1], s,
                              d1, h12, h22);
          wr[i] = s;
          wi[i] = d1;
          h[nh - 1] = d;
          h[temp_tmp_tmp] = rt2r;
          h[nh] = rt1r;
          if (i + 1 < 4) {
            nh = 2 - i;
            if (3 - i >= 1) {
              nr = ((i + 1) << 2) + i;
              for (k = 0; k <= nh; k++) {
                b_k = nr + (k << 2);
                tst = h[b_k];
                aa = h[b_k - 1];
                h[b_k] = h12 * tst - h22 * aa;
                h[b_k - 1] = h12 * aa + h22 * tst;
              }
            }
          }
          if (i - 1 >= 1) {
            for (k = 0; k <= i - 2; k++) {
              b_k = b_i + k;
              tst = h[b_k];
              temp_tmp_tmp = i1 + k;
              aa = h[temp_tmp_tmp];
              h[b_k] = h12 * tst - h22 * aa;
              h[temp_tmp_tmp] = h12 * aa + h22 * tst;
            }
          }
          if (nz + 1 >= 1) {
            nr = (i1 + iloz) - 1;
            nh = (b_i + iloz) - 1;
            for (k = 0; k <= nz; k++) {
              b_k = nh + k;
              tst = z[b_k];
              temp_tmp_tmp = nr + k;
              aa = z[temp_tmp_tmp];
              z[b_k] = h12 * tst - h22 * aa;
              z[temp_tmp_tmp] = h12 * aa + h22 * tst;
            }
          }
        }
        kdefl = 0;
        i = l - 2;
      }
    }
    for (nr = 0; nr < 2; nr++) {
      for (i = nr + 3; i < 5; i++) {
        h[(i + (nr << 2)) - 1] = 0.0;
      }
    }
  }
  return info;
}

} // namespace reflapack
} // namespace internal
} // namespace coder

//
// File trailer for xdlahqr.cpp
//
// [EOF]
//
