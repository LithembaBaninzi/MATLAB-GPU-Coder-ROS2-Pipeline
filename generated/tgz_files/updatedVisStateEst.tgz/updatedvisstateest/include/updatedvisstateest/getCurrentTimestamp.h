//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: getCurrentTimestamp.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef GETCURRENTTIMESTAMP_H
#define GETCURRENTTIMESTAMP_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
double getCurrentTimestamp(int &sec, unsigned int &nsec);

#endif
//
// File trailer for getCurrentTimestamp.h
//
// [EOF]
//
