//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: imageDisplay.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef IMAGEDISPLAY_H
#define IMAGEDISPLAY_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Definitions
namespace coder {
namespace nvidiacoder {
namespace common {
class imageDisplay {
public:
  static imageDisplay *b_imageDisplay(imageDisplay &iobj_0);
  void image(const unsigned char img[691200]);
  void matlabCodegenDestructor();
  ~imageDisplay();
  imageDisplay();

protected:
  void setupImpl();
  static void stepImpl(unsigned char pln1[230400], unsigned char pln2[230400],
                       unsigned char pln3[230400]);
  static void releaseImpl();

public:
  bool matlabCodegenIsDeleted;
  int isInitialized;

private:
  bool isSetupComplete;
  int PixelFormatEnum;
};

} // namespace common
} // namespace nvidiacoder
} // namespace coder

#endif
//
// File trailer for imageDisplay.h
//
// [EOF]
//
