//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: geometry_msgs_PointStruct.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef GEOMETRY_MSGS_POINTSTRUCT_H
#define GEOMETRY_MSGS_POINTSTRUCT_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct geometry_msgs_PointStruct_T;

// Function Declarations
geometry_msgs_PointStruct_T geometry_msgs_PointStruct();

#endif
//
// File trailer for geometry_msgs_PointStruct.h
//
// [EOF]
//
