//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: strcmp.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef STRCMP_H
#define STRCMP_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
bool b_strcmp(const array<char, 2U> &b);

bool c_strcmp(const array<char, 2U> &b);

bool d_strcmp(const array<char, 2U> &b);

} // namespace internal
} // namespace coder

#endif
//
// File trailer for strcmp.h
//
// [EOF]
//
