//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: ros2publisher.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef ROS2PUBLISHER_H
#define ROS2PUBLISHER_H

// Include Files
#include "rtwtypes.h"
#include "mlros2_node.h"
#include "mlros2_pub.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace coder {
class ros2node;

}

// Type Definitions
namespace coder {
class ros2publisher {
public:
  ros2publisher *init(ros2node &node);
  void deadline_callback() const;
  void liveliness_callback() const;
  void incompatible_qos_callback() const;
  char TopicName[9];
  char History[8];
  double Depth;
  char Reliability[8];
  char Durability[8];
  double Deadline;
  double Lifespan;
  char Liveliness[9];
  double LeaseDuration;
  bool AvoidROSNamespaceConventions;
  std::unique_ptr<MATLABROS2Publisher<geometry_msgs::msg::PoseStamped,
                                      geometry_msgs_PoseStampedStruct_T>>
      PublisherHelper;

private:
  rclcpp::Node::SharedPtr NodeHandle;
  bool IsInitialized;
};

class b_ros2publisher {
public:
  b_ros2publisher *init(ros2node &node);
  void deadline_callback() const;
  void liveliness_callback() const;
  void incompatible_qos_callback() const;
  char TopicName[21];
  char History[8];
  double Depth;
  char Reliability[8];
  char Durability[8];
  double Deadline;
  double Lifespan;
  char Liveliness[9];
  double LeaseDuration;
  bool AvoidROSNamespaceConventions;
  std::unique_ptr<
      MATLABROS2Publisher<std_msgs::msg::String, std_msgs_StringStruct_T>>
      PublisherHelper;

private:
  rclcpp::Node::SharedPtr NodeHandle;
  bool IsInitialized;
};

} // namespace coder

#endif
//
// File trailer for ros2publisher.h
//
// [EOF]
//
