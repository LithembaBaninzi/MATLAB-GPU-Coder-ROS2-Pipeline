//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: ros2subscriber.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef ROS2SUBSCRIBER_H
#define ROS2SUBSCRIBER_H

// Include Files
#include "rtwtypes.h"
#include "updatedVisStateEst_types.h"
#include "coder_array.h"
#include "mlros2_node.h"
#include "mlros2_sub.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace coder {
class ros2node;

}

// Type Definitions
namespace coder {
class ros2subscriber {
public:
  ros2subscriber *init(ros2node &node);
  void callback();
  void deadline_callback() const;
  void liveliness_callback() const;
  void message_lost_callback() const;
  void incompatible_qos_callback() const;
  bool receive(array<char, 2U> &receivedMsg_data) const;
  char TopicName[22];
  char History[8];
  double Depth;
  char Reliability[8];
  char Durability[8];
  double Deadline;
  double Lifespan;
  char Liveliness[9];
  double LeaseDuration;
  bool AvoidROSNamespaceConventions;
  double MessageCount;

private:
  std::unique_ptr<
      MATLABROS2Subscriber<std_msgs::msg::String, std_msgs_StringStruct_T>>
      SubscriberHelper;
  rclcpp::Node::SharedPtr NodeHandle;
  std_msgs_StringStruct_T MsgStruct;
  bool IsInitialized;
};

} // namespace coder

#endif
//
// File trailer for ros2subscriber.h
//
// [EOF]
//
