//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xzgehrd.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef XZGEHRD_H
#define XZGEHRD_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace reflapack {
void xzgehrd(double a[16], int ilo, int ihi, double tau[3]);

}
} // namespace internal
} // namespace coder

#endif
//
// File trailer for xzgehrd.h
//
// [EOF]
//
