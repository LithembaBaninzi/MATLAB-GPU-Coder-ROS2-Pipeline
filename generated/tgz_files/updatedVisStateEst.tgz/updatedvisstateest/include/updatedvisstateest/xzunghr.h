//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xzunghr.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef XZUNGHR_H
#define XZUNGHR_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace reflapack {
void xzunghr(int ilo, int ihi, double A[16], const double tau[3]);

}
} // namespace internal
} // namespace coder

#endif
//
// File trailer for xzunghr.h
//
// [EOF]
//
