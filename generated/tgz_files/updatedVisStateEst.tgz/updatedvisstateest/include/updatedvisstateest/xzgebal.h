//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xzgebal.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef XZGEBAL_H
#define XZGEBAL_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace reflapack {
int xzgebal(double A[16], int &ihi, double scale[4]);

}
} // namespace internal
} // namespace coder

#endif
//
// File trailer for xzgebal.h
//
// [EOF]
//
