//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: updatedVisStateEst.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef UPDATEDVISSTATEEST_H
#define UPDATEDVISSTATEEST_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void updatedVisStateEst();

#endif
//
// File trailer for updatedVisStateEst.h
//
// [EOF]
//
