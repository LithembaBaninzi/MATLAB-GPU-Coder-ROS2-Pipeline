//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: geometry_msgs_PoseStampedStruct.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef GEOMETRY_MSGS_POSESTAMPEDSTRUCT_H
#define GEOMETRY_MSGS_POSESTAMPEDSTRUCT_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct geometry_msgs_PoseStampedStruct_T;

// Function Declarations
void geometry_msgs_PoseStampedStruct(geometry_msgs_PoseStampedStruct_T &msg);

#endif
//
// File trailer for geometry_msgs_PoseStampedStruct.h
//
// [EOF]
//
