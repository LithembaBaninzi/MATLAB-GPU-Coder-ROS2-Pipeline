//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: tFormPQRight.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef TFORMPQRIGHT_H
#define TFORMPQRIGHT_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void tFormPQRight(const double pq_a2b[28], double pq_c2b[28]);

#endif
//
// File trailer for tFormPQRight.h
//
// [EOF]
//
