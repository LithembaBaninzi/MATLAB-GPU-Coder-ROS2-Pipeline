//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xzsteqr.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef XZSTEQR_H
#define XZSTEQR_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace reflapack {
int xzsteqr(double d[4], double e[3], double z[16]);

}
} // namespace internal
} // namespace coder

#endif
//
// File trailer for xzsteqr.h
//
// [EOF]
//
