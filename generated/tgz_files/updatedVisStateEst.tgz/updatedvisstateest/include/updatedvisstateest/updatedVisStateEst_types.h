//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: updatedVisStateEst_types.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef UPDATEDVISSTATEEST_TYPES_H
#define UPDATEDVISSTATEEST_TYPES_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"

// Type Definitions
struct struct_T {
  double sec;
  double nsec;
};

struct builtin_interfaces_TimeStruct_T {
  char MessageType[23];
  int sec;
  unsigned int nanosec;
};

struct geometry_msgs_PointStruct_T {
  char MessageType[19];
  double x;
  double y;
  double z;
};

struct geometry_msgs_QuaternionStruct_T {
  char MessageType[24];
  double x;
  double y;
  double z;
  double w;
};

struct geometry_msgs_PoseStruct_T {
  char MessageType[18];
  geometry_msgs_PointStruct_T position;
  geometry_msgs_QuaternionStruct_T orientation;
};

struct std_msgs_StringStruct_T {
  char MessageType[15];
  coder::array<char, 2U> data;
};

struct std_msgs_HeaderStruct_T {
  char MessageType[15];
  builtin_interfaces_TimeStruct_T stamp;
  coder::array<char, 2U> frame_id;
};

struct geometry_msgs_PoseStampedStruct_T {
  char MessageType[25];
  std_msgs_HeaderStruct_T header;
  geometry_msgs_PoseStruct_T pose;
};

#endif
//
// File trailer for updatedVisStateEst_types.h
//
// [EOF]
//
