//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: nanoP3p.h
//
// GPU Coder version                    : 24.2
// CUDA/C/C++ source code generated on  : 09-Feb-2026 14:45:55
//

#ifndef NANOP3P_H
#define NANOP3P_H

// Include Files
#include "nanoP3p_spec.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
NANOP3P_DLL_EXPORT extern void nanoP3p(const unsigned char cpu_img[691200],
                                       double bestPose_rc2rw[7]);

#endif
//
// File trailer for nanoP3p.h
//
// [EOF]
//
