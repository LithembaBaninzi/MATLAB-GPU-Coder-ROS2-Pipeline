//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: ros2node.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef ROS2NODE_H
#define ROS2NODE_H

// Include Files
#include "rtwtypes.h"
#include "mlros2_node.h"
#include <cstddef>
#include <cstdlib>

// Type Definitions
namespace coder {
class ros2node {
public:
  rclcpp::Node::SharedPtr NodeHandle;
};

} // namespace coder

#endif
//
// File trailer for ros2node.h
//
// [EOF]
//
