//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xdlahqr.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef XDLAHQR_H
#define XDLAHQR_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace reflapack {
int xdlahqr(int ilo, int ihi, double h[16], int iloz, int ihiz, double z[16],
            double wr[4], double wi[4]);

}
} // namespace internal
} // namespace coder

#endif
//
// File trailer for xdlahqr.h
//
// [EOF]
//
