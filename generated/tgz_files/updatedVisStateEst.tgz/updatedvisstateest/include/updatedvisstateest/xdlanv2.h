//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xdlanv2.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef XDLANV2_H
#define XDLANV2_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace reflapack {
double xdlanv2(double &a, double &b, double &c, double &d, double &rt1i,
               double &rt2r, double &rt2i, double &cs, double &sn);

}
} // namespace internal
} // namespace coder

#endif
//
// File trailer for xdlanv2.h
//
// [EOF]
//
