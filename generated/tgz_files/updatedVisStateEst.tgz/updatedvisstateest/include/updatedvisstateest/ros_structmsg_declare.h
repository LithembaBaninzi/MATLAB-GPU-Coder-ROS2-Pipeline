#ifndef _ROS_STRUCTMSG_DECLARE_H_
#define _ROS_STRUCTMSG_DECLARE_H_

struct builtin_interfaces_TimeStruct_T;

struct geometry_msgs_PointStruct_T;

struct geometry_msgs_PoseStruct_T;

struct geometry_msgs_PoseStampedStruct_T;

struct geometry_msgs_QuaternionStruct_T;

struct std_msgs_HeaderStruct_T;

struct std_msgs_StringStruct_T;


#endif
