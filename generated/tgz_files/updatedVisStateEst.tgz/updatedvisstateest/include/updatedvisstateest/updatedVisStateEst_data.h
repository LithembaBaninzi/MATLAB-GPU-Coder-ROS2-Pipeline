//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: updatedVisStateEst_data.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef UPDATEDVISSTATEEST_DATA_H
#define UPDATEDVISSTATEEST_DATA_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
extern double freq;
extern bool freq_not_empty;
extern const char cv[9];
extern bool isInitialized_updatedVisStateEst;

#endif
//
// File trailer for updatedVisStateEst_data.h
//
// [EOF]
//
