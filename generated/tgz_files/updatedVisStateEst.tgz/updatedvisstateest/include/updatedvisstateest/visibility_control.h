#ifndef UPDATEDVISSTATEEST__VISIBILITY_CONTROL_H_
#define UPDATEDVISSTATEEST__VISIBILITY_CONTROL_H_
#if defined _WIN32 || defined __CYGWIN__
  #ifdef __GNUC__
    #define UPDATEDVISSTATEEST_EXPORT __attribute__ ((dllexport))
    #define UPDATEDVISSTATEEST_IMPORT __attribute__ ((dllimport))
  #else
    #define UPDATEDVISSTATEEST_EXPORT __declspec(dllexport)
    #define UPDATEDVISSTATEEST_IMPORT __declspec(dllimport)
  #endif
  #ifdef UPDATEDVISSTATEEST_BUILDING_LIBRARY
    #define UPDATEDVISSTATEEST_PUBLIC UPDATEDVISSTATEEST_EXPORT
  #else
    #define UPDATEDVISSTATEEST_PUBLIC UPDATEDVISSTATEEST_IMPORT
  #endif
  #define UPDATEDVISSTATEEST_PUBLIC_TYPE UPDATEDVISSTATEEST_PUBLIC
  #define UPDATEDVISSTATEEST_LOCAL
#else
  #define UPDATEDVISSTATEEST_EXPORT __attribute__ ((visibility("default")))
  #define UPDATEDVISSTATEEST_IMPORT
  #if __GNUC__ >= 4
    #define UPDATEDVISSTATEEST_PUBLIC __attribute__ ((visibility("default")))
    #define UPDATEDVISSTATEEST_LOCAL  __attribute__ ((visibility("hidden")))
  #else
    #define UPDATEDVISSTATEEST_PUBLIC
    #define UPDATEDVISSTATEEST_LOCAL
  #endif
  #define UPDATEDVISSTATEEST_PUBLIC_TYPE
#endif
#endif  // UPDATEDVISSTATEEST__VISIBILITY_CONTROL_H_
// Generated 09-Feb-2026 16:10:09
 