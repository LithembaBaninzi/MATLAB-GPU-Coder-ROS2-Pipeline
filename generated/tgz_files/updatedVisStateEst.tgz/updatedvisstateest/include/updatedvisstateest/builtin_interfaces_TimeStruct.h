//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: builtin_interfaces_TimeStruct.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef BUILTIN_INTERFACES_TIMESTRUCT_H
#define BUILTIN_INTERFACES_TIMESTRUCT_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct builtin_interfaces_TimeStruct_T;

// Function Declarations
builtin_interfaces_TimeStruct_T builtin_interfaces_TimeStruct();

#endif
//
// File trailer for builtin_interfaces_TimeStruct.h
//
// [EOF]
//
