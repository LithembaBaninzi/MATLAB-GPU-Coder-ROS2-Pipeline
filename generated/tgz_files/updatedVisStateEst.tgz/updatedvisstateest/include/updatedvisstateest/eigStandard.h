//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: eigStandard.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef EIGSTANDARD_H
#define EIGSTANDARD_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void eigStandard(const double A[16], creal_T V[16], creal_T D[4]);

}

#endif
//
// File trailer for eigStandard.h
//
// [EOF]
//
