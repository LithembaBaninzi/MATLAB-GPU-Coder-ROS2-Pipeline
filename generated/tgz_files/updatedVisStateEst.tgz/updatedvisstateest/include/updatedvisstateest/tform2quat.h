//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: tform2quat.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef TFORM2QUAT_H
#define TFORM2QUAT_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void tform2quat(const double H[16], double q[4]);

}

#endif
//
// File trailer for tform2quat.h
//
// [EOF]
//
