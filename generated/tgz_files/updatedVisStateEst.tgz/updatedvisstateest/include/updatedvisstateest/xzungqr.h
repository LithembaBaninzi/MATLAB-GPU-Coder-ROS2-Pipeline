//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xzungqr.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef XZUNGQR_H
#define XZUNGQR_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace reflapack {
void xzungqr(int m, int n, int k, double A[16], int ia0, const double tau[3],
             int itau0);

}
} // namespace internal
} // namespace coder

#endif
//
// File trailer for xzungqr.h
//
// [EOF]
//
