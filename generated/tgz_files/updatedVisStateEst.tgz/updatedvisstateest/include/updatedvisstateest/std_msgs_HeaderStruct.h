//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: std_msgs_HeaderStruct.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef STD_MSGS_HEADERSTRUCT_H
#define STD_MSGS_HEADERSTRUCT_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct std_msgs_HeaderStruct_T;

// Function Declarations
void std_msgs_HeaderStruct(std_msgs_HeaderStruct_T &msg);

#endif
//
// File trailer for std_msgs_HeaderStruct.h
//
// [EOF]
//
