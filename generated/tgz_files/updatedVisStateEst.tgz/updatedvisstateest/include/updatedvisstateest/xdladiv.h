//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xdladiv.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef XDLADIV_H
#define XDLADIV_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace reflapack {
double xdladiv(double a, double b, double c, double d, double &q);

}
} // namespace internal
} // namespace coder

#endif
//
// File trailer for xdladiv.h
//
// [EOF]
//
