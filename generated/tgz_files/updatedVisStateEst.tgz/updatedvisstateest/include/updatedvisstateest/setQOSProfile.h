//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: setQOSProfile.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef SETQOSPROFILE_H
#define SETQOSPROFILE_H

// Include Files
#include "rtwtypes.h"
#include "rmw/qos_profiles.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace ros {
namespace ros2 {
namespace internal {
rmw_qos_profile_t setQOSProfile(rmw_qos_profile_t rmwProfile, double qosDepth,
                                const char qosReliability[8],
                                double qosDeadline, double qosLifespan,
                                const char qosLiveliness[9],
                                double qosLeaseDuration,
                                bool qosAvoidROSNamespaceConventions);

}
} // namespace ros2
} // namespace ros
} // namespace coder

#endif
//
// File trailer for setQOSProfile.h
//
// [EOF]
//
