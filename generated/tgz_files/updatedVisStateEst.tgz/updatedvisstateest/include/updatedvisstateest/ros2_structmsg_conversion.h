#ifndef _ROS2_STRUCTMSG_CONVERSION_H_
#define _ROS2_STRUCTMSG_CONVERSION_H_

#include "ros_structmsg_declare.h"
#include "rclcpp/rclcpp.hpp"
#include <builtin_interfaces/msg/time.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <geometry_msgs/msg/pose.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/quaternion.hpp>
#include <std_msgs/msg/header.hpp>
#include <std_msgs/msg/string.hpp>
#include "updatedVisStateEst_types.h"
#include "mlros2_msgconvert_utils.h"


void struct2msg(builtin_interfaces::msg::Time& msgPtr, builtin_interfaces_TimeStruct_T const* structPtr);
void msg2struct(builtin_interfaces_TimeStruct_T* structPtr, const builtin_interfaces::msg::Time& msgPtr);

void struct2msg(geometry_msgs::msg::Point& msgPtr, geometry_msgs_PointStruct_T const* structPtr);
void msg2struct(geometry_msgs_PointStruct_T* structPtr, const geometry_msgs::msg::Point& msgPtr);

void struct2msg(geometry_msgs::msg::Pose& msgPtr, geometry_msgs_PoseStruct_T const* structPtr);
void msg2struct(geometry_msgs_PoseStruct_T* structPtr, const geometry_msgs::msg::Pose& msgPtr);

void struct2msg(geometry_msgs::msg::PoseStamped& msgPtr, geometry_msgs_PoseStampedStruct_T const* structPtr);
void msg2struct(geometry_msgs_PoseStampedStruct_T* structPtr, const geometry_msgs::msg::PoseStamped& msgPtr);

void struct2msg(geometry_msgs::msg::Quaternion& msgPtr, geometry_msgs_QuaternionStruct_T const* structPtr);
void msg2struct(geometry_msgs_QuaternionStruct_T* structPtr, const geometry_msgs::msg::Quaternion& msgPtr);

void struct2msg(std_msgs::msg::Header& msgPtr, std_msgs_HeaderStruct_T const* structPtr);
void msg2struct(std_msgs_HeaderStruct_T* structPtr, const std_msgs::msg::Header& msgPtr);

void struct2msg(std_msgs::msg::String& msgPtr, std_msgs_StringStruct_T const* structPtr);
void msg2struct(std_msgs_StringStruct_T* structPtr, const std_msgs::msg::String& msgPtr);


#endif
