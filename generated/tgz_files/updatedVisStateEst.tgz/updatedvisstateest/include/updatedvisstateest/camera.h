//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: camera.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef CAMERA_H
#define CAMERA_H

// Include Files
#include "rtwtypes.h"
#include "frameReader.h"
#include <cstddef>
#include <cstdlib>

// Type Definitions
namespace coder {
namespace nvidiacoder {
namespace common {
class camera {
public:
  static camera *b_camera(camera &iobj_0);
  void snapshot(unsigned char image[691200]);
  void matlabCodegenDestructor();
  ~camera();
  camera();

protected:
  void initCamera();
  void stepImpl(unsigned char image[691200]);
  void releaseImpl();

public:
  bool matlabCodegenIsDeleted;
  int isInitialized;
  bool Initialized;
  char VideoDevice[33];
  double CamWidth;
  double CamHeight;
  double Duration;
  unsigned int SearchMode;
  char PixelFormat[8];

private:
  bool isSetupComplete;
  MW_customData StructCustomData;
  double FrameRate;
};

} // namespace common
} // namespace nvidiacoder
} // namespace coder

#endif
//
// File trailer for camera.h
//
// [EOF]
//
