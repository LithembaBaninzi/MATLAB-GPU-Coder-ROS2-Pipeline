//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xdtrevc3.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Feb-2026 16:09:19
//

#ifndef XDTREVC3_H
#define XDTREVC3_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace reflapack {
void xdtrevc3(const double T[16], double vr[16]);

}
} // namespace internal
} // namespace coder

#endif
//
// File trailer for xdtrevc3.h
//
// [EOF]
//
