//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: nanoP3p_spec.h
//
// GPU Coder version                    : 24.2
// CUDA/C/C++ source code generated on  : 09-Feb-2026 14:45:55
//

#ifndef NANOP3P_SPEC_H
#define NANOP3P_SPEC_H

// Include Files
#if defined(NANOP3P_XIL_BUILD) || defined(BUILDING_EXE_NANOP3P)
#if defined(_WIN32) || defined(__LCC__)
#define NANOP3P_DLL_EXPORT __declspec(dllimport)
#else
#define NANOP3P_DLL_EXPORT __attribute__((visibility("default")))
#endif
#elif defined(BUILDING_NANOP3P)
#if defined(_WIN32) || defined(__LCC__)
#define NANOP3P_DLL_EXPORT __declspec(dllexport)
#else
#define NANOP3P_DLL_EXPORT __attribute__((visibility("default")))
#endif
#else
#define NANOP3P_DLL_EXPORT
#endif

#endif
//
// File trailer for nanoP3p_spec.h
//
// [EOF]
//
